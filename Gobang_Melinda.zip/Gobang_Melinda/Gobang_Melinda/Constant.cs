﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Gobang_Melinda
{
    static class Constant
    {
        public const int SIZE_CHESSBOARD = 15;
        public const int BLACKCHESS = 0;
        public const int WHITECHESS = 1;
        public const int NULLCHESS = 2;
        public const int WINSCORE = 50000;
    }
}
