﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Gobang_Melinda
{
    [Serializable]
    public  class tempmemories
    {
        /// <summary>
        /// 
        /// </summary>
        public static int _tempmemories { get; set; }

        public static int temparr { get; set; }

    };
}
