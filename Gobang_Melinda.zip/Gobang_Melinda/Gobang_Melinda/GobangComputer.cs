﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Gobang_Melinda
{
    public class GobangComputer
    {
        private readonly static GobangComputer _instance = new GobangComputer();
        public static GobangComputer Instance //return a static example
        {
            get { return _instance; }
        }


        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        /// <param name="CheckBoard"></param>param>
        /// <param name="row"></param>param>
        /// <param name="column"></param>param>
        [STAThread]
        #region
        public int ComputerMethod(int[,] CheckBoard, int j)
        {
            int row, column;
            int computerchess, playerchess;                     //assign the player's chess to colour black, the computer's chess as white
            int computer_score, player_score;          //set to zero
            int score_max = -100000, score_temp = 0;
            int rowcomputer, colcomputer, rowplayer, colplayer;
            //Prunning (track a place where there exist a chess in the surrouding eight direction, if not, the computer will not choose this road, prunning=true)
            bool Pruning = false;
            playerchess = Constant.BLACKCHESS;
            computerchess = Constant.WHITECHESS;
            row = j/ 15;
            column = j % 15;
            //calculate the most accurate point of landing
            for (rowcomputer = 0; rowcomputer < Constant.SIZE_CHESSBOARD; rowcomputer++)
            {
                for (colcomputer = 0; colcomputer < Constant.SIZE_CHESSBOARD; colcomputer++)
                {
                    if (CheckBoard[rowcomputer, colcomputer] != Constant.NULLCHESS)
                        continue;
                    //set the empty spot as computer's
                    CheckBoard[rowcomputer, colcomputer] = computerchess;

                    //predict the spot where player will put their chess at
                    Pruning = false;
                    score_temp = 100000;
                    for (rowplayer = 0; rowplayer < Constant.SIZE_CHESSBOARD; rowplayer++)
                    {
                        for (colplayer = 0; colplayer < Constant.SIZE_CHESSBOARD; colplayer++)
                        { //supposedly add one player's chess to see the place where player gets the highest score at
                            if (CheckBoard[rowplayer, colplayer] != Constant.NULLCHESS)
                                continue;

                            //set the empty spot as player's
                            CheckBoard[rowplayer, colplayer] = playerchess;

                            computer_score = GetScore(CheckBoard, rowcomputer, colcomputer);
                            player_score = GetScore(CheckBoard, rowplayer, colplayer);

                            //cancel the player's chess   
                            CheckBoard[rowplayer, colplayer] = Constant.NULLCHESS;
                            //pruning if the current max is bigger than the minimum of situation (since the number of getting five = Method1 * 2  - Method 2) and  score max is the "minumum" score
                            if (score_max > computer_score - 2 * player_score)
                            {
                                Pruning = true;
                                break;
                            }
                            //the computer'schess will land on the highest point
                            if (score_temp > computer_score - 2 * player_score)
                            {
                                score_temp = computer_score - 2 * player_score;
                            }
                        }
                        if (Pruning)
                            break;
                    }
                    //cancel the computer's chess on rowcomputer,colcomputer
                    CheckBoard[rowcomputer, colcomputer] = Constant.NULLCHESS;
                    if (Pruning)
                        continue;
                    //acquire the place where computer gets the largest points at
                    if (score_max < score_temp)
                    {
                        score_max = score_temp;
                        row = rowcomputer;
                        column = colcomputer;
                    }
                }//colcomputer
            }//rowcomputer
            return row * 15 + column;

        }
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        /// <param name="chessarr"></param>param>
        /// <param name="chess"></param>param>
        private int GetScore(int[,] ChessBoard, int row, int column)
        {
            int i, j, k, horizontal, vertical;
            int chess = ChessBoard[row, column];
            int[] chessarr = new int[7];
            int score = 0, score_temp;
            //condition ? consequent : alternatives
            for (horizontal = column - 4 < 0 ? 0 : column - 4; horizontal <= column; horizontal++)
            {
                // check for horizontal  [the possibility of five in horizontal line]
                //if the spot extended cannot form a consecutive five, move on to the next spot
                if (horizontal + 4 >= Constant.SIZE_CHESSBOARD)
                    break;
                if (horizontal - 1 >= 0)
                    chessarr[0] = ChessBoard[row, horizontal - 1];
                else
                    chessarr[0] = Constant.BLACKCHESS;

                //middle five
                for (k = 1, j = horizontal; j < horizontal + 5; k++, j++)
                {
                    chessarr[k] = ChessBoard[row, j];
                }
                //determine seven consecutive spots extended from the White chess, to get the optimum result, use Black chess to replace the last space 
                if (horizontal + 5 < Constant.SIZE_CHESSBOARD)
                    chessarr[6] = ChessBoard[row, horizontal + 5];
                else
                    chessarr[6] = Constant.BLACKCHESS;
                //calculate the score of five chess
                score_temp = GetScorefive(chessarr, chess);
                if (score_temp == Constant.WINSCORE)
                    return Constant.WINSCORE;
                score += score_temp;
            }//horizontal
            //calculate the possiblity to link a five in vertical two directions
            for (vertical = (row - 4 < 0 ? 0 : row - 4); vertical <= row; vertical++)
            {
                // check for horizontal [the possibility of five in vertical line]
                if (vertical + 4 >= Constant.SIZE_CHESSBOARD)
                    break;
                if (vertical - 1 >= 0)
                    chessarr[0] = ChessBoard[vertical - 1, column];
                else
                    chessarr[0] = Constant.BLACKCHESS;

                //middle five
                for (k = 1, i = vertical; i < vertical + 5; k++, i++)
                {
                    chessarr[k] = ChessBoard[i, column];
                }

                if (vertical + 5 < Constant.SIZE_CHESSBOARD)
                    chessarr[6] = ChessBoard[vertical + 5, column];
                else
                    chessarr[6] = Constant.BLACKCHESS;
                //calculate the score
                score_temp = GetScorefive(chessarr, chess);
                if (score_temp == Constant.WINSCORE)
                    return Constant.WINSCORE;
                score += score_temp;
            }//vertical

            //check for two diagonals
            for (vertical = row + 4, horizontal = column - 4; vertical >= Constant.SIZE_CHESSBOARD || horizontal < 0; vertical--, horizontal++) ;
            for (; horizontal <= column; vertical--, horizontal++)
            {
                if (vertical - 4 < 0 || horizontal + 4 >= Constant.SIZE_CHESSBOARD)
                    break;
                // slope>0 diagnol direction
                if (vertical + 1 < Constant.SIZE_CHESSBOARD && horizontal - 1 >= 0)
                    chessarr[0] = ChessBoard[vertical + 1, horizontal - 1];
                else
                    chessarr[0] = Constant.BLACKCHESS;
                for (k = 1, i = vertical, j = horizontal; i > vertical - 5; k++, i--, j++)
                    chessarr[k] = ChessBoard[i, j];

                if (vertical - 1 >= 0 && horizontal + 1 < Constant.SIZE_CHESSBOARD)
                    chessarr[6] = ChessBoard[vertical - 1, horizontal + 1];
                else
                    chessarr[6] = Constant.BLACKCHESS;
                //calculate the score of five chess
                score_temp = GetScorefive(chessarr, chess);
                //return the winscore value if there is five chess
                if (score_temp == Constant.WINSCORE)
                    return Constant.WINSCORE;
                score += score_temp;
            }
            for (vertical = row - 4, horizontal = column - 4; vertical < 0 || horizontal < 0; vertical++, horizontal++) ;
            for (; horizontal <= column; vertical++, horizontal++)
            {
                //if oversized, passed
                if (vertical + 4 >= Constant.SIZE_CHESSBOARD || horizontal + 4 >= Constant.SIZE_CHESSBOARD)
                    break;

                if (vertical - 1 >= 0 && horizontal - 1 >= 0)
                    chessarr[0] = ChessBoard[vertical - 1, horizontal - 1];
                else
                    chessarr[0] = Constant.BLACKCHESS;
                for (k = 1, i = vertical, j = horizontal; i < vertical + 5; k++, i++, j++)
                    chessarr[k] = ChessBoard[i, j];
                if (vertical + 5 < Constant.SIZE_CHESSBOARD && horizontal + 5 < Constant.SIZE_CHESSBOARD)
                    chessarr[6] = ChessBoard[vertical + 5, horizontal + 5];
                else
                    chessarr[6] = Constant.BLACKCHESS;
                score_temp = GetScorefive(chessarr, chess);
                if (score_temp == Constant.WINSCORE)
                    return Constant.WINSCORE;
                score += score_temp;
            }
            return score;
        }

        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        /// <param name="arr"></param>param>
        /// <param name="chess"></param>param>
        private int GetScorefive(int[] arr, int chess)
        {
            int i, j;
            int count = 0;
            int[] chessarray = new int[3] { 0, 0, 0 };
            bool exist_first = false, exist_end = false;

            if (arr[0] != Constant.NULLCHESS && arr[1] == chess)
                exist_first = true;
            if (arr[6] != Constant.NULLCHESS && arr[5] == chess)
                exist_end = true;

            j = -1;
            bool exist = false;
            for (i = 0; i < 5; i++)
            {
                if (arr[i + 1] != chess && arr[i] != Constant.NULLCHESS)
                    return 0;
                if (arr[i + 1] == chess)
                {
                    count++;
                    if (exist == false)
                        j += 1;
                    exist = true;
                    chessarray[j]++;
                }
                else
                {
                    exist = false;
                }
            }//for
            if (count == 5)
                return Constant.WINSCORE;
            else if (count == 4)
            {
                //4=4+0
                if (chessarray[0] == 4)
                {
                    if (exist_first || exist_end)
                        return 30;
                    else
                        return 50;
                }
                //4=3+1 or 1+3 or 2+2
                else
                    return 25;
            }

            else if (count == 3)
            {
                //3=3+0
                if (chessarray[0] == 3)
                {
                    if (exist_first || exist_end)
                        return 10;
                    else
                        return 20;
                }
                else if (chessarray[0] == 2 || chessarray[0] == 1)
                {
                    //3=3+0
                    if (exist_first && exist_end)
                        return 6;
                    else if (exist_first || exist_end)
                        return 10;
                    else
                        return 25;
                }
                // 3 = 1 + 1 + 1
                else
                {
                    if (exist_first || exist_end)
                        return 6;
                    else
                        return 8;
                }
            }//else if count==3
            else if (count == 2)
            {
                // 2 = 2 + 0
                if (chessarray[0] == 2)
                {
                    if (exist_first || exist_end)
                        return 3;
                    else
                        return 6;
                }

                // 2=1+1
                else
                {
                    if (exist_first && exist_end)
                        return 2;
                    else if (exist_first || exist_end)
                        return 3;
                    else
                        return 6;
                }
            }//else if
            else
            {

                if (exist_first || exist_end)
                    return 1;
                else
                    return 2;
            }

        }//else if

        #endregion;
    }
}
