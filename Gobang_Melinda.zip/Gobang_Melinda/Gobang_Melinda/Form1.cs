﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Drawing.Drawing2D;


namespace Gobang_Melinda
{

    public partial class Gobang : Form
    {
        int i = 0;
        int[,] CheckBoard = new int[Constant.SIZE_CHESSBOARD, Constant.SIZE_CHESSBOARD];
        private readonly PictureBox[] _pictureBox = new PictureBox[225];
        private readonly static GobangComputer _instance = new GobangComputer();
        bool getwinner = false;
        public static GobangComputer Instance //return a static example
        {
            get { return _instance; }
        }

        public Gobang()
        {
            InitializeComponent();
            for (int k = 0; k < Constant.SIZE_CHESSBOARD; k++)
               for (int j = 0; j < Constant.SIZE_CHESSBOARD; j++)
                   CheckBoard[j, k] = Constant.NULLCHESS;
            #region _pictureBox
            _pictureBox[0] = this.pictureBox1;
            _pictureBox[1] = this.pictureBox2;
            _pictureBox[2] = this.pictureBox3;
            _pictureBox[3] = this.pictureBox4;
            _pictureBox[4] = this.pictureBox5;
            _pictureBox[5] = this.pictureBox6;
            _pictureBox[6] = this.pictureBox7;
            _pictureBox[7] = this.pictureBox8;
            _pictureBox[8] = this.pictureBox9;
            _pictureBox[9] = this.pictureBox10;
            _pictureBox[10] = this.pictureBox11;
            _pictureBox[11] = this.pictureBox12;
            _pictureBox[12] = this.pictureBox13;
            _pictureBox[13] = this.pictureBox14;
            _pictureBox[14] = this.pictureBox15;
            _pictureBox[15] = this.pictureBox16;
            _pictureBox[16] = this.pictureBox17;
            _pictureBox[17] = this.pictureBox18;
            _pictureBox[18] = this.pictureBox19;
            _pictureBox[19] = this.pictureBox20;
            _pictureBox[20] = this.pictureBox21;
            _pictureBox[21] = this.pictureBox22;
            _pictureBox[22] = this.pictureBox23;
            _pictureBox[23] = this.pictureBox24;
            _pictureBox[24] = this.pictureBox25;
            _pictureBox[25] = this.pictureBox26;
            _pictureBox[26] = this.pictureBox27;
            _pictureBox[27] = this.pictureBox28;
            _pictureBox[28] = this.pictureBox29;
            _pictureBox[29] = this.pictureBox30;
            _pictureBox[30] = this.pictureBox31;
            _pictureBox[31] = this.pictureBox32;
            _pictureBox[32] = this.pictureBox33;
            _pictureBox[33] = this.pictureBox34;
            _pictureBox[34] = this.pictureBox35;
            _pictureBox[35] = this.pictureBox36;
            _pictureBox[36] = this.pictureBox37;
            _pictureBox[37] = this.pictureBox38;
            _pictureBox[38] = this.pictureBox39;
            _pictureBox[39] = this.pictureBox40;
            _pictureBox[40] = this.pictureBox41;
            _pictureBox[41] = this.pictureBox42;
            _pictureBox[42] = this.pictureBox43;
            _pictureBox[43] = this.pictureBox44;
            _pictureBox[44] = this.pictureBox45;
            _pictureBox[45] = this.pictureBox46;
            _pictureBox[46] = this.pictureBox47;
            _pictureBox[47] = this.pictureBox48;
            _pictureBox[48] = this.pictureBox49;
            _pictureBox[49] = this.pictureBox50;
            _pictureBox[50] = this.pictureBox51;
            _pictureBox[51] = this.pictureBox52;
            _pictureBox[52] = this.pictureBox53;
            _pictureBox[53] = this.pictureBox54;
            _pictureBox[54] = this.pictureBox55;
            _pictureBox[55] = this.pictureBox56;
            _pictureBox[56] = this.pictureBox57;
            _pictureBox[57] = this.pictureBox58;
            _pictureBox[58] = this.pictureBox59;
            _pictureBox[59] = this.pictureBox60;
            _pictureBox[60] = this.pictureBox61;
            _pictureBox[61] = this.pictureBox62;
            _pictureBox[62] = this.pictureBox63;
            _pictureBox[63] = this.pictureBox64;
            _pictureBox[64] = this.pictureBox65;
            _pictureBox[65] = this.pictureBox66;
            _pictureBox[66] = this.pictureBox67;
            _pictureBox[67] = this.pictureBox68;
            _pictureBox[68] = this.pictureBox69;
            _pictureBox[69] = this.pictureBox70;
            _pictureBox[70] = this.pictureBox71;
            _pictureBox[71] = this.pictureBox72;
            _pictureBox[72] = this.pictureBox73;
            _pictureBox[73] = this.pictureBox74;
            _pictureBox[74] = this.pictureBox75;
            _pictureBox[75] = this.pictureBox76;
            _pictureBox[76] = this.pictureBox77;
            _pictureBox[77] = this.pictureBox78;
            _pictureBox[78] = this.pictureBox79;
            _pictureBox[79] = this.pictureBox80;
            _pictureBox[80] = this.pictureBox81;
            _pictureBox[81] = this.pictureBox82;
            _pictureBox[82] = this.pictureBox83;
            _pictureBox[83] = this.pictureBox84;
            _pictureBox[84] = this.pictureBox85;
            _pictureBox[85] = this.pictureBox86;
            _pictureBox[86] = this.pictureBox87;
            _pictureBox[87] = this.pictureBox88;
            _pictureBox[88] = this.pictureBox89;
            _pictureBox[89] = this.pictureBox90;
            _pictureBox[90] = this.pictureBox91;
            _pictureBox[91] = this.pictureBox92;
            _pictureBox[92] = this.pictureBox93;
            _pictureBox[93] = this.pictureBox94;
            _pictureBox[94] = this.pictureBox95;
            _pictureBox[95] = this.pictureBox96;
            _pictureBox[96] = this.pictureBox97;
            _pictureBox[97] = this.pictureBox98;
            _pictureBox[98] = this.pictureBox99;
            _pictureBox[99] = this.pictureBox100;
            _pictureBox[100] = this.pictureBox101;
            _pictureBox[101] = this.pictureBox102;
            _pictureBox[102] = this.pictureBox103;
            _pictureBox[103] = this.pictureBox104;
            _pictureBox[104] = this.pictureBox105;
            _pictureBox[105] = this.pictureBox106;
            _pictureBox[106] = this.pictureBox107;
            _pictureBox[107] = this.pictureBox108;
            _pictureBox[108] = this.pictureBox109;
            _pictureBox[109] = this.pictureBox110;
            _pictureBox[110] = this.pictureBox111;
            _pictureBox[111] = this.pictureBox112;
            _pictureBox[112] = this.pictureBox113;
            _pictureBox[113] = this.pictureBox114;
            _pictureBox[114] = this.pictureBox115;
            _pictureBox[115] = this.pictureBox116;
            _pictureBox[116] = this.pictureBox117;
            _pictureBox[117] = this.pictureBox118;
            _pictureBox[118] = this.pictureBox119;
            _pictureBox[119] = this.pictureBox120;

            _pictureBox[120] = this.pictureBox121;
            _pictureBox[121] = this.pictureBox122;
            _pictureBox[122] = this.pictureBox123;
            _pictureBox[123] = this.pictureBox124;
            _pictureBox[124] = this.pictureBox125;
            _pictureBox[125] = this.pictureBox126;
            _pictureBox[126] = this.pictureBox127;
            _pictureBox[127] = this.pictureBox128;
            _pictureBox[128] = this.pictureBox129;
            _pictureBox[129] = this.pictureBox130;
            _pictureBox[130] = this.pictureBox131;
            _pictureBox[131] = this.pictureBox132;
            _pictureBox[132] = this.pictureBox133;
            _pictureBox[133] = this.pictureBox134;
            _pictureBox[134] = this.pictureBox135;
            _pictureBox[135] = this.pictureBox136;
            _pictureBox[136] = this.pictureBox137;
            _pictureBox[137] = this.pictureBox138;
            _pictureBox[138] = this.pictureBox139;
            _pictureBox[139] = this.pictureBox140;

            _pictureBox[140] = this.pictureBox141;
            _pictureBox[141] = this.pictureBox142;
            _pictureBox[142] = this.pictureBox143;
            _pictureBox[143] = this.pictureBox144;
            _pictureBox[144] = this.pictureBox145;
            _pictureBox[145] = this.pictureBox146;
            _pictureBox[146] = this.pictureBox147;
            _pictureBox[147] = this.pictureBox148;
            _pictureBox[148] = this.pictureBox149;
            _pictureBox[149] = this.pictureBox150;
            _pictureBox[150] = this.pictureBox151;
            _pictureBox[151] = this.pictureBox152;
            _pictureBox[152] = this.pictureBox153;
            _pictureBox[153] = this.pictureBox154;
            _pictureBox[154] = this.pictureBox155;
            _pictureBox[155] = this.pictureBox156;
            _pictureBox[156] = this.pictureBox157;
            _pictureBox[157] = this.pictureBox158;
            _pictureBox[158] = this.pictureBox159;
            _pictureBox[159] = this.pictureBox160;

            _pictureBox[160] = this.pictureBox161;
            _pictureBox[161] = this.pictureBox162;
            _pictureBox[162] = this.pictureBox163;
            _pictureBox[163] = this.pictureBox164;
            _pictureBox[164] = this.pictureBox165;
            _pictureBox[165] = this.pictureBox166;
            _pictureBox[166] = this.pictureBox167;
            _pictureBox[167] = this.pictureBox168;
            _pictureBox[168] = this.pictureBox169;
            _pictureBox[169] = this.pictureBox170;
            _pictureBox[170] = this.pictureBox171;
            _pictureBox[171] = this.pictureBox172;
            _pictureBox[172] = this.pictureBox173;
            _pictureBox[173] = this.pictureBox174;
            _pictureBox[174] = this.pictureBox175;
            _pictureBox[175] = this.pictureBox176;
            _pictureBox[176] = this.pictureBox177;
            _pictureBox[177] = this.pictureBox178;
            _pictureBox[178] = this.pictureBox179;
            _pictureBox[179] = this.pictureBox180;

            _pictureBox[180] = this.pictureBox181;
            _pictureBox[181] = this.pictureBox182;
            _pictureBox[182] = this.pictureBox183;
            _pictureBox[183] = this.pictureBox184;
            _pictureBox[184] = this.pictureBox185;
            _pictureBox[185] = this.pictureBox186;
            _pictureBox[186] = this.pictureBox187;
            _pictureBox[187] = this.pictureBox188;
            _pictureBox[188] = this.pictureBox189;
            _pictureBox[189] = this.pictureBox190;
            _pictureBox[190] = this.pictureBox191;
            _pictureBox[191] = this.pictureBox192;
            _pictureBox[192] = this.pictureBox193;
            _pictureBox[193] = this.pictureBox194;
            _pictureBox[194] = this.pictureBox195;
            _pictureBox[195] = this.pictureBox196;
            _pictureBox[196] = this.pictureBox197;
            _pictureBox[197] = this.pictureBox198;
            _pictureBox[198] = this.pictureBox199;
            _pictureBox[199] = this.pictureBox200;

            _pictureBox[200] = this.pictureBox201;
            _pictureBox[201] = this.pictureBox202;
            _pictureBox[202] = this.pictureBox203;
            _pictureBox[203] = this.pictureBox204;
            _pictureBox[204] = this.pictureBox205;
            _pictureBox[205] = this.pictureBox206;
            _pictureBox[206] = this.pictureBox207;
            _pictureBox[207] = this.pictureBox208;
            _pictureBox[208] = this.pictureBox209;
            _pictureBox[209] = this.pictureBox210;
            _pictureBox[210] = this.pictureBox211;
            _pictureBox[211] = this.pictureBox212;
            _pictureBox[212] = this.pictureBox213;
            _pictureBox[213] = this.pictureBox214;
            _pictureBox[214] = this.pictureBox215;
            _pictureBox[215] = this.pictureBox216;
            _pictureBox[216] = this.pictureBox217;
            _pictureBox[217] = this.pictureBox218;
            _pictureBox[218] = this.pictureBox219;
            _pictureBox[219] = this.pictureBox220;
            _pictureBox[220] = this.pictureBox221;
            _pictureBox[221] = this.pictureBox222;
            _pictureBox[222] = this.pictureBox223;
            _pictureBox[223] = this.pictureBox224;
            _pictureBox[224] = this.pictureBox225;

            #endregion
        }

        #region ClickEvent

        private void pictureBox1_Click(object sender, EventArgs e) { GetClickpictureBox(0); }
        private void pictureBox2_Click(object sender, EventArgs e) { GetClickpictureBox(1); }
        private void pictureBox3_Click(object sender, EventArgs e) { GetClickpictureBox(2); }
        private void pictureBox4_Click(object sender, EventArgs e) { GetClickpictureBox(3); }
        private void pictureBox5_Click(object sender, EventArgs e) { GetClickpictureBox(4); }
        private void pictureBox6_Click(object sender, EventArgs e) { GetClickpictureBox(5); }

        private void pictureBox7_Click(object sender, EventArgs e) { GetClickpictureBox(6); }
        private void pictureBox8_Click(object sender, EventArgs e) { GetClickpictureBox(7); }
        private void pictureBox9_Click(object sender, EventArgs e) { GetClickpictureBox(8); }
        private void pictureBox10_Click(object sender, EventArgs e) { GetClickpictureBox(9); }
        private void pictureBox11_Click(object sender, EventArgs e) { GetClickpictureBox(10); }
        private void pictureBox12_Click(object sender, EventArgs e) { GetClickpictureBox(11); }

        private void pictureBox13_Click(object sender, EventArgs e) { GetClickpictureBox(12); }
        private void pictureBox14_Click(object sender, EventArgs e) { GetClickpictureBox(13); }
        private void pictureBox15_Click(object sender, EventArgs e) { GetClickpictureBox(14); }
        private void pictureBox16_Click(object sender, EventArgs e) { GetClickpictureBox(15); }
        private void pictureBox17_Click(object sender, EventArgs e) { GetClickpictureBox(16); }
        private void pictureBox18_Click(object sender, EventArgs e) { GetClickpictureBox(17); }
        private void pictureBox19_Click(object sender, EventArgs e) { GetClickpictureBox(18); }
        private void pictureBox20_Click(object sender, EventArgs e) { GetClickpictureBox(19); }
        private void pictureBox21_Click(object sender, EventArgs e) { GetClickpictureBox(20); }
        private void pictureBox22_Click(object sender, EventArgs e) { GetClickpictureBox(21); }
        private void pictureBox23_Click(object sender, EventArgs e) { GetClickpictureBox(22); }
        private void pictureBox24_Click(object sender, EventArgs e) { GetClickpictureBox(23); }

        private void pictureBox25_Click(object sender, EventArgs e) { GetClickpictureBox(24); }
        private void pictureBox26_Click(object sender, EventArgs e) { GetClickpictureBox(25); }
        private void pictureBox27_Click(object sender, EventArgs e) { GetClickpictureBox(26); }
        private void pictureBox28_Click(object sender, EventArgs e) { GetClickpictureBox(27); }
        private void pictureBox29_Click(object sender, EventArgs e) { GetClickpictureBox(28); }
        private void pictureBox30_Click(object sender, EventArgs e) { GetClickpictureBox(29); }

        private void pictureBox31_Click(object sender, EventArgs e) { GetClickpictureBox(30); }
        private void pictureBox32_Click(object sender, EventArgs e) { GetClickpictureBox(31); }
        private void pictureBox33_Click(object sender, EventArgs e) { GetClickpictureBox(32); }
        private void pictureBox34_Click(object sender, EventArgs e) { GetClickpictureBox(33); }
        private void pictureBox35_Click(object sender, EventArgs e) { GetClickpictureBox(34); }
        private void pictureBox36_Click(object sender, EventArgs e) { GetClickpictureBox(35); }
        private void pictureBox37_Click(object sender, EventArgs e) { GetClickpictureBox(36); }
        private void pictureBox38_Click(object sender, EventArgs e) { GetClickpictureBox(37); }
        private void pictureBox39_Click(object sender, EventArgs e) { GetClickpictureBox(38); }
        private void pictureBox40_Click(object sender, EventArgs e) { GetClickpictureBox(39); }
        private void pictureBox41_Click(object sender, EventArgs e) { GetClickpictureBox(40); }
        private void pictureBox42_Click(object sender, EventArgs e) { GetClickpictureBox(41); }
        private void pictureBox43_Click(object sender, EventArgs e) { GetClickpictureBox(42); }
        private void pictureBox44_Click(object sender, EventArgs e) { GetClickpictureBox(43); }
        private void pictureBox45_Click(object sender, EventArgs e) { GetClickpictureBox(44); }
        private void pictureBox46_Click(object sender, EventArgs e) { GetClickpictureBox(45); }
        private void pictureBox47_Click(object sender, EventArgs e) { GetClickpictureBox(46); }
        private void pictureBox48_Click(object sender, EventArgs e) { GetClickpictureBox(47); }
        private void pictureBox49_Click(object sender, EventArgs e) { GetClickpictureBox(48); }
        private void pictureBox50_Click(object sender, EventArgs e) { GetClickpictureBox(49); }
        private void pictureBox51_Click(object sender, EventArgs e) { GetClickpictureBox(50); }
        private void pictureBox52_Click(object sender, EventArgs e) { GetClickpictureBox(51); }
        private void pictureBox53_Click(object sender, EventArgs e) { GetClickpictureBox(52); }
        private void pictureBox54_Click(object sender, EventArgs e) { GetClickpictureBox(53); }
        private void pictureBox55_Click(object sender, EventArgs e) { GetClickpictureBox(54); }
        private void pictureBox56_Click(object sender, EventArgs e) { GetClickpictureBox(55); }
        private void pictureBox57_Click(object sender, EventArgs e) { GetClickpictureBox(56); }
        private void pictureBox58_Click(object sender, EventArgs e) { GetClickpictureBox(57); }
        private void pictureBox59_Click(object sender, EventArgs e) { GetClickpictureBox(58); }
        private void pictureBox60_Click(object sender, EventArgs e) { GetClickpictureBox(59); }
        private void pictureBox61_Click(object sender, EventArgs e) { GetClickpictureBox(60); }
        private void pictureBox62_Click(object sender, EventArgs e) { GetClickpictureBox(61); }
        private void pictureBox63_Click(object sender, EventArgs e) { GetClickpictureBox(62); }
        private void pictureBox64_Click(object sender, EventArgs e) { GetClickpictureBox(63); }
        private void pictureBox65_Click(object sender, EventArgs e) { GetClickpictureBox(64); }
        private void pictureBox66_Click(object sender, EventArgs e) { GetClickpictureBox(65); }
        private void pictureBox67_Click(object sender, EventArgs e) { GetClickpictureBox(66); }
        private void pictureBox68_Click(object sender, EventArgs e) { GetClickpictureBox(67); }
        private void pictureBox69_Click(object sender, EventArgs e) { GetClickpictureBox(68); }
        private void pictureBox70_Click(object sender, EventArgs e) { GetClickpictureBox(69); }

        private void pictureBox71_Click(object sender, EventArgs e) { GetClickpictureBox(70); }
        private void pictureBox72_Click(object sender, EventArgs e) { GetClickpictureBox(71); }
        private void pictureBox73_Click(object sender, EventArgs e) { GetClickpictureBox(72); }
        private void pictureBox74_Click(object sender, EventArgs e) { GetClickpictureBox(73); }
        private void pictureBox75_Click(object sender, EventArgs e) { GetClickpictureBox(74); }
        private void pictureBox76_Click(object sender, EventArgs e) { GetClickpictureBox(75); }
        private void pictureBox77_Click(object sender, EventArgs e) { GetClickpictureBox(76); }
        private void pictureBox78_Click(object sender, EventArgs e) { GetClickpictureBox(77); }
        private void pictureBox79_Click(object sender, EventArgs e) { GetClickpictureBox(78); }
        private void pictureBox80_Click(object sender, EventArgs e) { GetClickpictureBox(79); }
        private void pictureBox81_Click(object sender, EventArgs e) { GetClickpictureBox(80); }
        private void pictureBox82_Click(object sender, EventArgs e) { GetClickpictureBox(81); }
        private void pictureBox83_Click(object sender, EventArgs e) { GetClickpictureBox(82); }
        private void pictureBox84_Click(object sender, EventArgs e) { GetClickpictureBox(83); }
        private void pictureBox85_Click(object sender, EventArgs e) { GetClickpictureBox(84); }
        private void pictureBox86_Click(object sender, EventArgs e) { GetClickpictureBox(85); }
        private void pictureBox87_Click(object sender, EventArgs e) { GetClickpictureBox(86); }
        private void pictureBox88_Click(object sender, EventArgs e) { GetClickpictureBox(87); }
        private void pictureBox89_Click(object sender, EventArgs e) { GetClickpictureBox(88); }
        private void pictureBox90_Click(object sender, EventArgs e) { GetClickpictureBox(89); }

        private void pictureBox91_Click(object sender, EventArgs e) { GetClickpictureBox(90); }
        private void pictureBox92_Click(object sender, EventArgs e) { GetClickpictureBox(91); }
        private void pictureBox93_Click(object sender, EventArgs e) { GetClickpictureBox(92); }
        private void pictureBox94_Click(object sender, EventArgs e) { GetClickpictureBox(93); }
        private void pictureBox95_Click(object sender, EventArgs e) { GetClickpictureBox(94); }
        private void pictureBox96_Click(object sender, EventArgs e) { GetClickpictureBox(95); }
        private void pictureBox97_Click(object sender, EventArgs e) { GetClickpictureBox(96); }
        private void pictureBox98_Click(object sender, EventArgs e) { GetClickpictureBox(97); }
        private void pictureBox99_Click(object sender, EventArgs e) { GetClickpictureBox(98); }
        private void pictureBox100_Click(object sender, EventArgs e) { GetClickpictureBox(99); }
        private void pictureBox101_Click(object sender, EventArgs e) { GetClickpictureBox(100); }
        private void pictureBox102_Click(object sender, EventArgs e) { GetClickpictureBox(101); }
        private void pictureBox103_Click(object sender, EventArgs e) { GetClickpictureBox(102); }
        private void pictureBox104_Click(object sender, EventArgs e) { GetClickpictureBox(103); }
        private void pictureBox105_Click(object sender, EventArgs e) { GetClickpictureBox(104); }
        private void pictureBox106_Click(object sender, EventArgs e) { GetClickpictureBox(105); }
        private void pictureBox107_Click(object sender, EventArgs e) { GetClickpictureBox(106); }
        private void pictureBox108_Click(object sender, EventArgs e) { GetClickpictureBox(107); }
        private void pictureBox109_Click(object sender, EventArgs e) { GetClickpictureBox(108); }
        private void pictureBox110_Click(object sender, EventArgs e) { GetClickpictureBox(109); }

        private void pictureBox111_Click(object sender, EventArgs e) { GetClickpictureBox(110); }
        private void pictureBox112_Click(object sender, EventArgs e) { GetClickpictureBox(111); }
        private void pictureBox113_Click(object sender, EventArgs e) { GetClickpictureBox(112); }
        private void pictureBox114_Click(object sender, EventArgs e) { GetClickpictureBox(113); }
        private void pictureBox115_Click(object sender, EventArgs e) { GetClickpictureBox(114); }
        private void pictureBox116_Click(object sender, EventArgs e) { GetClickpictureBox(115); }
        private void pictureBox117_Click(object sender, EventArgs e) { GetClickpictureBox(116); }
        private void pictureBox118_Click(object sender, EventArgs e) { GetClickpictureBox(117); }
        private void pictureBox119_Click(object sender, EventArgs e) { GetClickpictureBox(118); }
        private void pictureBox120_Click(object sender, EventArgs e) { GetClickpictureBox(119); }

        private void pictureBox121_Click(object sender, EventArgs e) { GetClickpictureBox(120); }
        private void pictureBox122_Click(object sender, EventArgs e) { GetClickpictureBox(121); }
        private void pictureBox123_Click(object sender, EventArgs e) { GetClickpictureBox(122); }
        private void pictureBox124_Click(object sender, EventArgs e) { GetClickpictureBox(123); }
        private void pictureBox125_Click(object sender, EventArgs e) { GetClickpictureBox(124); }
        private void pictureBox126_Click(object sender, EventArgs e) { GetClickpictureBox(125); }
        private void pictureBox127_Click(object sender, EventArgs e) { GetClickpictureBox(126); }
        private void pictureBox128_Click(object sender, EventArgs e) { GetClickpictureBox(127); }
        private void pictureBox129_Click(object sender, EventArgs e) { GetClickpictureBox(128); }
        private void pictureBox130_Click(object sender, EventArgs e) { GetClickpictureBox(129); }

        private void pictureBox131_Click(object sender, EventArgs e) { GetClickpictureBox(130); }
        private void pictureBox132_Click(object sender, EventArgs e) { GetClickpictureBox(131); }
        private void pictureBox133_Click(object sender, EventArgs e) { GetClickpictureBox(132); }
        private void pictureBox134_Click(object sender, EventArgs e) { GetClickpictureBox(133); }
        private void pictureBox135_Click(object sender, EventArgs e) { GetClickpictureBox(134); }
        private void pictureBox136_Click(object sender, EventArgs e) { GetClickpictureBox(135); }
        private void pictureBox137_Click(object sender, EventArgs e) { GetClickpictureBox(136); }
        private void pictureBox138_Click(object sender, EventArgs e) { GetClickpictureBox(137); }
        private void pictureBox139_Click(object sender, EventArgs e) { GetClickpictureBox(138); }
        private void pictureBox140_Click(object sender, EventArgs e) { GetClickpictureBox(139); }

        private void pictureBox141_Click(object sender, EventArgs e) { GetClickpictureBox(140); }
        private void pictureBox142_Click(object sender, EventArgs e) { GetClickpictureBox(141); }
        private void pictureBox143_Click(object sender, EventArgs e) { GetClickpictureBox(142); }
        private void pictureBox144_Click(object sender, EventArgs e) { GetClickpictureBox(143); }
        private void pictureBox145_Click(object sender, EventArgs e) { GetClickpictureBox(144); }
        private void pictureBox146_Click(object sender, EventArgs e) { GetClickpictureBox(145); }
        private void pictureBox147_Click(object sender, EventArgs e) { GetClickpictureBox(146); }
        private void pictureBox148_Click(object sender, EventArgs e) { GetClickpictureBox(147); }
        private void pictureBox149_Click(object sender, EventArgs e) { GetClickpictureBox(148); }
        private void pictureBox150_Click(object sender, EventArgs e) { GetClickpictureBox(149); }

        private void pictureBox151_Click(object sender, EventArgs e) { GetClickpictureBox(150); }
        private void pictureBox152_Click(object sender, EventArgs e) { GetClickpictureBox(151); }
        private void pictureBox153_Click(object sender, EventArgs e) { GetClickpictureBox(152); }
        private void pictureBox154_Click(object sender, EventArgs e) { GetClickpictureBox(153); }
        private void pictureBox155_Click(object sender, EventArgs e) { GetClickpictureBox(154); }
        private void pictureBox156_Click(object sender, EventArgs e) { GetClickpictureBox(155); }
        private void pictureBox157_Click(object sender, EventArgs e) { GetClickpictureBox(156); }
        private void pictureBox158_Click(object sender, EventArgs e) { GetClickpictureBox(157); }
        private void pictureBox159_Click(object sender, EventArgs e) { GetClickpictureBox(158); }
        private void pictureBox160_Click(object sender, EventArgs e) { GetClickpictureBox(159); }

        private void pictureBox161_Click(object sender, EventArgs e) { GetClickpictureBox(160); }
        private void pictureBox162_Click(object sender, EventArgs e) { GetClickpictureBox(161); }
        private void pictureBox163_Click(object sender, EventArgs e) { GetClickpictureBox(162); }
        private void pictureBox164_Click(object sender, EventArgs e) { GetClickpictureBox(163); }
        private void pictureBox165_Click(object sender, EventArgs e) { GetClickpictureBox(164); }
        private void pictureBox166_Click(object sender, EventArgs e) { GetClickpictureBox(165); }
        private void pictureBox167_Click(object sender, EventArgs e) { GetClickpictureBox(166); }
        private void pictureBox168_Click(object sender, EventArgs e) { GetClickpictureBox(167); }
        private void pictureBox169_Click(object sender, EventArgs e) { GetClickpictureBox(168); }
        private void pictureBox170_Click(object sender, EventArgs e) { GetClickpictureBox(169); }

        private void pictureBox171_Click(object sender, EventArgs e) { GetClickpictureBox(170); }
        private void pictureBox172_Click(object sender, EventArgs e) { GetClickpictureBox(171); }
        private void pictureBox173_Click(object sender, EventArgs e) { GetClickpictureBox(172); }
        private void pictureBox174_Click(object sender, EventArgs e) { GetClickpictureBox(173); }
        private void pictureBox175_Click(object sender, EventArgs e) { GetClickpictureBox(174); }
        private void pictureBox176_Click(object sender, EventArgs e) { GetClickpictureBox(175); }
        private void pictureBox177_Click(object sender, EventArgs e) { GetClickpictureBox(176); }
        private void pictureBox178_Click(object sender, EventArgs e) { GetClickpictureBox(177); }
        private void pictureBox179_Click(object sender, EventArgs e) { GetClickpictureBox(178); }
        private void pictureBox180_Click(object sender, EventArgs e) { GetClickpictureBox(179); }

        private void pictureBox181_Click(object sender, EventArgs e) { GetClickpictureBox(180); }
        private void pictureBox182_Click(object sender, EventArgs e) { GetClickpictureBox(181); }
        private void pictureBox183_Click(object sender, EventArgs e) { GetClickpictureBox(182); }
        private void pictureBox184_Click(object sender, EventArgs e) { GetClickpictureBox(183); }
        private void pictureBox185_Click(object sender, EventArgs e) { GetClickpictureBox(184); }
        private void pictureBox186_Click(object sender, EventArgs e) { GetClickpictureBox(185); }
        private void pictureBox187_Click(object sender, EventArgs e) { GetClickpictureBox(186); }
        private void pictureBox188_Click(object sender, EventArgs e) { GetClickpictureBox(187); }
        private void pictureBox189_Click(object sender, EventArgs e) { GetClickpictureBox(188); }
        private void pictureBox190_Click(object sender, EventArgs e) { GetClickpictureBox(189); }
        
        private void pictureBox191_Click(object sender, EventArgs e) { GetClickpictureBox(190); }
        private void pictureBox192_Click(object sender, EventArgs e) { GetClickpictureBox(191); }
        private void pictureBox193_Click(object sender, EventArgs e) { GetClickpictureBox(192); }
        private void pictureBox194_Click(object sender, EventArgs e) { GetClickpictureBox(193); }
        private void pictureBox195_Click(object sender, EventArgs e) { GetClickpictureBox(194); }
        private void pictureBox196_Click(object sender, EventArgs e) { GetClickpictureBox(195); }
        private void pictureBox197_Click(object sender, EventArgs e) { GetClickpictureBox(196); }
        private void pictureBox198_Click(object sender, EventArgs e) { GetClickpictureBox(197); }
        private void pictureBox199_Click(object sender, EventArgs e) { GetClickpictureBox(198); }
        private void pictureBox200_Click(object sender, EventArgs e) { GetClickpictureBox(199); }

        private void pictureBox201_Click(object sender, EventArgs e) { GetClickpictureBox(200); }
        private void pictureBox202_Click(object sender, EventArgs e) { GetClickpictureBox(201); }
        private void pictureBox203_Click(object sender, EventArgs e) { GetClickpictureBox(202); }
        private void pictureBox204_Click(object sender, EventArgs e) { GetClickpictureBox(203); }
        private void pictureBox205_Click(object sender, EventArgs e) { GetClickpictureBox(204); }
        private void pictureBox206_Click(object sender, EventArgs e) { GetClickpictureBox(205); }
        private void pictureBox207_Click(object sender, EventArgs e) { GetClickpictureBox(206); }
        private void pictureBox208_Click(object sender, EventArgs e) { GetClickpictureBox(207); }
        private void pictureBox209_Click(object sender, EventArgs e) { GetClickpictureBox(208); }
        private void pictureBox210_Click(object sender, EventArgs e) { GetClickpictureBox(209); }

        private void pictureBox211_Click(object sender, EventArgs e) { GetClickpictureBox(210); }
        private void pictureBox212_Click(object sender, EventArgs e) { GetClickpictureBox(211); }
        private void pictureBox213_Click(object sender, EventArgs e) { GetClickpictureBox(212); }
        private void pictureBox214_Click(object sender, EventArgs e) { GetClickpictureBox(213); }
        private void pictureBox215_Click(object sender, EventArgs e) { GetClickpictureBox(214); }
        private void pictureBox216_Click(object sender, EventArgs e) { GetClickpictureBox(215); }
        private void pictureBox217_Click(object sender, EventArgs e) { GetClickpictureBox(216); }
        private void pictureBox218_Click(object sender, EventArgs e) { GetClickpictureBox(217); }
        private void pictureBox219_Click(object sender, EventArgs e) { GetClickpictureBox(218); }
        private void pictureBox220_Click(object sender, EventArgs e) { GetClickpictureBox(219); }

        private void pictureBox221_Click(object sender, EventArgs e) { GetClickpictureBox(220); }
        private void pictureBox222_Click(object sender, EventArgs e) { GetClickpictureBox(221); }
        private void pictureBox223_Click(object sender, EventArgs e) { GetClickpictureBox(222); }
        private void pictureBox224_Click(object sender, EventArgs e) { GetClickpictureBox(223); }
        private void pictureBox225_Click(object sender, EventArgs e) { GetClickpictureBox(224); }


        #endregion

        Image img;

        private void GetClickpictureBox(int j)
        {
            int computer_next_move;
            _pictureBox[j].SizeMode = PictureBoxSizeMode.StretchImage;            
            string appPath = System.Windows.Forms.Application.StartupPath;            
            if (i % 2 == 0) 
            { 
                img = Image.FromFile(appPath + @"\black.png");
            }
            else { img = Image.FromFile(appPath + @"\white.png"); }
            if (_pictureBox[j].Image == null)
            {
                _pictureBox[j].Image = img;
                if (i % 2 == 0)
                {
                    CheckBoard[j / 15, j % 15] = Constant.BLACKCHESS;
                    getwinner = WinJudgment.FINDWINNER(CheckBoard, Constant.BLACKCHESS);
                }
                else
                {
                    CheckBoard[j / 15, j % 15] = Constant.WHITECHESS;
                    getwinner = WinJudgment.FINDWINNER(CheckBoard, Constant.WHITECHESS);
                }

                if (getwinner)
                {
                    if(i % 2==0)
                        MessageBox.Show("The winner is the PLayer!!! OHHH GUESS WHAT?? It's YOU!!!");
                    else
                        MessageBox.Show("UH-OH...The winner is the COMPUTER!!!");
                    System.Environment.Exit(0);
                }
                else
                {
                    computer_next_move = GobangComputer.Instance.ComputerMethod(CheckBoard, j);
                    i++;
                    if (i % 2 == 1)
                        automove(computer_next_move);
                }

            }
            if(i==225&&(!getwinner))
                MessageBox.Show("OHHH! TOUGH CALL!!! IT'S A TIE!!!");
        }

        public void automove(int num)
        {
            switch(num)
            {
                case 0: GetClickpictureBox(num); break;  
                case 1: GetClickpictureBox(num); break;   
                case 2: GetClickpictureBox(num); break;  
                case 3: GetClickpictureBox(num); break;  
                case 4: GetClickpictureBox(num); break;  
                case 5: GetClickpictureBox(num); break;   
                case 6: GetClickpictureBox(num); break; 
                case 7: GetClickpictureBox(num); break; 
                case 8: GetClickpictureBox(num); break;  
                case 9: GetClickpictureBox(num); break;  
                case 10: GetClickpictureBox(num); break;
                case 11: GetClickpictureBox(num); break; 
                case 12: GetClickpictureBox(num); break;  
                case 13: GetClickpictureBox(num); break; 
                case 14: GetClickpictureBox(num); break; 
                case 15: GetClickpictureBox(num); break; 
                case 16: GetClickpictureBox(num); break;
                case 17: GetClickpictureBox(num); break; 
                case 18: GetClickpictureBox(num); break; 
                case 19: GetClickpictureBox(num); break;
                case 20: GetClickpictureBox(num); break;
                case 21: GetClickpictureBox(num); break; 
                case 22: GetClickpictureBox(num); break; 
                case 23: GetClickpictureBox(num); break; 
                case 24: GetClickpictureBox(num); break; 
                case 25: GetClickpictureBox(num); break; 
                case 26: GetClickpictureBox(num); break; 
                case 27: GetClickpictureBox(num); break; 
                case 28: GetClickpictureBox(num); break; 
                case 29: GetClickpictureBox(num); break; 
                case 30: GetClickpictureBox(num); break;
                case 31: GetClickpictureBox(num); break; 
                case 32: GetClickpictureBox(num); break;  
                case 33: GetClickpictureBox(num); break; 
                case 34: GetClickpictureBox(num); break; 
                case 35: GetClickpictureBox(num); break; 
                case 36: GetClickpictureBox(num); break; 
                case 37: GetClickpictureBox(num); break; 
                case 38: GetClickpictureBox(num); break;
                case 39: GetClickpictureBox(num); break; 
                case 40: GetClickpictureBox(num); break;
                case 41: GetClickpictureBox(num); break;
                case 42: GetClickpictureBox(num); break; 
                case 43: GetClickpictureBox(num); break; 
                case 44: GetClickpictureBox(num); break; 
                case 45: GetClickpictureBox(num); break; 
                case 46: GetClickpictureBox(num); break; 
                case 47: GetClickpictureBox(num); break; 
                case 48: GetClickpictureBox(num); break; 
                case 49: GetClickpictureBox(num); break;  
                case 50: GetClickpictureBox(num); break;
                case 51: GetClickpictureBox(num); break;
                case 52: GetClickpictureBox(num); break;
                case 53: GetClickpictureBox(num); break;
                case 54: GetClickpictureBox(num); break;
                case 55: GetClickpictureBox(num); break;
                case 56: GetClickpictureBox(num); break;
                case 57: GetClickpictureBox(num); break;
                case 58: GetClickpictureBox(num); break;
                case 59: GetClickpictureBox(num); break;
                case 60: GetClickpictureBox(num); break;
                case 61: GetClickpictureBox(num); break;
                case 62: GetClickpictureBox(num); break;
                case 63: GetClickpictureBox(num); break;
                case 64: GetClickpictureBox(num); break;
                case 65: GetClickpictureBox(num); break;
                case 66: GetClickpictureBox(num); break;
                case 67: GetClickpictureBox(num); break;
                case 68: GetClickpictureBox(num); break;
                case 69: GetClickpictureBox(num); break;
                case 70: GetClickpictureBox(num); break;
                case 71: GetClickpictureBox(num); break;
                case 72: GetClickpictureBox(num); break;
                case 73: GetClickpictureBox(num); break;
                case 74: GetClickpictureBox(num); break;
                case 75: GetClickpictureBox(num); break;
                case 76: GetClickpictureBox(num); break;
                case 77: GetClickpictureBox(num); break;
                case 78: GetClickpictureBox(num); break;
                case 79: GetClickpictureBox(num); break;
                case 80: GetClickpictureBox(num); break;
                case 81: GetClickpictureBox(num); break;
                case 82: GetClickpictureBox(num); break;
                case 83: GetClickpictureBox(num); break;
                case 84: GetClickpictureBox(num); break;
                case 85: GetClickpictureBox(num); break;
                case 86: GetClickpictureBox(num); break;
                case 87: GetClickpictureBox(num); break;
                case 88: GetClickpictureBox(num); break;
                case 89: GetClickpictureBox(num); break;
                case 90: GetClickpictureBox(num); break;
                case 91: GetClickpictureBox(num); break;
                case 92: GetClickpictureBox(num); break;
                case 93: GetClickpictureBox(num); break;
                case 94: GetClickpictureBox(num); break;
                case 95: GetClickpictureBox(num); break;
                case 96: GetClickpictureBox(num); break;
                case 97: GetClickpictureBox(num); break;
                case 98: GetClickpictureBox(num); break;
                case 99: GetClickpictureBox(num); break;
                case 100: GetClickpictureBox(num); break;
                case 101: GetClickpictureBox(num); break;
                case 102: GetClickpictureBox(num); break;
                case 103: GetClickpictureBox(num); break;
                case 104: GetClickpictureBox(num); break;
                case 105: GetClickpictureBox(num); break;
                case 106: GetClickpictureBox(num); break;
                case 107: GetClickpictureBox(num); break;
                case 108: GetClickpictureBox(num); break;
                case 109: GetClickpictureBox(num); break;
                case 110: GetClickpictureBox(num); break;
                case 111: GetClickpictureBox(num); break;
                case 112: GetClickpictureBox(num); break;
                case 113: GetClickpictureBox(num); break;
                case 114: GetClickpictureBox(num); break;
                case 115: GetClickpictureBox(num); break;
                case 116: GetClickpictureBox(num); break;
                case 117: GetClickpictureBox(num); break;
                case 118: GetClickpictureBox(num); break;
                case 119: GetClickpictureBox(num); break;
                case 120: GetClickpictureBox(num); break;
                case 121: GetClickpictureBox(num); break;
                case 122: GetClickpictureBox(num); break;
                case 123: GetClickpictureBox(num); break;
                case 124: GetClickpictureBox(num); break;
                case 125: GetClickpictureBox(num); break;
                case 126: GetClickpictureBox(num); break;
                case 127: GetClickpictureBox(num); break;
                case 128: GetClickpictureBox(num); break;
                case 129: GetClickpictureBox(num); break;
                case 130: GetClickpictureBox(num); break;
                case 131: GetClickpictureBox(num); break;
                case 132: GetClickpictureBox(num); break;
                case 133: GetClickpictureBox(num); break;
                case 134: GetClickpictureBox(num); break;
                case 135: GetClickpictureBox(num); break;
                case 136: GetClickpictureBox(num); break;
                case 137: GetClickpictureBox(num); break;
                case 138: GetClickpictureBox(num); break;
                case 139: GetClickpictureBox(num); break;
                case 140: GetClickpictureBox(num); break;
                case 141: GetClickpictureBox(num); break;
                case 142: GetClickpictureBox(num); break;
                case 143: GetClickpictureBox(num); break;
                case 144: GetClickpictureBox(num); break;
                case 145: GetClickpictureBox(num); break;
                case 146: GetClickpictureBox(num); break;
                case 147: GetClickpictureBox(num); break;
                case 148: GetClickpictureBox(num); break;
                case 149: GetClickpictureBox(num); break;
                case 150: GetClickpictureBox(num); break;
                case 151: GetClickpictureBox(num); break;
                case 152: GetClickpictureBox(num); break;
                case 153: GetClickpictureBox(num); break;
                case 154: GetClickpictureBox(num); break;
                case 155: GetClickpictureBox(num); break;
                case 156: GetClickpictureBox(num); break;
                case 157: GetClickpictureBox(num); break;
                case 158: GetClickpictureBox(num); break;
                case 159: GetClickpictureBox(num); break;
                case 160: GetClickpictureBox(num); break;
                case 161: GetClickpictureBox(num); break;
                case 162: GetClickpictureBox(num); break;
                case 163: GetClickpictureBox(num); break;
                case 164: GetClickpictureBox(num); break;
                case 165: GetClickpictureBox(num); break;
                case 166: GetClickpictureBox(num); break;
                case 167: GetClickpictureBox(num); break;
                case 168: GetClickpictureBox(num); break;
                case 169: GetClickpictureBox(num); break;
                case 170: GetClickpictureBox(num); break;
                case 171: GetClickpictureBox(num); break;
                case 172: GetClickpictureBox(num); break;
                case 173: GetClickpictureBox(num); break;
                case 174: GetClickpictureBox(num); break;
                case 175: GetClickpictureBox(num); break;
                case 176: GetClickpictureBox(num); break;
                case 177: GetClickpictureBox(num); break;
                case 178: GetClickpictureBox(num); break;
                case 179: GetClickpictureBox(num); break;
                case 180: GetClickpictureBox(num); break;
                case 181: GetClickpictureBox(num); break;
                case 182: GetClickpictureBox(num); break;
                case 183: GetClickpictureBox(num); break;
                case 184: GetClickpictureBox(num); break;
                case 185: GetClickpictureBox(num); break;
                case 186: GetClickpictureBox(num); break;
                case 187: GetClickpictureBox(num); break;
                case 188: GetClickpictureBox(num); break;
                case 189: GetClickpictureBox(num); break;
                case 190: GetClickpictureBox(num); break;
                case 191: GetClickpictureBox(num); break;
                case 192: GetClickpictureBox(num); break;
                case 193: GetClickpictureBox(num); break;
                case 194: GetClickpictureBox(num); break;
                case 195: GetClickpictureBox(num); break;
                case 196: GetClickpictureBox(num); break;
                case 197: GetClickpictureBox(num); break;
                case 198: GetClickpictureBox(num); break;
                case 199: GetClickpictureBox(num); break;
                case 200: GetClickpictureBox(num); break;
                case 201: GetClickpictureBox(num); break;
                case 202: GetClickpictureBox(num); break;
                case 203: GetClickpictureBox(num); break;
                case 204: GetClickpictureBox(num); break;
                case 205: GetClickpictureBox(num); break;
                case 206: GetClickpictureBox(num); break;
                case 207: GetClickpictureBox(num); break;
                case 208: GetClickpictureBox(num); break;
                case 209: GetClickpictureBox(num); break;
                case 210: GetClickpictureBox(num); break;
                case 211: GetClickpictureBox(num); break;
                case 212: GetClickpictureBox(num); break;
                case 213: GetClickpictureBox(num); break;
                case 214: GetClickpictureBox(num); break;
                case 215: GetClickpictureBox(num); break;
                case 216: GetClickpictureBox(num); break;
                case 217: GetClickpictureBox(num); break;
                case 218: GetClickpictureBox(num); break;
                case 219: GetClickpictureBox(num); break;
                case 220: GetClickpictureBox(num); break;
                case 221: GetClickpictureBox(num); break;
                case 222: GetClickpictureBox(num); break;
                case 223: GetClickpictureBox(num); break;
                case 224: GetClickpictureBox(num); break;

            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.button1.Enabled = false;
            this.button3.Enabled = true;
            this.tableLayoutPanel1.Enabled = true;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            System.Environment.Exit(0);
        }

    }
    // 胜利判断
    class WinJudgment
    {
        // identify the chess belonged
        public static bool FINDWINNER(int[,] CheckBoard, int Judgment)
        {
            bool Win = false;         // initially set no winners
            // Loop through
            for (int i = 0; i < Constant.SIZE_CHESSBOARD; i++)
            {
                for (int j = 0; j < Constant.SIZE_CHESSBOARD; j++)
                {
                    if (CheckBoard[j, i] == Judgment)
                    {
                        if (j < 11)
                        {//check for horizontal
                            if (CheckBoard[j + 1, i] == Judgment && CheckBoard[j + 2, i] == Judgment && CheckBoard[j + 3, i] == Judgment && CheckBoard[j + 4, i] == Judgment)
                            {
                                Win = true;
                                return Win;
                            }
                        }
                        //check for vertical
                        if (i < 11)
                            if (CheckBoard[j, i + 1] == Judgment && CheckBoard[j, i + 2] == Judgment && CheckBoard[j, i + 3] == Judgment && CheckBoard[j, i + 4] == Judgment)
                            {
                                Win = true;
                                return Win;
                            }

                        // one diagonal
                        if (j < 11 && i < 11)
                            if (CheckBoard[j + 1, i + 1] == Judgment && CheckBoard[j + 2, i + 2] == Judgment && CheckBoard[j + 3, i + 3] == Judgment && CheckBoard[j + 4, i + 4] == Judgment)
                            {
                                Win = true;
                                return Win;
                            }

                                // another diagonal
                        if (j > 3 && i < 11)
                            if (CheckBoard[j - 1, i + 1] == Judgment && CheckBoard[j - 2, i + 2] == Judgment && CheckBoard[j - 3, i + 3] == Judgment && CheckBoard[j - 4, i + 4] == Judgment)
                            {
                                Win = true;
                                return Win;
                            }
                    }
                }
            }
            return Win;
        }
    }//winJudgement
}
