﻿namespace Gobang_Melinda
{
    partial class Gobang
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.pictureBox6 = new System.Windows.Forms.PictureBox();
            this.pictureBox7 = new System.Windows.Forms.PictureBox();
            this.pictureBox8 = new System.Windows.Forms.PictureBox();
            this.pictureBox9 = new System.Windows.Forms.PictureBox();
            this.pictureBox10 = new System.Windows.Forms.PictureBox();
            this.pictureBox11 = new System.Windows.Forms.PictureBox();
            this.pictureBox12 = new System.Windows.Forms.PictureBox();
            this.pictureBox13 = new System.Windows.Forms.PictureBox();
            this.pictureBox14 = new System.Windows.Forms.PictureBox();
            this.pictureBox15 = new System.Windows.Forms.PictureBox();
            this.pictureBox16 = new System.Windows.Forms.PictureBox();
            this.pictureBox17 = new System.Windows.Forms.PictureBox();
            this.pictureBox18 = new System.Windows.Forms.PictureBox();
            this.pictureBox19 = new System.Windows.Forms.PictureBox();
            this.pictureBox20 = new System.Windows.Forms.PictureBox();
            this.pictureBox21 = new System.Windows.Forms.PictureBox();
            this.pictureBox22 = new System.Windows.Forms.PictureBox();
            this.pictureBox23 = new System.Windows.Forms.PictureBox();
            this.pictureBox24 = new System.Windows.Forms.PictureBox();
            this.pictureBox25 = new System.Windows.Forms.PictureBox();
            this.pictureBox26 = new System.Windows.Forms.PictureBox();
            this.pictureBox27 = new System.Windows.Forms.PictureBox();
            this.pictureBox28 = new System.Windows.Forms.PictureBox();
            this.pictureBox29 = new System.Windows.Forms.PictureBox();
            this.pictureBox30 = new System.Windows.Forms.PictureBox();
            this.pictureBox31 = new System.Windows.Forms.PictureBox();
            this.pictureBox32 = new System.Windows.Forms.PictureBox();
            this.pictureBox33 = new System.Windows.Forms.PictureBox();
            this.pictureBox34 = new System.Windows.Forms.PictureBox();
            this.pictureBox35 = new System.Windows.Forms.PictureBox();
            this.pictureBox36 = new System.Windows.Forms.PictureBox();
            this.pictureBox37 = new System.Windows.Forms.PictureBox();
            this.pictureBox38 = new System.Windows.Forms.PictureBox();
            this.pictureBox39 = new System.Windows.Forms.PictureBox();
            this.pictureBox40 = new System.Windows.Forms.PictureBox();
            this.pictureBox41 = new System.Windows.Forms.PictureBox();
            this.pictureBox42 = new System.Windows.Forms.PictureBox();
            this.pictureBox43 = new System.Windows.Forms.PictureBox();
            this.pictureBox44 = new System.Windows.Forms.PictureBox();
            this.pictureBox45 = new System.Windows.Forms.PictureBox();
            this.pictureBox46 = new System.Windows.Forms.PictureBox();
            this.pictureBox47 = new System.Windows.Forms.PictureBox();
            this.pictureBox48 = new System.Windows.Forms.PictureBox();
            this.pictureBox49 = new System.Windows.Forms.PictureBox();
            this.pictureBox50 = new System.Windows.Forms.PictureBox();
            this.pictureBox51 = new System.Windows.Forms.PictureBox();
            this.pictureBox52 = new System.Windows.Forms.PictureBox();
            this.pictureBox53 = new System.Windows.Forms.PictureBox();
            this.pictureBox54 = new System.Windows.Forms.PictureBox();
            this.pictureBox55 = new System.Windows.Forms.PictureBox();
            this.pictureBox56 = new System.Windows.Forms.PictureBox();
            this.pictureBox57 = new System.Windows.Forms.PictureBox();
            this.pictureBox58 = new System.Windows.Forms.PictureBox();
            this.pictureBox59 = new System.Windows.Forms.PictureBox();
            this.pictureBox60 = new System.Windows.Forms.PictureBox();
            this.pictureBox61 = new System.Windows.Forms.PictureBox();
            this.pictureBox62 = new System.Windows.Forms.PictureBox();
            this.pictureBox63 = new System.Windows.Forms.PictureBox();
            this.pictureBox64 = new System.Windows.Forms.PictureBox();
            this.pictureBox65 = new System.Windows.Forms.PictureBox();
            this.pictureBox66 = new System.Windows.Forms.PictureBox();
            this.pictureBox67 = new System.Windows.Forms.PictureBox();
            this.pictureBox68 = new System.Windows.Forms.PictureBox();
            this.pictureBox69 = new System.Windows.Forms.PictureBox();
            this.pictureBox70 = new System.Windows.Forms.PictureBox();
            this.pictureBox71 = new System.Windows.Forms.PictureBox();
            this.pictureBox72 = new System.Windows.Forms.PictureBox();
            this.pictureBox73 = new System.Windows.Forms.PictureBox();
            this.pictureBox74 = new System.Windows.Forms.PictureBox();
            this.pictureBox75 = new System.Windows.Forms.PictureBox();
            this.pictureBox76 = new System.Windows.Forms.PictureBox();
            this.pictureBox77 = new System.Windows.Forms.PictureBox();
            this.pictureBox78 = new System.Windows.Forms.PictureBox();
            this.pictureBox79 = new System.Windows.Forms.PictureBox();
            this.pictureBox80 = new System.Windows.Forms.PictureBox();
            this.pictureBox81 = new System.Windows.Forms.PictureBox();
            this.pictureBox82 = new System.Windows.Forms.PictureBox();
            this.pictureBox83 = new System.Windows.Forms.PictureBox();
            this.pictureBox84 = new System.Windows.Forms.PictureBox();
            this.pictureBox85 = new System.Windows.Forms.PictureBox();
            this.pictureBox86 = new System.Windows.Forms.PictureBox();
            this.pictureBox87 = new System.Windows.Forms.PictureBox();
            this.pictureBox88 = new System.Windows.Forms.PictureBox();
            this.pictureBox89 = new System.Windows.Forms.PictureBox();
            this.pictureBox90 = new System.Windows.Forms.PictureBox();
            this.pictureBox91 = new System.Windows.Forms.PictureBox();
            this.pictureBox92 = new System.Windows.Forms.PictureBox();
            this.pictureBox93 = new System.Windows.Forms.PictureBox();
            this.pictureBox94 = new System.Windows.Forms.PictureBox();
            this.pictureBox95 = new System.Windows.Forms.PictureBox();
            this.pictureBox96 = new System.Windows.Forms.PictureBox();
            this.pictureBox97 = new System.Windows.Forms.PictureBox();
            this.pictureBox98 = new System.Windows.Forms.PictureBox();
            this.pictureBox99 = new System.Windows.Forms.PictureBox();
            this.pictureBox100 = new System.Windows.Forms.PictureBox();
            this.pictureBox101 = new System.Windows.Forms.PictureBox();
            this.pictureBox102 = new System.Windows.Forms.PictureBox();
            this.pictureBox103 = new System.Windows.Forms.PictureBox();
            this.pictureBox104 = new System.Windows.Forms.PictureBox();
            this.pictureBox105 = new System.Windows.Forms.PictureBox();
            this.pictureBox106 = new System.Windows.Forms.PictureBox();
            this.pictureBox107 = new System.Windows.Forms.PictureBox();
            this.pictureBox108 = new System.Windows.Forms.PictureBox();
            this.pictureBox109 = new System.Windows.Forms.PictureBox();
            this.pictureBox110 = new System.Windows.Forms.PictureBox();
            this.pictureBox111 = new System.Windows.Forms.PictureBox();
            this.pictureBox112 = new System.Windows.Forms.PictureBox();
            this.pictureBox113 = new System.Windows.Forms.PictureBox();
            this.pictureBox114 = new System.Windows.Forms.PictureBox();
            this.pictureBox115 = new System.Windows.Forms.PictureBox();
            this.pictureBox116 = new System.Windows.Forms.PictureBox();
            this.pictureBox117 = new System.Windows.Forms.PictureBox();
            this.pictureBox118 = new System.Windows.Forms.PictureBox();
            this.pictureBox119 = new System.Windows.Forms.PictureBox();
            this.pictureBox120 = new System.Windows.Forms.PictureBox();
            this.pictureBox121 = new System.Windows.Forms.PictureBox();
            this.pictureBox122 = new System.Windows.Forms.PictureBox();
            this.pictureBox123 = new System.Windows.Forms.PictureBox();
            this.pictureBox124 = new System.Windows.Forms.PictureBox();
            this.pictureBox125 = new System.Windows.Forms.PictureBox();
            this.pictureBox126 = new System.Windows.Forms.PictureBox();
            this.pictureBox127 = new System.Windows.Forms.PictureBox();
            this.pictureBox128 = new System.Windows.Forms.PictureBox();
            this.pictureBox129 = new System.Windows.Forms.PictureBox();
            this.pictureBox130 = new System.Windows.Forms.PictureBox();
            this.pictureBox131 = new System.Windows.Forms.PictureBox();
            this.pictureBox132 = new System.Windows.Forms.PictureBox();
            this.pictureBox133 = new System.Windows.Forms.PictureBox();
            this.pictureBox134 = new System.Windows.Forms.PictureBox();
            this.pictureBox135 = new System.Windows.Forms.PictureBox();
            this.pictureBox136 = new System.Windows.Forms.PictureBox();
            this.pictureBox137 = new System.Windows.Forms.PictureBox();
            this.pictureBox138 = new System.Windows.Forms.PictureBox();
            this.pictureBox139 = new System.Windows.Forms.PictureBox();
            this.pictureBox140 = new System.Windows.Forms.PictureBox();
            this.pictureBox141 = new System.Windows.Forms.PictureBox();
            this.pictureBox142 = new System.Windows.Forms.PictureBox();
            this.pictureBox143 = new System.Windows.Forms.PictureBox();
            this.pictureBox144 = new System.Windows.Forms.PictureBox();
            this.pictureBox145 = new System.Windows.Forms.PictureBox();
            this.pictureBox146 = new System.Windows.Forms.PictureBox();
            this.pictureBox147 = new System.Windows.Forms.PictureBox();
            this.pictureBox148 = new System.Windows.Forms.PictureBox();
            this.pictureBox149 = new System.Windows.Forms.PictureBox();
            this.pictureBox150 = new System.Windows.Forms.PictureBox();
            this.pictureBox151 = new System.Windows.Forms.PictureBox();
            this.pictureBox152 = new System.Windows.Forms.PictureBox();
            this.pictureBox153 = new System.Windows.Forms.PictureBox();
            this.pictureBox154 = new System.Windows.Forms.PictureBox();
            this.pictureBox155 = new System.Windows.Forms.PictureBox();
            this.pictureBox156 = new System.Windows.Forms.PictureBox();
            this.pictureBox157 = new System.Windows.Forms.PictureBox();
            this.pictureBox158 = new System.Windows.Forms.PictureBox();
            this.pictureBox159 = new System.Windows.Forms.PictureBox();
            this.pictureBox160 = new System.Windows.Forms.PictureBox();
            this.pictureBox161 = new System.Windows.Forms.PictureBox();
            this.pictureBox162 = new System.Windows.Forms.PictureBox();
            this.pictureBox163 = new System.Windows.Forms.PictureBox();
            this.pictureBox164 = new System.Windows.Forms.PictureBox();
            this.pictureBox165 = new System.Windows.Forms.PictureBox();
            this.pictureBox166 = new System.Windows.Forms.PictureBox();
            this.pictureBox167 = new System.Windows.Forms.PictureBox();
            this.pictureBox168 = new System.Windows.Forms.PictureBox();
            this.pictureBox169 = new System.Windows.Forms.PictureBox();
            this.pictureBox170 = new System.Windows.Forms.PictureBox();
            this.pictureBox171 = new System.Windows.Forms.PictureBox();
            this.pictureBox172 = new System.Windows.Forms.PictureBox();
            this.pictureBox173 = new System.Windows.Forms.PictureBox();
            this.pictureBox174 = new System.Windows.Forms.PictureBox();
            this.pictureBox175 = new System.Windows.Forms.PictureBox();
            this.pictureBox176 = new System.Windows.Forms.PictureBox();
            this.pictureBox177 = new System.Windows.Forms.PictureBox();
            this.pictureBox178 = new System.Windows.Forms.PictureBox();
            this.pictureBox179 = new System.Windows.Forms.PictureBox();
            this.pictureBox180 = new System.Windows.Forms.PictureBox();
            this.pictureBox181 = new System.Windows.Forms.PictureBox();
            this.pictureBox182 = new System.Windows.Forms.PictureBox();
            this.pictureBox183 = new System.Windows.Forms.PictureBox();
            this.pictureBox184 = new System.Windows.Forms.PictureBox();
            this.pictureBox185 = new System.Windows.Forms.PictureBox();
            this.pictureBox186 = new System.Windows.Forms.PictureBox();
            this.pictureBox187 = new System.Windows.Forms.PictureBox();
            this.pictureBox188 = new System.Windows.Forms.PictureBox();
            this.pictureBox189 = new System.Windows.Forms.PictureBox();
            this.pictureBox190 = new System.Windows.Forms.PictureBox();
            this.pictureBox191 = new System.Windows.Forms.PictureBox();
            this.pictureBox192 = new System.Windows.Forms.PictureBox();
            this.pictureBox193 = new System.Windows.Forms.PictureBox();
            this.pictureBox194 = new System.Windows.Forms.PictureBox();
            this.pictureBox195 = new System.Windows.Forms.PictureBox();
            this.pictureBox196 = new System.Windows.Forms.PictureBox();
            this.pictureBox197 = new System.Windows.Forms.PictureBox();
            this.pictureBox198 = new System.Windows.Forms.PictureBox();
            this.pictureBox199 = new System.Windows.Forms.PictureBox();
            this.pictureBox200 = new System.Windows.Forms.PictureBox();
            this.pictureBox201 = new System.Windows.Forms.PictureBox();
            this.pictureBox202 = new System.Windows.Forms.PictureBox();
            this.pictureBox203 = new System.Windows.Forms.PictureBox();
            this.pictureBox204 = new System.Windows.Forms.PictureBox();
            this.pictureBox205 = new System.Windows.Forms.PictureBox();
            this.pictureBox206 = new System.Windows.Forms.PictureBox();
            this.pictureBox207 = new System.Windows.Forms.PictureBox();
            this.pictureBox208 = new System.Windows.Forms.PictureBox();
            this.pictureBox209 = new System.Windows.Forms.PictureBox();
            this.pictureBox210 = new System.Windows.Forms.PictureBox();
            this.pictureBox211 = new System.Windows.Forms.PictureBox();
            this.pictureBox212 = new System.Windows.Forms.PictureBox();
            this.pictureBox213 = new System.Windows.Forms.PictureBox();
            this.pictureBox214 = new System.Windows.Forms.PictureBox();
            this.pictureBox215 = new System.Windows.Forms.PictureBox();
            this.pictureBox216 = new System.Windows.Forms.PictureBox();
            this.pictureBox217 = new System.Windows.Forms.PictureBox();
            this.pictureBox218 = new System.Windows.Forms.PictureBox();
            this.pictureBox219 = new System.Windows.Forms.PictureBox();
            this.pictureBox220 = new System.Windows.Forms.PictureBox();
            this.pictureBox221 = new System.Windows.Forms.PictureBox();
            this.pictureBox222 = new System.Windows.Forms.PictureBox();
            this.pictureBox223 = new System.Windows.Forms.PictureBox();
            this.pictureBox224 = new System.Windows.Forms.PictureBox();
            this.pictureBox225 = new System.Windows.Forms.PictureBox();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.tableLayoutPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox11)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox12)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox13)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox14)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox15)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox16)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox17)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox18)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox19)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox20)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox21)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox22)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox23)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox24)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox25)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox26)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox27)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox28)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox29)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox30)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox31)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox32)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox33)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox34)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox35)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox36)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox37)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox38)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox39)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox40)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox41)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox42)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox43)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox44)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox45)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox46)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox47)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox48)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox49)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox50)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox51)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox52)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox53)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox54)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox55)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox56)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox57)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox58)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox59)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox60)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox61)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox62)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox63)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox64)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox65)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox66)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox67)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox68)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox69)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox70)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox71)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox72)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox73)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox74)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox75)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox76)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox77)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox78)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox79)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox80)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox81)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox82)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox83)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox84)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox85)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox86)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox87)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox88)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox89)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox90)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox91)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox92)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox93)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox94)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox95)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox96)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox97)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox98)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox99)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox100)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox101)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox102)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox103)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox104)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox105)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox106)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox107)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox108)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox109)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox110)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox111)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox112)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox113)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox114)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox115)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox116)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox117)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox118)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox119)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox120)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox121)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox122)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox123)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox124)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox125)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox126)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox127)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox128)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox129)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox130)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox131)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox132)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox133)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox134)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox135)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox136)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox137)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox138)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox139)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox140)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox141)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox142)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox143)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox144)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox145)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox146)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox147)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox148)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox149)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox150)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox151)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox152)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox153)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox154)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox155)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox156)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox157)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox158)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox159)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox160)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox161)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox162)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox163)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox164)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox165)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox166)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox167)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox168)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox169)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox170)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox171)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox172)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox173)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox174)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox175)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox176)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox177)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox178)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox179)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox180)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox181)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox182)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox183)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox184)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox185)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox186)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox187)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox188)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox189)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox190)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox191)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox192)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox193)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox194)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox195)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox196)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox197)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox198)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox199)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox200)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox201)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox202)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox203)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox204)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox205)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox206)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox207)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox208)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox209)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox210)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox211)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox212)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox213)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox214)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox215)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox216)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox217)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox218)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox219)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox220)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox221)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox222)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox223)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox224)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox225)).BeginInit();
            this.SuspendLayout();
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.tableLayoutPanel1.BackColor = System.Drawing.Color.Transparent;
            this.tableLayoutPanel1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.tableLayoutPanel1.ColumnCount = 15;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 59F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 59F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 59F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 59F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 61F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 58F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 63F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 67F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 59F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 59F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 63F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 61F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 63F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 56F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 62F));
            this.tableLayoutPanel1.Controls.Add(this.pictureBox1, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.pictureBox2, 1, 0);
            this.tableLayoutPanel1.Controls.Add(this.pictureBox3, 2, 0);
            this.tableLayoutPanel1.Controls.Add(this.pictureBox4, 3, 0);
            this.tableLayoutPanel1.Controls.Add(this.pictureBox5, 4, 0);
            this.tableLayoutPanel1.Controls.Add(this.pictureBox6, 5, 0);
            this.tableLayoutPanel1.Controls.Add(this.pictureBox7, 6, 0);
            this.tableLayoutPanel1.Controls.Add(this.pictureBox8, 7, 0);
            this.tableLayoutPanel1.Controls.Add(this.pictureBox9, 8, 0);
            this.tableLayoutPanel1.Controls.Add(this.pictureBox10, 9, 0);
            this.tableLayoutPanel1.Controls.Add(this.pictureBox11, 10, 0);
            this.tableLayoutPanel1.Controls.Add(this.pictureBox12, 11, 0);
            this.tableLayoutPanel1.Controls.Add(this.pictureBox13, 12, 0);
            this.tableLayoutPanel1.Controls.Add(this.pictureBox14, 13, 0);
            this.tableLayoutPanel1.Controls.Add(this.pictureBox15, 14, 0);
            this.tableLayoutPanel1.Controls.Add(this.pictureBox16, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.pictureBox17, 1, 1);
            this.tableLayoutPanel1.Controls.Add(this.pictureBox18, 2, 1);
            this.tableLayoutPanel1.Controls.Add(this.pictureBox19, 3, 1);
            this.tableLayoutPanel1.Controls.Add(this.pictureBox20, 4, 1);
            this.tableLayoutPanel1.Controls.Add(this.pictureBox21, 5, 1);
            this.tableLayoutPanel1.Controls.Add(this.pictureBox22, 6, 1);
            this.tableLayoutPanel1.Controls.Add(this.pictureBox23, 7, 1);
            this.tableLayoutPanel1.Controls.Add(this.pictureBox24, 8, 1);
            this.tableLayoutPanel1.Controls.Add(this.pictureBox25, 9, 1);
            this.tableLayoutPanel1.Controls.Add(this.pictureBox26, 10, 1);
            this.tableLayoutPanel1.Controls.Add(this.pictureBox27, 11, 1);
            this.tableLayoutPanel1.Controls.Add(this.pictureBox28, 12, 1);
            this.tableLayoutPanel1.Controls.Add(this.pictureBox29, 13, 1);
            this.tableLayoutPanel1.Controls.Add(this.pictureBox30, 14, 1);
            this.tableLayoutPanel1.Controls.Add(this.pictureBox31, 0, 2);
            this.tableLayoutPanel1.Controls.Add(this.pictureBox32, 1, 2);
            this.tableLayoutPanel1.Controls.Add(this.pictureBox33, 2, 2);
            this.tableLayoutPanel1.Controls.Add(this.pictureBox34, 3, 2);
            this.tableLayoutPanel1.Controls.Add(this.pictureBox35, 4, 2);
            this.tableLayoutPanel1.Controls.Add(this.pictureBox36, 5, 2);
            this.tableLayoutPanel1.Controls.Add(this.pictureBox37, 6, 2);
            this.tableLayoutPanel1.Controls.Add(this.pictureBox38, 7, 2);
            this.tableLayoutPanel1.Controls.Add(this.pictureBox39, 8, 2);
            this.tableLayoutPanel1.Controls.Add(this.pictureBox40, 9, 2);
            this.tableLayoutPanel1.Controls.Add(this.pictureBox41, 10, 2);
            this.tableLayoutPanel1.Controls.Add(this.pictureBox42, 11, 2);
            this.tableLayoutPanel1.Controls.Add(this.pictureBox43, 12, 2);
            this.tableLayoutPanel1.Controls.Add(this.pictureBox44, 13, 2);
            this.tableLayoutPanel1.Controls.Add(this.pictureBox45, 14, 2);
            this.tableLayoutPanel1.Controls.Add(this.pictureBox46, 0, 3);
            this.tableLayoutPanel1.Controls.Add(this.pictureBox47, 1, 3);
            this.tableLayoutPanel1.Controls.Add(this.pictureBox48, 2, 3);
            this.tableLayoutPanel1.Controls.Add(this.pictureBox49, 3, 3);
            this.tableLayoutPanel1.Controls.Add(this.pictureBox50, 4, 3);
            this.tableLayoutPanel1.Controls.Add(this.pictureBox51, 5, 3);
            this.tableLayoutPanel1.Controls.Add(this.pictureBox52, 6, 3);
            this.tableLayoutPanel1.Controls.Add(this.pictureBox53, 7, 3);
            this.tableLayoutPanel1.Controls.Add(this.pictureBox54, 8, 3);
            this.tableLayoutPanel1.Controls.Add(this.pictureBox55, 9, 3);
            this.tableLayoutPanel1.Controls.Add(this.pictureBox56, 10, 3);
            this.tableLayoutPanel1.Controls.Add(this.pictureBox57, 11, 3);
            this.tableLayoutPanel1.Controls.Add(this.pictureBox58, 12, 3);
            this.tableLayoutPanel1.Controls.Add(this.pictureBox59, 13, 3);
            this.tableLayoutPanel1.Controls.Add(this.pictureBox60, 14, 3);
            this.tableLayoutPanel1.Controls.Add(this.pictureBox61, 0, 4);
            this.tableLayoutPanel1.Controls.Add(this.pictureBox62, 1, 4);
            this.tableLayoutPanel1.Controls.Add(this.pictureBox63, 2, 4);
            this.tableLayoutPanel1.Controls.Add(this.pictureBox64, 3, 4);
            this.tableLayoutPanel1.Controls.Add(this.pictureBox65, 4, 4);
            this.tableLayoutPanel1.Controls.Add(this.pictureBox66, 5, 4);
            this.tableLayoutPanel1.Controls.Add(this.pictureBox67, 6, 4);
            this.tableLayoutPanel1.Controls.Add(this.pictureBox68, 7, 4);
            this.tableLayoutPanel1.Controls.Add(this.pictureBox69, 8, 4);
            this.tableLayoutPanel1.Controls.Add(this.pictureBox70, 9, 4);
            this.tableLayoutPanel1.Controls.Add(this.pictureBox71, 10, 4);
            this.tableLayoutPanel1.Controls.Add(this.pictureBox72, 11, 4);
            this.tableLayoutPanel1.Controls.Add(this.pictureBox73, 12, 4);
            this.tableLayoutPanel1.Controls.Add(this.pictureBox74, 13, 4);
            this.tableLayoutPanel1.Controls.Add(this.pictureBox75, 14, 4);
            this.tableLayoutPanel1.Controls.Add(this.pictureBox76, 0, 5);
            this.tableLayoutPanel1.Controls.Add(this.pictureBox77, 1, 5);
            this.tableLayoutPanel1.Controls.Add(this.pictureBox78, 2, 5);
            this.tableLayoutPanel1.Controls.Add(this.pictureBox79, 3, 5);
            this.tableLayoutPanel1.Controls.Add(this.pictureBox80, 4, 5);
            this.tableLayoutPanel1.Controls.Add(this.pictureBox81, 5, 5);
            this.tableLayoutPanel1.Controls.Add(this.pictureBox82, 6, 5);
            this.tableLayoutPanel1.Controls.Add(this.pictureBox83, 7, 5);
            this.tableLayoutPanel1.Controls.Add(this.pictureBox84, 8, 5);
            this.tableLayoutPanel1.Controls.Add(this.pictureBox85, 9, 5);
            this.tableLayoutPanel1.Controls.Add(this.pictureBox86, 10, 5);
            this.tableLayoutPanel1.Controls.Add(this.pictureBox87, 11, 5);
            this.tableLayoutPanel1.Controls.Add(this.pictureBox88, 12, 5);
            this.tableLayoutPanel1.Controls.Add(this.pictureBox89, 13, 5);
            this.tableLayoutPanel1.Controls.Add(this.pictureBox90, 14, 5);
            this.tableLayoutPanel1.Controls.Add(this.pictureBox91, 0, 6);
            this.tableLayoutPanel1.Controls.Add(this.pictureBox92, 1, 6);
            this.tableLayoutPanel1.Controls.Add(this.pictureBox93, 2, 6);
            this.tableLayoutPanel1.Controls.Add(this.pictureBox94, 3, 6);
            this.tableLayoutPanel1.Controls.Add(this.pictureBox95, 4, 6);
            this.tableLayoutPanel1.Controls.Add(this.pictureBox96, 5, 6);
            this.tableLayoutPanel1.Controls.Add(this.pictureBox97, 6, 6);
            this.tableLayoutPanel1.Controls.Add(this.pictureBox98, 7, 6);
            this.tableLayoutPanel1.Controls.Add(this.pictureBox99, 8, 6);
            this.tableLayoutPanel1.Controls.Add(this.pictureBox100, 9, 6);
            this.tableLayoutPanel1.Controls.Add(this.pictureBox101, 10, 6);
            this.tableLayoutPanel1.Controls.Add(this.pictureBox102, 11, 6);
            this.tableLayoutPanel1.Controls.Add(this.pictureBox103, 12, 6);
            this.tableLayoutPanel1.Controls.Add(this.pictureBox104, 13, 6);
            this.tableLayoutPanel1.Controls.Add(this.pictureBox105, 14, 6);
            this.tableLayoutPanel1.Controls.Add(this.pictureBox106, 0, 7);
            this.tableLayoutPanel1.Controls.Add(this.pictureBox107, 1, 7);
            this.tableLayoutPanel1.Controls.Add(this.pictureBox108, 2, 7);
            this.tableLayoutPanel1.Controls.Add(this.pictureBox109, 3, 7);
            this.tableLayoutPanel1.Controls.Add(this.pictureBox110, 4, 7);
            this.tableLayoutPanel1.Controls.Add(this.pictureBox111, 5, 7);
            this.tableLayoutPanel1.Controls.Add(this.pictureBox112, 6, 7);
            this.tableLayoutPanel1.Controls.Add(this.pictureBox113, 7, 7);
            this.tableLayoutPanel1.Controls.Add(this.pictureBox114, 8, 7);
            this.tableLayoutPanel1.Controls.Add(this.pictureBox115, 9, 7);
            this.tableLayoutPanel1.Controls.Add(this.pictureBox116, 10, 7);
            this.tableLayoutPanel1.Controls.Add(this.pictureBox117, 11, 7);
            this.tableLayoutPanel1.Controls.Add(this.pictureBox118, 12, 7);
            this.tableLayoutPanel1.Controls.Add(this.pictureBox119, 13, 7);
            this.tableLayoutPanel1.Controls.Add(this.pictureBox120, 14, 7);
            this.tableLayoutPanel1.Controls.Add(this.pictureBox121, 0, 8);
            this.tableLayoutPanel1.Controls.Add(this.pictureBox122, 1, 8);
            this.tableLayoutPanel1.Controls.Add(this.pictureBox123, 2, 8);
            this.tableLayoutPanel1.Controls.Add(this.pictureBox124, 3, 8);
            this.tableLayoutPanel1.Controls.Add(this.pictureBox125, 4, 8);
            this.tableLayoutPanel1.Controls.Add(this.pictureBox126, 5, 8);
            this.tableLayoutPanel1.Controls.Add(this.pictureBox127, 6, 8);
            this.tableLayoutPanel1.Controls.Add(this.pictureBox128, 7, 8);
            this.tableLayoutPanel1.Controls.Add(this.pictureBox129, 8, 8);
            this.tableLayoutPanel1.Controls.Add(this.pictureBox130, 9, 8);
            this.tableLayoutPanel1.Controls.Add(this.pictureBox131, 10, 8);
            this.tableLayoutPanel1.Controls.Add(this.pictureBox132, 11, 8);
            this.tableLayoutPanel1.Controls.Add(this.pictureBox133, 12, 8);
            this.tableLayoutPanel1.Controls.Add(this.pictureBox134, 13, 8);
            this.tableLayoutPanel1.Controls.Add(this.pictureBox135, 14, 8);
            this.tableLayoutPanel1.Controls.Add(this.pictureBox136, 0, 9);
            this.tableLayoutPanel1.Controls.Add(this.pictureBox137, 1, 9);
            this.tableLayoutPanel1.Controls.Add(this.pictureBox138, 2, 9);
            this.tableLayoutPanel1.Controls.Add(this.pictureBox139, 3, 9);
            this.tableLayoutPanel1.Controls.Add(this.pictureBox140, 4, 9);
            this.tableLayoutPanel1.Controls.Add(this.pictureBox141, 5, 9);
            this.tableLayoutPanel1.Controls.Add(this.pictureBox142, 6, 9);
            this.tableLayoutPanel1.Controls.Add(this.pictureBox143, 7, 9);
            this.tableLayoutPanel1.Controls.Add(this.pictureBox144, 8, 9);
            this.tableLayoutPanel1.Controls.Add(this.pictureBox145, 9, 9);
            this.tableLayoutPanel1.Controls.Add(this.pictureBox146, 10, 9);
            this.tableLayoutPanel1.Controls.Add(this.pictureBox147, 11, 9);
            this.tableLayoutPanel1.Controls.Add(this.pictureBox148, 12, 9);
            this.tableLayoutPanel1.Controls.Add(this.pictureBox149, 13, 9);
            this.tableLayoutPanel1.Controls.Add(this.pictureBox150, 14, 9);
            this.tableLayoutPanel1.Controls.Add(this.pictureBox151, 0, 10);
            this.tableLayoutPanel1.Controls.Add(this.pictureBox152, 1, 10);
            this.tableLayoutPanel1.Controls.Add(this.pictureBox153, 2, 10);
            this.tableLayoutPanel1.Controls.Add(this.pictureBox154, 3, 10);
            this.tableLayoutPanel1.Controls.Add(this.pictureBox155, 4, 10);
            this.tableLayoutPanel1.Controls.Add(this.pictureBox156, 5, 10);
            this.tableLayoutPanel1.Controls.Add(this.pictureBox157, 6, 10);
            this.tableLayoutPanel1.Controls.Add(this.pictureBox158, 7, 10);
            this.tableLayoutPanel1.Controls.Add(this.pictureBox159, 8, 10);
            this.tableLayoutPanel1.Controls.Add(this.pictureBox160, 9, 10);
            this.tableLayoutPanel1.Controls.Add(this.pictureBox161, 10, 10);
            this.tableLayoutPanel1.Controls.Add(this.pictureBox162, 11, 10);
            this.tableLayoutPanel1.Controls.Add(this.pictureBox163, 12, 10);
            this.tableLayoutPanel1.Controls.Add(this.pictureBox164, 13, 10);
            this.tableLayoutPanel1.Controls.Add(this.pictureBox165, 14, 10);
            this.tableLayoutPanel1.Controls.Add(this.pictureBox166, 0, 11);
            this.tableLayoutPanel1.Controls.Add(this.pictureBox167, 1, 11);
            this.tableLayoutPanel1.Controls.Add(this.pictureBox168, 2, 11);
            this.tableLayoutPanel1.Controls.Add(this.pictureBox169, 3, 11);
            this.tableLayoutPanel1.Controls.Add(this.pictureBox170, 4, 11);
            this.tableLayoutPanel1.Controls.Add(this.pictureBox171, 5, 11);
            this.tableLayoutPanel1.Controls.Add(this.pictureBox172, 6, 11);
            this.tableLayoutPanel1.Controls.Add(this.pictureBox173, 7, 11);
            this.tableLayoutPanel1.Controls.Add(this.pictureBox174, 8, 11);
            this.tableLayoutPanel1.Controls.Add(this.pictureBox175, 9, 11);
            this.tableLayoutPanel1.Controls.Add(this.pictureBox176, 10, 11);
            this.tableLayoutPanel1.Controls.Add(this.pictureBox177, 11, 11);
            this.tableLayoutPanel1.Controls.Add(this.pictureBox178, 12, 11);
            this.tableLayoutPanel1.Controls.Add(this.pictureBox179, 13, 11);
            this.tableLayoutPanel1.Controls.Add(this.pictureBox180, 14, 11);
            this.tableLayoutPanel1.Controls.Add(this.pictureBox181, 0, 12);
            this.tableLayoutPanel1.Controls.Add(this.pictureBox182, 1, 12);
            this.tableLayoutPanel1.Controls.Add(this.pictureBox183, 2, 12);
            this.tableLayoutPanel1.Controls.Add(this.pictureBox184, 3, 12);
            this.tableLayoutPanel1.Controls.Add(this.pictureBox185, 4, 12);
            this.tableLayoutPanel1.Controls.Add(this.pictureBox186, 5, 12);
            this.tableLayoutPanel1.Controls.Add(this.pictureBox187, 6, 12);
            this.tableLayoutPanel1.Controls.Add(this.pictureBox188, 7, 12);
            this.tableLayoutPanel1.Controls.Add(this.pictureBox189, 8, 12);
            this.tableLayoutPanel1.Controls.Add(this.pictureBox190, 9, 12);
            this.tableLayoutPanel1.Controls.Add(this.pictureBox191, 10, 12);
            this.tableLayoutPanel1.Controls.Add(this.pictureBox192, 11, 12);
            this.tableLayoutPanel1.Controls.Add(this.pictureBox193, 12, 12);
            this.tableLayoutPanel1.Controls.Add(this.pictureBox194, 13, 12);
            this.tableLayoutPanel1.Controls.Add(this.pictureBox195, 14, 12);
            this.tableLayoutPanel1.Controls.Add(this.pictureBox196, 0, 13);
            this.tableLayoutPanel1.Controls.Add(this.pictureBox197, 1, 13);
            this.tableLayoutPanel1.Controls.Add(this.pictureBox198, 2, 13);
            this.tableLayoutPanel1.Controls.Add(this.pictureBox199, 3, 13);
            this.tableLayoutPanel1.Controls.Add(this.pictureBox200, 4, 13);
            this.tableLayoutPanel1.Controls.Add(this.pictureBox201, 5, 13);
            this.tableLayoutPanel1.Controls.Add(this.pictureBox202, 6, 13);
            this.tableLayoutPanel1.Controls.Add(this.pictureBox203, 7, 13);
            this.tableLayoutPanel1.Controls.Add(this.pictureBox204, 8, 13);
            this.tableLayoutPanel1.Controls.Add(this.pictureBox205, 9, 13);
            this.tableLayoutPanel1.Controls.Add(this.pictureBox206, 10, 13);
            this.tableLayoutPanel1.Controls.Add(this.pictureBox207, 11, 13);
            this.tableLayoutPanel1.Controls.Add(this.pictureBox208, 12, 13);
            this.tableLayoutPanel1.Controls.Add(this.pictureBox209, 13, 13);
            this.tableLayoutPanel1.Controls.Add(this.pictureBox210, 14, 13);
            this.tableLayoutPanel1.Controls.Add(this.pictureBox211, 0, 14);
            this.tableLayoutPanel1.Controls.Add(this.pictureBox212, 1, 14);
            this.tableLayoutPanel1.Controls.Add(this.pictureBox213, 2, 14);
            this.tableLayoutPanel1.Controls.Add(this.pictureBox214, 3, 14);
            this.tableLayoutPanel1.Controls.Add(this.pictureBox215, 4, 14);
            this.tableLayoutPanel1.Controls.Add(this.pictureBox216, 5, 14);
            this.tableLayoutPanel1.Controls.Add(this.pictureBox217, 6, 14);
            this.tableLayoutPanel1.Controls.Add(this.pictureBox218, 7, 14);
            this.tableLayoutPanel1.Controls.Add(this.pictureBox219, 8, 14);
            this.tableLayoutPanel1.Controls.Add(this.pictureBox220, 9, 14);
            this.tableLayoutPanel1.Controls.Add(this.pictureBox221, 10, 14);
            this.tableLayoutPanel1.Controls.Add(this.pictureBox222, 11, 14);
            this.tableLayoutPanel1.Controls.Add(this.pictureBox223, 12, 14);
            this.tableLayoutPanel1.Controls.Add(this.pictureBox224, 13, 14);
            this.tableLayoutPanel1.Controls.Add(this.pictureBox225, 14, 14);
            this.tableLayoutPanel1.Enabled = false;
            this.tableLayoutPanel1.ForeColor = System.Drawing.SystemColors.Control;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(286, 36);
            this.tableLayoutPanel1.Margin = new System.Windows.Forms.Padding(0);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 15;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 62F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 56F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 56F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 62F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 58F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 58F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 62F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 64F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 55F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 60F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 62F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 58F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 58F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 60F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 17F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(908, 898);
            this.tableLayoutPanel1.TabIndex = 0;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox1.Location = new System.Drawing.Point(0, 0);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(0);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(59, 62);
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // pictureBox2
            // 
            this.pictureBox2.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox2.Location = new System.Drawing.Point(59, 0);
            this.pictureBox2.Margin = new System.Windows.Forms.Padding(0);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(59, 62);
            this.pictureBox2.TabIndex = 0;
            this.pictureBox2.TabStop = false;
            this.pictureBox2.Click += new System.EventHandler(this.pictureBox2_Click);
            // 
            // pictureBox3
            // 
            this.pictureBox3.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox3.Location = new System.Drawing.Point(118, 0);
            this.pictureBox3.Margin = new System.Windows.Forms.Padding(0);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(59, 62);
            this.pictureBox3.TabIndex = 0;
            this.pictureBox3.TabStop = false;
            this.pictureBox3.Click += new System.EventHandler(this.pictureBox3_Click);
            // 
            // pictureBox4
            // 
            this.pictureBox4.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox4.Location = new System.Drawing.Point(177, 0);
            this.pictureBox4.Margin = new System.Windows.Forms.Padding(0);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(59, 62);
            this.pictureBox4.TabIndex = 0;
            this.pictureBox4.TabStop = false;
            this.pictureBox4.Click += new System.EventHandler(this.pictureBox4_Click);
            // 
            // pictureBox5
            // 
            this.pictureBox5.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox5.Location = new System.Drawing.Point(236, 0);
            this.pictureBox5.Margin = new System.Windows.Forms.Padding(0);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(61, 62);
            this.pictureBox5.TabIndex = 0;
            this.pictureBox5.TabStop = false;
            this.pictureBox5.Click += new System.EventHandler(this.pictureBox5_Click);
            // 
            // pictureBox6
            // 
            this.pictureBox6.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox6.Location = new System.Drawing.Point(297, 0);
            this.pictureBox6.Margin = new System.Windows.Forms.Padding(0);
            this.pictureBox6.Name = "pictureBox6";
            this.pictureBox6.Size = new System.Drawing.Size(58, 62);
            this.pictureBox6.TabIndex = 0;
            this.pictureBox6.TabStop = false;
            this.pictureBox6.Click += new System.EventHandler(this.pictureBox6_Click);
            // 
            // pictureBox7
            // 
            this.pictureBox7.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox7.Location = new System.Drawing.Point(355, 0);
            this.pictureBox7.Margin = new System.Windows.Forms.Padding(0);
            this.pictureBox7.Name = "pictureBox7";
            this.pictureBox7.Size = new System.Drawing.Size(63, 62);
            this.pictureBox7.TabIndex = 0;
            this.pictureBox7.TabStop = false;
            this.pictureBox7.Click += new System.EventHandler(this.pictureBox7_Click);
            // 
            // pictureBox8
            // 
            this.pictureBox8.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox8.Location = new System.Drawing.Point(418, 0);
            this.pictureBox8.Margin = new System.Windows.Forms.Padding(0);
            this.pictureBox8.Name = "pictureBox8";
            this.pictureBox8.Size = new System.Drawing.Size(67, 62);
            this.pictureBox8.TabIndex = 0;
            this.pictureBox8.TabStop = false;
            this.pictureBox8.Click += new System.EventHandler(this.pictureBox8_Click);
            // 
            // pictureBox9
            // 
            this.pictureBox9.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox9.Location = new System.Drawing.Point(485, 0);
            this.pictureBox9.Margin = new System.Windows.Forms.Padding(0);
            this.pictureBox9.Name = "pictureBox9";
            this.pictureBox9.Size = new System.Drawing.Size(59, 62);
            this.pictureBox9.TabIndex = 0;
            this.pictureBox9.TabStop = false;
            this.pictureBox9.Click += new System.EventHandler(this.pictureBox9_Click);
            // 
            // pictureBox10
            // 
            this.pictureBox10.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox10.Location = new System.Drawing.Point(544, 0);
            this.pictureBox10.Margin = new System.Windows.Forms.Padding(0);
            this.pictureBox10.Name = "pictureBox10";
            this.pictureBox10.Size = new System.Drawing.Size(59, 62);
            this.pictureBox10.TabIndex = 0;
            this.pictureBox10.TabStop = false;
            this.pictureBox10.Click += new System.EventHandler(this.pictureBox10_Click);
            // 
            // pictureBox11
            // 
            this.pictureBox11.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox11.Location = new System.Drawing.Point(603, 0);
            this.pictureBox11.Margin = new System.Windows.Forms.Padding(0);
            this.pictureBox11.Name = "pictureBox11";
            this.pictureBox11.Size = new System.Drawing.Size(63, 62);
            this.pictureBox11.TabIndex = 0;
            this.pictureBox11.TabStop = false;
            this.pictureBox11.Click += new System.EventHandler(this.pictureBox11_Click);
            // 
            // pictureBox12
            // 
            this.pictureBox12.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox12.Location = new System.Drawing.Point(666, 0);
            this.pictureBox12.Margin = new System.Windows.Forms.Padding(0);
            this.pictureBox12.Name = "pictureBox12";
            this.pictureBox12.Size = new System.Drawing.Size(61, 62);
            this.pictureBox12.TabIndex = 0;
            this.pictureBox12.TabStop = false;
            this.pictureBox12.Click += new System.EventHandler(this.pictureBox12_Click);
            // 
            // pictureBox13
            // 
            this.pictureBox13.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox13.Location = new System.Drawing.Point(727, 0);
            this.pictureBox13.Margin = new System.Windows.Forms.Padding(0);
            this.pictureBox13.Name = "pictureBox13";
            this.pictureBox13.Size = new System.Drawing.Size(63, 62);
            this.pictureBox13.TabIndex = 0;
            this.pictureBox13.TabStop = false;
            this.pictureBox13.Click += new System.EventHandler(this.pictureBox13_Click);
            // 
            // pictureBox14
            // 
            this.pictureBox14.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox14.Location = new System.Drawing.Point(790, 0);
            this.pictureBox14.Margin = new System.Windows.Forms.Padding(0);
            this.pictureBox14.Name = "pictureBox14";
            this.pictureBox14.Size = new System.Drawing.Size(56, 62);
            this.pictureBox14.TabIndex = 0;
            this.pictureBox14.TabStop = false;
            this.pictureBox14.Click += new System.EventHandler(this.pictureBox14_Click);
            // 
            // pictureBox15
            // 
            this.pictureBox15.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox15.Location = new System.Drawing.Point(846, 0);
            this.pictureBox15.Margin = new System.Windows.Forms.Padding(0);
            this.pictureBox15.Name = "pictureBox15";
            this.pictureBox15.Size = new System.Drawing.Size(62, 62);
            this.pictureBox15.TabIndex = 0;
            this.pictureBox15.TabStop = false;
            this.pictureBox15.Click += new System.EventHandler(this.pictureBox15_Click);
            // 
            // pictureBox16
            // 
            this.pictureBox16.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox16.Location = new System.Drawing.Point(0, 62);
            this.pictureBox16.Margin = new System.Windows.Forms.Padding(0);
            this.pictureBox16.Name = "pictureBox16";
            this.pictureBox16.Size = new System.Drawing.Size(59, 56);
            this.pictureBox16.TabIndex = 0;
            this.pictureBox16.TabStop = false;
            this.pictureBox16.Click += new System.EventHandler(this.pictureBox16_Click);
            // 
            // pictureBox17
            // 
            this.pictureBox17.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox17.Location = new System.Drawing.Point(59, 62);
            this.pictureBox17.Margin = new System.Windows.Forms.Padding(0);
            this.pictureBox17.Name = "pictureBox17";
            this.pictureBox17.Size = new System.Drawing.Size(59, 56);
            this.pictureBox17.TabIndex = 0;
            this.pictureBox17.TabStop = false;
            this.pictureBox17.Click += new System.EventHandler(this.pictureBox17_Click);
            // 
            // pictureBox18
            // 
            this.pictureBox18.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox18.Location = new System.Drawing.Point(118, 62);
            this.pictureBox18.Margin = new System.Windows.Forms.Padding(0);
            this.pictureBox18.Name = "pictureBox18";
            this.pictureBox18.Size = new System.Drawing.Size(59, 56);
            this.pictureBox18.TabIndex = 0;
            this.pictureBox18.TabStop = false;
            this.pictureBox18.Click += new System.EventHandler(this.pictureBox18_Click);
            // 
            // pictureBox19
            // 
            this.pictureBox19.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox19.Location = new System.Drawing.Point(177, 62);
            this.pictureBox19.Margin = new System.Windows.Forms.Padding(0);
            this.pictureBox19.Name = "pictureBox19";
            this.pictureBox19.Size = new System.Drawing.Size(59, 56);
            this.pictureBox19.TabIndex = 0;
            this.pictureBox19.TabStop = false;
            this.pictureBox19.Click += new System.EventHandler(this.pictureBox19_Click);
            // 
            // pictureBox20
            // 
            this.pictureBox20.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox20.Location = new System.Drawing.Point(236, 62);
            this.pictureBox20.Margin = new System.Windows.Forms.Padding(0);
            this.pictureBox20.Name = "pictureBox20";
            this.pictureBox20.Size = new System.Drawing.Size(61, 56);
            this.pictureBox20.TabIndex = 0;
            this.pictureBox20.TabStop = false;
            this.pictureBox20.Click += new System.EventHandler(this.pictureBox20_Click);
            // 
            // pictureBox21
            // 
            this.pictureBox21.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox21.Location = new System.Drawing.Point(297, 62);
            this.pictureBox21.Margin = new System.Windows.Forms.Padding(0);
            this.pictureBox21.Name = "pictureBox21";
            this.pictureBox21.Size = new System.Drawing.Size(58, 56);
            this.pictureBox21.TabIndex = 0;
            this.pictureBox21.TabStop = false;
            this.pictureBox21.Click += new System.EventHandler(this.pictureBox21_Click);
            // 
            // pictureBox22
            // 
            this.pictureBox22.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox22.Location = new System.Drawing.Point(355, 62);
            this.pictureBox22.Margin = new System.Windows.Forms.Padding(0);
            this.pictureBox22.Name = "pictureBox22";
            this.pictureBox22.Size = new System.Drawing.Size(63, 56);
            this.pictureBox22.TabIndex = 0;
            this.pictureBox22.TabStop = false;
            this.pictureBox22.Click += new System.EventHandler(this.pictureBox22_Click);
            // 
            // pictureBox23
            // 
            this.pictureBox23.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox23.Location = new System.Drawing.Point(418, 62);
            this.pictureBox23.Margin = new System.Windows.Forms.Padding(0);
            this.pictureBox23.Name = "pictureBox23";
            this.pictureBox23.Size = new System.Drawing.Size(67, 56);
            this.pictureBox23.TabIndex = 0;
            this.pictureBox23.TabStop = false;
            this.pictureBox23.Click += new System.EventHandler(this.pictureBox23_Click);
            // 
            // pictureBox24
            // 
            this.pictureBox24.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox24.Location = new System.Drawing.Point(485, 62);
            this.pictureBox24.Margin = new System.Windows.Forms.Padding(0);
            this.pictureBox24.Name = "pictureBox24";
            this.pictureBox24.Size = new System.Drawing.Size(59, 56);
            this.pictureBox24.TabIndex = 0;
            this.pictureBox24.TabStop = false;
            this.pictureBox24.Click += new System.EventHandler(this.pictureBox24_Click);
            // 
            // pictureBox25
            // 
            this.pictureBox25.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox25.Location = new System.Drawing.Point(544, 62);
            this.pictureBox25.Margin = new System.Windows.Forms.Padding(0);
            this.pictureBox25.Name = "pictureBox25";
            this.pictureBox25.Size = new System.Drawing.Size(59, 56);
            this.pictureBox25.TabIndex = 0;
            this.pictureBox25.TabStop = false;
            this.pictureBox25.Click += new System.EventHandler(this.pictureBox25_Click);
            // 
            // pictureBox26
            // 
            this.pictureBox26.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox26.Location = new System.Drawing.Point(603, 62);
            this.pictureBox26.Margin = new System.Windows.Forms.Padding(0);
            this.pictureBox26.Name = "pictureBox26";
            this.pictureBox26.Size = new System.Drawing.Size(63, 56);
            this.pictureBox26.TabIndex = 0;
            this.pictureBox26.TabStop = false;
            this.pictureBox26.Click += new System.EventHandler(this.pictureBox26_Click);
            // 
            // pictureBox27
            // 
            this.pictureBox27.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox27.Location = new System.Drawing.Point(666, 62);
            this.pictureBox27.Margin = new System.Windows.Forms.Padding(0);
            this.pictureBox27.Name = "pictureBox27";
            this.pictureBox27.Size = new System.Drawing.Size(61, 56);
            this.pictureBox27.TabIndex = 0;
            this.pictureBox27.TabStop = false;
            this.pictureBox27.Click += new System.EventHandler(this.pictureBox27_Click);
            // 
            // pictureBox28
            // 
            this.pictureBox28.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox28.Location = new System.Drawing.Point(727, 62);
            this.pictureBox28.Margin = new System.Windows.Forms.Padding(0);
            this.pictureBox28.Name = "pictureBox28";
            this.pictureBox28.Size = new System.Drawing.Size(63, 56);
            this.pictureBox28.TabIndex = 0;
            this.pictureBox28.TabStop = false;
            this.pictureBox28.Click += new System.EventHandler(this.pictureBox28_Click);
            // 
            // pictureBox29
            // 
            this.pictureBox29.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox29.Location = new System.Drawing.Point(790, 62);
            this.pictureBox29.Margin = new System.Windows.Forms.Padding(0);
            this.pictureBox29.Name = "pictureBox29";
            this.pictureBox29.Size = new System.Drawing.Size(56, 56);
            this.pictureBox29.TabIndex = 0;
            this.pictureBox29.TabStop = false;
            this.pictureBox29.Click += new System.EventHandler(this.pictureBox29_Click);
            // 
            // pictureBox30
            // 
            this.pictureBox30.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox30.Location = new System.Drawing.Point(846, 62);
            this.pictureBox30.Margin = new System.Windows.Forms.Padding(0);
            this.pictureBox30.Name = "pictureBox30";
            this.pictureBox30.Size = new System.Drawing.Size(62, 56);
            this.pictureBox30.TabIndex = 0;
            this.pictureBox30.TabStop = false;
            this.pictureBox30.Click += new System.EventHandler(this.pictureBox30_Click);
            // 
            // pictureBox31
            // 
            this.pictureBox31.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox31.Location = new System.Drawing.Point(0, 118);
            this.pictureBox31.Margin = new System.Windows.Forms.Padding(0);
            this.pictureBox31.Name = "pictureBox31";
            this.pictureBox31.Size = new System.Drawing.Size(59, 56);
            this.pictureBox31.TabIndex = 0;
            this.pictureBox31.TabStop = false;
            this.pictureBox31.Click += new System.EventHandler(this.pictureBox31_Click);
            // 
            // pictureBox32
            // 
            this.pictureBox32.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox32.Location = new System.Drawing.Point(59, 118);
            this.pictureBox32.Margin = new System.Windows.Forms.Padding(0);
            this.pictureBox32.Name = "pictureBox32";
            this.pictureBox32.Size = new System.Drawing.Size(59, 56);
            this.pictureBox32.TabIndex = 0;
            this.pictureBox32.TabStop = false;
            this.pictureBox32.Click += new System.EventHandler(this.pictureBox32_Click);
            // 
            // pictureBox33
            // 
            this.pictureBox33.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox33.Location = new System.Drawing.Point(118, 118);
            this.pictureBox33.Margin = new System.Windows.Forms.Padding(0);
            this.pictureBox33.Name = "pictureBox33";
            this.pictureBox33.Size = new System.Drawing.Size(59, 56);
            this.pictureBox33.TabIndex = 0;
            this.pictureBox33.TabStop = false;
            this.pictureBox33.Click += new System.EventHandler(this.pictureBox33_Click);
            // 
            // pictureBox34
            // 
            this.pictureBox34.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox34.Location = new System.Drawing.Point(177, 118);
            this.pictureBox34.Margin = new System.Windows.Forms.Padding(0);
            this.pictureBox34.Name = "pictureBox34";
            this.pictureBox34.Size = new System.Drawing.Size(59, 56);
            this.pictureBox34.TabIndex = 0;
            this.pictureBox34.TabStop = false;
            this.pictureBox34.Click += new System.EventHandler(this.pictureBox34_Click);
            // 
            // pictureBox35
            // 
            this.pictureBox35.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox35.Location = new System.Drawing.Point(236, 118);
            this.pictureBox35.Margin = new System.Windows.Forms.Padding(0);
            this.pictureBox35.Name = "pictureBox35";
            this.pictureBox35.Size = new System.Drawing.Size(61, 56);
            this.pictureBox35.TabIndex = 0;
            this.pictureBox35.TabStop = false;
            this.pictureBox35.Click += new System.EventHandler(this.pictureBox35_Click);
            // 
            // pictureBox36
            // 
            this.pictureBox36.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox36.Location = new System.Drawing.Point(297, 118);
            this.pictureBox36.Margin = new System.Windows.Forms.Padding(0);
            this.pictureBox36.Name = "pictureBox36";
            this.pictureBox36.Size = new System.Drawing.Size(58, 56);
            this.pictureBox36.TabIndex = 0;
            this.pictureBox36.TabStop = false;
            this.pictureBox36.Click += new System.EventHandler(this.pictureBox36_Click);
            // 
            // pictureBox37
            // 
            this.pictureBox37.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox37.Location = new System.Drawing.Point(355, 118);
            this.pictureBox37.Margin = new System.Windows.Forms.Padding(0);
            this.pictureBox37.Name = "pictureBox37";
            this.pictureBox37.Size = new System.Drawing.Size(63, 56);
            this.pictureBox37.TabIndex = 0;
            this.pictureBox37.TabStop = false;
            this.pictureBox37.Click += new System.EventHandler(this.pictureBox37_Click);
            // 
            // pictureBox38
            // 
            this.pictureBox38.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox38.Location = new System.Drawing.Point(418, 118);
            this.pictureBox38.Margin = new System.Windows.Forms.Padding(0);
            this.pictureBox38.Name = "pictureBox38";
            this.pictureBox38.Size = new System.Drawing.Size(67, 56);
            this.pictureBox38.TabIndex = 0;
            this.pictureBox38.TabStop = false;
            this.pictureBox38.Click += new System.EventHandler(this.pictureBox38_Click);
            // 
            // pictureBox39
            // 
            this.pictureBox39.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox39.Location = new System.Drawing.Point(485, 118);
            this.pictureBox39.Margin = new System.Windows.Forms.Padding(0);
            this.pictureBox39.Name = "pictureBox39";
            this.pictureBox39.Size = new System.Drawing.Size(59, 56);
            this.pictureBox39.TabIndex = 0;
            this.pictureBox39.TabStop = false;
            this.pictureBox39.Click += new System.EventHandler(this.pictureBox39_Click);
            // 
            // pictureBox40
            // 
            this.pictureBox40.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox40.Location = new System.Drawing.Point(544, 118);
            this.pictureBox40.Margin = new System.Windows.Forms.Padding(0);
            this.pictureBox40.Name = "pictureBox40";
            this.pictureBox40.Size = new System.Drawing.Size(59, 56);
            this.pictureBox40.TabIndex = 0;
            this.pictureBox40.TabStop = false;
            this.pictureBox40.Click += new System.EventHandler(this.pictureBox40_Click);
            // 
            // pictureBox41
            // 
            this.pictureBox41.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox41.Location = new System.Drawing.Point(603, 118);
            this.pictureBox41.Margin = new System.Windows.Forms.Padding(0);
            this.pictureBox41.Name = "pictureBox41";
            this.pictureBox41.Size = new System.Drawing.Size(63, 56);
            this.pictureBox41.TabIndex = 0;
            this.pictureBox41.TabStop = false;
            this.pictureBox41.Click += new System.EventHandler(this.pictureBox41_Click);
            // 
            // pictureBox42
            // 
            this.pictureBox42.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox42.Location = new System.Drawing.Point(666, 118);
            this.pictureBox42.Margin = new System.Windows.Forms.Padding(0);
            this.pictureBox42.Name = "pictureBox42";
            this.pictureBox42.Size = new System.Drawing.Size(61, 56);
            this.pictureBox42.TabIndex = 0;
            this.pictureBox42.TabStop = false;
            this.pictureBox42.Click += new System.EventHandler(this.pictureBox42_Click);
            // 
            // pictureBox43
            // 
            this.pictureBox43.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox43.Location = new System.Drawing.Point(727, 118);
            this.pictureBox43.Margin = new System.Windows.Forms.Padding(0);
            this.pictureBox43.Name = "pictureBox43";
            this.pictureBox43.Size = new System.Drawing.Size(63, 56);
            this.pictureBox43.TabIndex = 0;
            this.pictureBox43.TabStop = false;
            this.pictureBox43.Click += new System.EventHandler(this.pictureBox43_Click);
            // 
            // pictureBox44
            // 
            this.pictureBox44.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox44.Location = new System.Drawing.Point(790, 118);
            this.pictureBox44.Margin = new System.Windows.Forms.Padding(0);
            this.pictureBox44.Name = "pictureBox44";
            this.pictureBox44.Size = new System.Drawing.Size(56, 56);
            this.pictureBox44.TabIndex = 0;
            this.pictureBox44.TabStop = false;
            this.pictureBox44.Click += new System.EventHandler(this.pictureBox44_Click);
            // 
            // pictureBox45
            // 
            this.pictureBox45.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox45.Location = new System.Drawing.Point(846, 118);
            this.pictureBox45.Margin = new System.Windows.Forms.Padding(0);
            this.pictureBox45.Name = "pictureBox45";
            this.pictureBox45.Size = new System.Drawing.Size(62, 56);
            this.pictureBox45.TabIndex = 0;
            this.pictureBox45.TabStop = false;
            this.pictureBox45.Click += new System.EventHandler(this.pictureBox45_Click);
            // 
            // pictureBox46
            // 
            this.pictureBox46.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox46.Location = new System.Drawing.Point(0, 174);
            this.pictureBox46.Margin = new System.Windows.Forms.Padding(0);
            this.pictureBox46.Name = "pictureBox46";
            this.pictureBox46.Size = new System.Drawing.Size(59, 62);
            this.pictureBox46.TabIndex = 0;
            this.pictureBox46.TabStop = false;
            this.pictureBox46.Click += new System.EventHandler(this.pictureBox46_Click);
            // 
            // pictureBox47
            // 
            this.pictureBox47.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox47.Location = new System.Drawing.Point(59, 174);
            this.pictureBox47.Margin = new System.Windows.Forms.Padding(0);
            this.pictureBox47.Name = "pictureBox47";
            this.pictureBox47.Size = new System.Drawing.Size(59, 62);
            this.pictureBox47.TabIndex = 0;
            this.pictureBox47.TabStop = false;
            this.pictureBox47.Click += new System.EventHandler(this.pictureBox47_Click);
            // 
            // pictureBox48
            // 
            this.pictureBox48.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox48.Location = new System.Drawing.Point(118, 174);
            this.pictureBox48.Margin = new System.Windows.Forms.Padding(0);
            this.pictureBox48.Name = "pictureBox48";
            this.pictureBox48.Size = new System.Drawing.Size(59, 62);
            this.pictureBox48.TabIndex = 0;
            this.pictureBox48.TabStop = false;
            this.pictureBox48.Click += new System.EventHandler(this.pictureBox48_Click);
            // 
            // pictureBox49
            // 
            this.pictureBox49.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox49.Location = new System.Drawing.Point(177, 174);
            this.pictureBox49.Margin = new System.Windows.Forms.Padding(0);
            this.pictureBox49.Name = "pictureBox49";
            this.pictureBox49.Size = new System.Drawing.Size(59, 62);
            this.pictureBox49.TabIndex = 0;
            this.pictureBox49.TabStop = false;
            this.pictureBox49.Click += new System.EventHandler(this.pictureBox49_Click);
            // 
            // pictureBox50
            // 
            this.pictureBox50.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox50.Location = new System.Drawing.Point(236, 174);
            this.pictureBox50.Margin = new System.Windows.Forms.Padding(0);
            this.pictureBox50.Name = "pictureBox50";
            this.pictureBox50.Size = new System.Drawing.Size(61, 62);
            this.pictureBox50.TabIndex = 0;
            this.pictureBox50.TabStop = false;
            this.pictureBox50.Click += new System.EventHandler(this.pictureBox50_Click);
            // 
            // pictureBox51
            // 
            this.pictureBox51.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox51.Location = new System.Drawing.Point(297, 174);
            this.pictureBox51.Margin = new System.Windows.Forms.Padding(0);
            this.pictureBox51.Name = "pictureBox51";
            this.pictureBox51.Size = new System.Drawing.Size(58, 62);
            this.pictureBox51.TabIndex = 0;
            this.pictureBox51.TabStop = false;
            this.pictureBox51.Click += new System.EventHandler(this.pictureBox51_Click);
            // 
            // pictureBox52
            // 
            this.pictureBox52.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox52.Location = new System.Drawing.Point(355, 174);
            this.pictureBox52.Margin = new System.Windows.Forms.Padding(0);
            this.pictureBox52.Name = "pictureBox52";
            this.pictureBox52.Size = new System.Drawing.Size(63, 62);
            this.pictureBox52.TabIndex = 0;
            this.pictureBox52.TabStop = false;
            this.pictureBox52.Click += new System.EventHandler(this.pictureBox52_Click);
            // 
            // pictureBox53
            // 
            this.pictureBox53.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox53.Location = new System.Drawing.Point(418, 174);
            this.pictureBox53.Margin = new System.Windows.Forms.Padding(0);
            this.pictureBox53.Name = "pictureBox53";
            this.pictureBox53.Size = new System.Drawing.Size(67, 62);
            this.pictureBox53.TabIndex = 0;
            this.pictureBox53.TabStop = false;
            this.pictureBox53.Click += new System.EventHandler(this.pictureBox53_Click);
            // 
            // pictureBox54
            // 
            this.pictureBox54.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox54.Location = new System.Drawing.Point(485, 174);
            this.pictureBox54.Margin = new System.Windows.Forms.Padding(0);
            this.pictureBox54.Name = "pictureBox54";
            this.pictureBox54.Size = new System.Drawing.Size(59, 62);
            this.pictureBox54.TabIndex = 0;
            this.pictureBox54.TabStop = false;
            this.pictureBox54.Click += new System.EventHandler(this.pictureBox54_Click);
            // 
            // pictureBox55
            // 
            this.pictureBox55.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox55.Location = new System.Drawing.Point(544, 174);
            this.pictureBox55.Margin = new System.Windows.Forms.Padding(0);
            this.pictureBox55.Name = "pictureBox55";
            this.pictureBox55.Size = new System.Drawing.Size(59, 62);
            this.pictureBox55.TabIndex = 0;
            this.pictureBox55.TabStop = false;
            this.pictureBox55.Click += new System.EventHandler(this.pictureBox55_Click);
            // 
            // pictureBox56
            // 
            this.pictureBox56.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox56.Location = new System.Drawing.Point(603, 174);
            this.pictureBox56.Margin = new System.Windows.Forms.Padding(0);
            this.pictureBox56.Name = "pictureBox56";
            this.pictureBox56.Size = new System.Drawing.Size(63, 62);
            this.pictureBox56.TabIndex = 0;
            this.pictureBox56.TabStop = false;
            this.pictureBox56.Click += new System.EventHandler(this.pictureBox56_Click);
            // 
            // pictureBox57
            // 
            this.pictureBox57.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox57.Location = new System.Drawing.Point(666, 174);
            this.pictureBox57.Margin = new System.Windows.Forms.Padding(0);
            this.pictureBox57.Name = "pictureBox57";
            this.pictureBox57.Size = new System.Drawing.Size(61, 62);
            this.pictureBox57.TabIndex = 0;
            this.pictureBox57.TabStop = false;
            this.pictureBox57.Click += new System.EventHandler(this.pictureBox57_Click);
            // 
            // pictureBox58
            // 
            this.pictureBox58.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox58.Location = new System.Drawing.Point(727, 174);
            this.pictureBox58.Margin = new System.Windows.Forms.Padding(0);
            this.pictureBox58.Name = "pictureBox58";
            this.pictureBox58.Size = new System.Drawing.Size(63, 62);
            this.pictureBox58.TabIndex = 0;
            this.pictureBox58.TabStop = false;
            this.pictureBox58.Click += new System.EventHandler(this.pictureBox58_Click);
            // 
            // pictureBox59
            // 
            this.pictureBox59.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox59.Location = new System.Drawing.Point(790, 174);
            this.pictureBox59.Margin = new System.Windows.Forms.Padding(0);
            this.pictureBox59.Name = "pictureBox59";
            this.pictureBox59.Size = new System.Drawing.Size(56, 62);
            this.pictureBox59.TabIndex = 0;
            this.pictureBox59.TabStop = false;
            this.pictureBox59.Click += new System.EventHandler(this.pictureBox59_Click);
            // 
            // pictureBox60
            // 
            this.pictureBox60.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox60.Location = new System.Drawing.Point(846, 174);
            this.pictureBox60.Margin = new System.Windows.Forms.Padding(0);
            this.pictureBox60.Name = "pictureBox60";
            this.pictureBox60.Size = new System.Drawing.Size(62, 62);
            this.pictureBox60.TabIndex = 0;
            this.pictureBox60.TabStop = false;
            this.pictureBox60.Click += new System.EventHandler(this.pictureBox60_Click);
            // 
            // pictureBox61
            // 
            this.pictureBox61.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox61.Location = new System.Drawing.Point(0, 236);
            this.pictureBox61.Margin = new System.Windows.Forms.Padding(0);
            this.pictureBox61.Name = "pictureBox61";
            this.pictureBox61.Size = new System.Drawing.Size(59, 58);
            this.pictureBox61.TabIndex = 0;
            this.pictureBox61.TabStop = false;
            this.pictureBox61.Click += new System.EventHandler(this.pictureBox61_Click);
            // 
            // pictureBox62
            // 
            this.pictureBox62.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox62.Location = new System.Drawing.Point(59, 236);
            this.pictureBox62.Margin = new System.Windows.Forms.Padding(0);
            this.pictureBox62.Name = "pictureBox62";
            this.pictureBox62.Size = new System.Drawing.Size(59, 58);
            this.pictureBox62.TabIndex = 0;
            this.pictureBox62.TabStop = false;
            this.pictureBox62.Click += new System.EventHandler(this.pictureBox62_Click);
            // 
            // pictureBox63
            // 
            this.pictureBox63.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox63.Location = new System.Drawing.Point(118, 236);
            this.pictureBox63.Margin = new System.Windows.Forms.Padding(0);
            this.pictureBox63.Name = "pictureBox63";
            this.pictureBox63.Size = new System.Drawing.Size(59, 58);
            this.pictureBox63.TabIndex = 0;
            this.pictureBox63.TabStop = false;
            this.pictureBox63.Click += new System.EventHandler(this.pictureBox63_Click);
            // 
            // pictureBox64
            // 
            this.pictureBox64.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox64.Location = new System.Drawing.Point(177, 236);
            this.pictureBox64.Margin = new System.Windows.Forms.Padding(0);
            this.pictureBox64.Name = "pictureBox64";
            this.pictureBox64.Size = new System.Drawing.Size(59, 58);
            this.pictureBox64.TabIndex = 0;
            this.pictureBox64.TabStop = false;
            this.pictureBox64.Click += new System.EventHandler(this.pictureBox64_Click);
            // 
            // pictureBox65
            // 
            this.pictureBox65.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox65.Location = new System.Drawing.Point(236, 236);
            this.pictureBox65.Margin = new System.Windows.Forms.Padding(0);
            this.pictureBox65.Name = "pictureBox65";
            this.pictureBox65.Size = new System.Drawing.Size(61, 58);
            this.pictureBox65.TabIndex = 0;
            this.pictureBox65.TabStop = false;
            this.pictureBox65.Click += new System.EventHandler(this.pictureBox65_Click);
            // 
            // pictureBox66
            // 
            this.pictureBox66.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox66.Location = new System.Drawing.Point(297, 236);
            this.pictureBox66.Margin = new System.Windows.Forms.Padding(0);
            this.pictureBox66.Name = "pictureBox66";
            this.pictureBox66.Size = new System.Drawing.Size(58, 58);
            this.pictureBox66.TabIndex = 0;
            this.pictureBox66.TabStop = false;
            this.pictureBox66.Click += new System.EventHandler(this.pictureBox66_Click);
            // 
            // pictureBox67
            // 
            this.pictureBox67.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox67.Location = new System.Drawing.Point(355, 236);
            this.pictureBox67.Margin = new System.Windows.Forms.Padding(0);
            this.pictureBox67.Name = "pictureBox67";
            this.pictureBox67.Size = new System.Drawing.Size(63, 58);
            this.pictureBox67.TabIndex = 0;
            this.pictureBox67.TabStop = false;
            this.pictureBox67.Click += new System.EventHandler(this.pictureBox67_Click);
            // 
            // pictureBox68
            // 
            this.pictureBox68.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox68.Location = new System.Drawing.Point(418, 236);
            this.pictureBox68.Margin = new System.Windows.Forms.Padding(0);
            this.pictureBox68.Name = "pictureBox68";
            this.pictureBox68.Size = new System.Drawing.Size(67, 58);
            this.pictureBox68.TabIndex = 0;
            this.pictureBox68.TabStop = false;
            this.pictureBox68.Click += new System.EventHandler(this.pictureBox68_Click);
            // 
            // pictureBox69
            // 
            this.pictureBox69.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox69.Location = new System.Drawing.Point(485, 236);
            this.pictureBox69.Margin = new System.Windows.Forms.Padding(0);
            this.pictureBox69.Name = "pictureBox69";
            this.pictureBox69.Size = new System.Drawing.Size(59, 58);
            this.pictureBox69.TabIndex = 0;
            this.pictureBox69.TabStop = false;
            this.pictureBox69.Click += new System.EventHandler(this.pictureBox69_Click);
            // 
            // pictureBox70
            // 
            this.pictureBox70.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox70.Location = new System.Drawing.Point(544, 236);
            this.pictureBox70.Margin = new System.Windows.Forms.Padding(0);
            this.pictureBox70.Name = "pictureBox70";
            this.pictureBox70.Size = new System.Drawing.Size(59, 58);
            this.pictureBox70.TabIndex = 0;
            this.pictureBox70.TabStop = false;
            this.pictureBox70.Click += new System.EventHandler(this.pictureBox70_Click);
            // 
            // pictureBox71
            // 
            this.pictureBox71.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox71.Location = new System.Drawing.Point(603, 236);
            this.pictureBox71.Margin = new System.Windows.Forms.Padding(0);
            this.pictureBox71.Name = "pictureBox71";
            this.pictureBox71.Size = new System.Drawing.Size(63, 58);
            this.pictureBox71.TabIndex = 0;
            this.pictureBox71.TabStop = false;
            this.pictureBox71.Click += new System.EventHandler(this.pictureBox71_Click);
            // 
            // pictureBox72
            // 
            this.pictureBox72.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox72.Location = new System.Drawing.Point(666, 236);
            this.pictureBox72.Margin = new System.Windows.Forms.Padding(0);
            this.pictureBox72.Name = "pictureBox72";
            this.pictureBox72.Size = new System.Drawing.Size(61, 58);
            this.pictureBox72.TabIndex = 0;
            this.pictureBox72.TabStop = false;
            this.pictureBox72.Click += new System.EventHandler(this.pictureBox72_Click);
            // 
            // pictureBox73
            // 
            this.pictureBox73.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox73.Location = new System.Drawing.Point(727, 236);
            this.pictureBox73.Margin = new System.Windows.Forms.Padding(0);
            this.pictureBox73.Name = "pictureBox73";
            this.pictureBox73.Size = new System.Drawing.Size(63, 58);
            this.pictureBox73.TabIndex = 0;
            this.pictureBox73.TabStop = false;
            this.pictureBox73.Click += new System.EventHandler(this.pictureBox73_Click);
            // 
            // pictureBox74
            // 
            this.pictureBox74.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox74.Location = new System.Drawing.Point(790, 236);
            this.pictureBox74.Margin = new System.Windows.Forms.Padding(0);
            this.pictureBox74.Name = "pictureBox74";
            this.pictureBox74.Size = new System.Drawing.Size(56, 58);
            this.pictureBox74.TabIndex = 0;
            this.pictureBox74.TabStop = false;
            this.pictureBox74.Click += new System.EventHandler(this.pictureBox74_Click);
            // 
            // pictureBox75
            // 
            this.pictureBox75.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox75.Location = new System.Drawing.Point(846, 236);
            this.pictureBox75.Margin = new System.Windows.Forms.Padding(0);
            this.pictureBox75.Name = "pictureBox75";
            this.pictureBox75.Size = new System.Drawing.Size(62, 58);
            this.pictureBox75.TabIndex = 0;
            this.pictureBox75.TabStop = false;
            this.pictureBox75.Click += new System.EventHandler(this.pictureBox75_Click);
            // 
            // pictureBox76
            // 
            this.pictureBox76.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox76.Location = new System.Drawing.Point(0, 294);
            this.pictureBox76.Margin = new System.Windows.Forms.Padding(0);
            this.pictureBox76.Name = "pictureBox76";
            this.pictureBox76.Size = new System.Drawing.Size(59, 58);
            this.pictureBox76.TabIndex = 0;
            this.pictureBox76.TabStop = false;
            this.pictureBox76.Click += new System.EventHandler(this.pictureBox76_Click);
            // 
            // pictureBox77
            // 
            this.pictureBox77.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox77.Location = new System.Drawing.Point(59, 294);
            this.pictureBox77.Margin = new System.Windows.Forms.Padding(0);
            this.pictureBox77.Name = "pictureBox77";
            this.pictureBox77.Size = new System.Drawing.Size(59, 58);
            this.pictureBox77.TabIndex = 0;
            this.pictureBox77.TabStop = false;
            this.pictureBox77.Click += new System.EventHandler(this.pictureBox77_Click);
            // 
            // pictureBox78
            // 
            this.pictureBox78.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox78.Location = new System.Drawing.Point(118, 294);
            this.pictureBox78.Margin = new System.Windows.Forms.Padding(0);
            this.pictureBox78.Name = "pictureBox78";
            this.pictureBox78.Size = new System.Drawing.Size(59, 58);
            this.pictureBox78.TabIndex = 0;
            this.pictureBox78.TabStop = false;
            this.pictureBox78.Click += new System.EventHandler(this.pictureBox78_Click);
            // 
            // pictureBox79
            // 
            this.pictureBox79.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox79.Location = new System.Drawing.Point(177, 294);
            this.pictureBox79.Margin = new System.Windows.Forms.Padding(0);
            this.pictureBox79.Name = "pictureBox79";
            this.pictureBox79.Size = new System.Drawing.Size(59, 58);
            this.pictureBox79.TabIndex = 0;
            this.pictureBox79.TabStop = false;
            this.pictureBox79.Click += new System.EventHandler(this.pictureBox79_Click);
            // 
            // pictureBox80
            // 
            this.pictureBox80.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox80.Location = new System.Drawing.Point(236, 294);
            this.pictureBox80.Margin = new System.Windows.Forms.Padding(0);
            this.pictureBox80.Name = "pictureBox80";
            this.pictureBox80.Size = new System.Drawing.Size(61, 58);
            this.pictureBox80.TabIndex = 0;
            this.pictureBox80.TabStop = false;
            this.pictureBox80.Click += new System.EventHandler(this.pictureBox80_Click);
            // 
            // pictureBox81
            // 
            this.pictureBox81.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox81.Location = new System.Drawing.Point(297, 294);
            this.pictureBox81.Margin = new System.Windows.Forms.Padding(0);
            this.pictureBox81.Name = "pictureBox81";
            this.pictureBox81.Size = new System.Drawing.Size(58, 58);
            this.pictureBox81.TabIndex = 0;
            this.pictureBox81.TabStop = false;
            this.pictureBox81.Click += new System.EventHandler(this.pictureBox81_Click);
            // 
            // pictureBox82
            // 
            this.pictureBox82.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox82.Location = new System.Drawing.Point(355, 294);
            this.pictureBox82.Margin = new System.Windows.Forms.Padding(0);
            this.pictureBox82.Name = "pictureBox82";
            this.pictureBox82.Size = new System.Drawing.Size(63, 58);
            this.pictureBox82.TabIndex = 0;
            this.pictureBox82.TabStop = false;
            this.pictureBox82.Click += new System.EventHandler(this.pictureBox82_Click);
            // 
            // pictureBox83
            // 
            this.pictureBox83.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox83.Location = new System.Drawing.Point(418, 294);
            this.pictureBox83.Margin = new System.Windows.Forms.Padding(0);
            this.pictureBox83.Name = "pictureBox83";
            this.pictureBox83.Size = new System.Drawing.Size(67, 58);
            this.pictureBox83.TabIndex = 0;
            this.pictureBox83.TabStop = false;
            this.pictureBox83.Click += new System.EventHandler(this.pictureBox83_Click);
            // 
            // pictureBox84
            // 
            this.pictureBox84.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox84.Location = new System.Drawing.Point(485, 294);
            this.pictureBox84.Margin = new System.Windows.Forms.Padding(0);
            this.pictureBox84.Name = "pictureBox84";
            this.pictureBox84.Size = new System.Drawing.Size(59, 58);
            this.pictureBox84.TabIndex = 0;
            this.pictureBox84.TabStop = false;
            this.pictureBox84.Click += new System.EventHandler(this.pictureBox84_Click);
            // 
            // pictureBox85
            // 
            this.pictureBox85.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox85.Location = new System.Drawing.Point(544, 294);
            this.pictureBox85.Margin = new System.Windows.Forms.Padding(0);
            this.pictureBox85.Name = "pictureBox85";
            this.pictureBox85.Size = new System.Drawing.Size(59, 58);
            this.pictureBox85.TabIndex = 0;
            this.pictureBox85.TabStop = false;
            this.pictureBox85.Click += new System.EventHandler(this.pictureBox85_Click);
            // 
            // pictureBox86
            // 
            this.pictureBox86.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox86.Location = new System.Drawing.Point(603, 294);
            this.pictureBox86.Margin = new System.Windows.Forms.Padding(0);
            this.pictureBox86.Name = "pictureBox86";
            this.pictureBox86.Size = new System.Drawing.Size(63, 58);
            this.pictureBox86.TabIndex = 0;
            this.pictureBox86.TabStop = false;
            this.pictureBox86.Click += new System.EventHandler(this.pictureBox86_Click);
            // 
            // pictureBox87
            // 
            this.pictureBox87.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox87.Location = new System.Drawing.Point(666, 294);
            this.pictureBox87.Margin = new System.Windows.Forms.Padding(0);
            this.pictureBox87.Name = "pictureBox87";
            this.pictureBox87.Size = new System.Drawing.Size(61, 58);
            this.pictureBox87.TabIndex = 0;
            this.pictureBox87.TabStop = false;
            this.pictureBox87.Click += new System.EventHandler(this.pictureBox87_Click);
            // 
            // pictureBox88
            // 
            this.pictureBox88.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox88.Location = new System.Drawing.Point(727, 294);
            this.pictureBox88.Margin = new System.Windows.Forms.Padding(0);
            this.pictureBox88.Name = "pictureBox88";
            this.pictureBox88.Size = new System.Drawing.Size(63, 58);
            this.pictureBox88.TabIndex = 0;
            this.pictureBox88.TabStop = false;
            this.pictureBox88.Click += new System.EventHandler(this.pictureBox88_Click);
            // 
            // pictureBox89
            // 
            this.pictureBox89.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox89.Location = new System.Drawing.Point(790, 294);
            this.pictureBox89.Margin = new System.Windows.Forms.Padding(0);
            this.pictureBox89.Name = "pictureBox89";
            this.pictureBox89.Size = new System.Drawing.Size(56, 58);
            this.pictureBox89.TabIndex = 0;
            this.pictureBox89.TabStop = false;
            this.pictureBox89.Click += new System.EventHandler(this.pictureBox89_Click);
            // 
            // pictureBox90
            // 
            this.pictureBox90.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox90.Location = new System.Drawing.Point(846, 294);
            this.pictureBox90.Margin = new System.Windows.Forms.Padding(0);
            this.pictureBox90.Name = "pictureBox90";
            this.pictureBox90.Size = new System.Drawing.Size(62, 58);
            this.pictureBox90.TabIndex = 0;
            this.pictureBox90.TabStop = false;
            this.pictureBox90.Click += new System.EventHandler(this.pictureBox90_Click);
            // 
            // pictureBox91
            // 
            this.pictureBox91.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox91.Location = new System.Drawing.Point(0, 352);
            this.pictureBox91.Margin = new System.Windows.Forms.Padding(0);
            this.pictureBox91.Name = "pictureBox91";
            this.pictureBox91.Size = new System.Drawing.Size(59, 62);
            this.pictureBox91.TabIndex = 0;
            this.pictureBox91.TabStop = false;
            this.pictureBox91.Click += new System.EventHandler(this.pictureBox91_Click);
            // 
            // pictureBox92
            // 
            this.pictureBox92.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox92.Location = new System.Drawing.Point(59, 352);
            this.pictureBox92.Margin = new System.Windows.Forms.Padding(0);
            this.pictureBox92.Name = "pictureBox92";
            this.pictureBox92.Size = new System.Drawing.Size(59, 62);
            this.pictureBox92.TabIndex = 0;
            this.pictureBox92.TabStop = false;
            this.pictureBox92.Click += new System.EventHandler(this.pictureBox92_Click);
            // 
            // pictureBox93
            // 
            this.pictureBox93.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox93.Location = new System.Drawing.Point(118, 352);
            this.pictureBox93.Margin = new System.Windows.Forms.Padding(0);
            this.pictureBox93.Name = "pictureBox93";
            this.pictureBox93.Size = new System.Drawing.Size(59, 62);
            this.pictureBox93.TabIndex = 0;
            this.pictureBox93.TabStop = false;
            this.pictureBox93.Click += new System.EventHandler(this.pictureBox93_Click);
            // 
            // pictureBox94
            // 
            this.pictureBox94.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox94.Location = new System.Drawing.Point(177, 352);
            this.pictureBox94.Margin = new System.Windows.Forms.Padding(0);
            this.pictureBox94.Name = "pictureBox94";
            this.pictureBox94.Size = new System.Drawing.Size(59, 62);
            this.pictureBox94.TabIndex = 0;
            this.pictureBox94.TabStop = false;
            this.pictureBox94.Click += new System.EventHandler(this.pictureBox94_Click);
            // 
            // pictureBox95
            // 
            this.pictureBox95.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox95.Location = new System.Drawing.Point(236, 352);
            this.pictureBox95.Margin = new System.Windows.Forms.Padding(0);
            this.pictureBox95.Name = "pictureBox95";
            this.pictureBox95.Size = new System.Drawing.Size(61, 62);
            this.pictureBox95.TabIndex = 0;
            this.pictureBox95.TabStop = false;
            this.pictureBox95.Click += new System.EventHandler(this.pictureBox95_Click);
            // 
            // pictureBox96
            // 
            this.pictureBox96.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox96.Location = new System.Drawing.Point(297, 352);
            this.pictureBox96.Margin = new System.Windows.Forms.Padding(0);
            this.pictureBox96.Name = "pictureBox96";
            this.pictureBox96.Size = new System.Drawing.Size(58, 62);
            this.pictureBox96.TabIndex = 0;
            this.pictureBox96.TabStop = false;
            this.pictureBox96.Click += new System.EventHandler(this.pictureBox96_Click);
            // 
            // pictureBox97
            // 
            this.pictureBox97.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox97.Location = new System.Drawing.Point(355, 352);
            this.pictureBox97.Margin = new System.Windows.Forms.Padding(0);
            this.pictureBox97.Name = "pictureBox97";
            this.pictureBox97.Size = new System.Drawing.Size(63, 62);
            this.pictureBox97.TabIndex = 0;
            this.pictureBox97.TabStop = false;
            this.pictureBox97.Click += new System.EventHandler(this.pictureBox97_Click);
            // 
            // pictureBox98
            // 
            this.pictureBox98.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox98.Location = new System.Drawing.Point(418, 352);
            this.pictureBox98.Margin = new System.Windows.Forms.Padding(0);
            this.pictureBox98.Name = "pictureBox98";
            this.pictureBox98.Size = new System.Drawing.Size(67, 62);
            this.pictureBox98.TabIndex = 0;
            this.pictureBox98.TabStop = false;
            this.pictureBox98.Click += new System.EventHandler(this.pictureBox98_Click);
            // 
            // pictureBox99
            // 
            this.pictureBox99.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox99.Location = new System.Drawing.Point(485, 352);
            this.pictureBox99.Margin = new System.Windows.Forms.Padding(0);
            this.pictureBox99.Name = "pictureBox99";
            this.pictureBox99.Size = new System.Drawing.Size(59, 62);
            this.pictureBox99.TabIndex = 0;
            this.pictureBox99.TabStop = false;
            this.pictureBox99.Click += new System.EventHandler(this.pictureBox99_Click);
            // 
            // pictureBox100
            // 
            this.pictureBox100.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox100.Location = new System.Drawing.Point(544, 352);
            this.pictureBox100.Margin = new System.Windows.Forms.Padding(0);
            this.pictureBox100.Name = "pictureBox100";
            this.pictureBox100.Size = new System.Drawing.Size(59, 62);
            this.pictureBox100.TabIndex = 0;
            this.pictureBox100.TabStop = false;
            this.pictureBox100.Click += new System.EventHandler(this.pictureBox100_Click);
            // 
            // pictureBox101
            // 
            this.pictureBox101.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox101.Location = new System.Drawing.Point(603, 352);
            this.pictureBox101.Margin = new System.Windows.Forms.Padding(0);
            this.pictureBox101.Name = "pictureBox101";
            this.pictureBox101.Size = new System.Drawing.Size(63, 62);
            this.pictureBox101.TabIndex = 0;
            this.pictureBox101.TabStop = false;
            this.pictureBox101.Click += new System.EventHandler(this.pictureBox101_Click);
            // 
            // pictureBox102
            // 
            this.pictureBox102.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox102.Location = new System.Drawing.Point(666, 352);
            this.pictureBox102.Margin = new System.Windows.Forms.Padding(0);
            this.pictureBox102.Name = "pictureBox102";
            this.pictureBox102.Size = new System.Drawing.Size(61, 62);
            this.pictureBox102.TabIndex = 0;
            this.pictureBox102.TabStop = false;
            this.pictureBox102.Click += new System.EventHandler(this.pictureBox102_Click);
            // 
            // pictureBox103
            // 
            this.pictureBox103.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox103.Location = new System.Drawing.Point(727, 352);
            this.pictureBox103.Margin = new System.Windows.Forms.Padding(0);
            this.pictureBox103.Name = "pictureBox103";
            this.pictureBox103.Size = new System.Drawing.Size(63, 62);
            this.pictureBox103.TabIndex = 0;
            this.pictureBox103.TabStop = false;
            this.pictureBox103.Click += new System.EventHandler(this.pictureBox103_Click);
            // 
            // pictureBox104
            // 
            this.pictureBox104.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox104.Location = new System.Drawing.Point(790, 352);
            this.pictureBox104.Margin = new System.Windows.Forms.Padding(0);
            this.pictureBox104.Name = "pictureBox104";
            this.pictureBox104.Size = new System.Drawing.Size(56, 62);
            this.pictureBox104.TabIndex = 0;
            this.pictureBox104.TabStop = false;
            this.pictureBox104.Click += new System.EventHandler(this.pictureBox104_Click);
            // 
            // pictureBox105
            // 
            this.pictureBox105.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox105.Location = new System.Drawing.Point(846, 352);
            this.pictureBox105.Margin = new System.Windows.Forms.Padding(0);
            this.pictureBox105.Name = "pictureBox105";
            this.pictureBox105.Size = new System.Drawing.Size(62, 62);
            this.pictureBox105.TabIndex = 0;
            this.pictureBox105.TabStop = false;
            this.pictureBox105.Click += new System.EventHandler(this.pictureBox105_Click);
            // 
            // pictureBox106
            // 
            this.pictureBox106.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox106.Location = new System.Drawing.Point(0, 414);
            this.pictureBox106.Margin = new System.Windows.Forms.Padding(0);
            this.pictureBox106.Name = "pictureBox106";
            this.pictureBox106.Size = new System.Drawing.Size(59, 64);
            this.pictureBox106.TabIndex = 0;
            this.pictureBox106.TabStop = false;
            this.pictureBox106.Click += new System.EventHandler(this.pictureBox106_Click);
            // 
            // pictureBox107
            // 
            this.pictureBox107.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox107.Location = new System.Drawing.Point(59, 414);
            this.pictureBox107.Margin = new System.Windows.Forms.Padding(0);
            this.pictureBox107.Name = "pictureBox107";
            this.pictureBox107.Size = new System.Drawing.Size(59, 64);
            this.pictureBox107.TabIndex = 0;
            this.pictureBox107.TabStop = false;
            this.pictureBox107.Click += new System.EventHandler(this.pictureBox107_Click);
            // 
            // pictureBox108
            // 
            this.pictureBox108.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox108.Location = new System.Drawing.Point(118, 414);
            this.pictureBox108.Margin = new System.Windows.Forms.Padding(0);
            this.pictureBox108.Name = "pictureBox108";
            this.pictureBox108.Size = new System.Drawing.Size(59, 64);
            this.pictureBox108.TabIndex = 0;
            this.pictureBox108.TabStop = false;
            this.pictureBox108.Click += new System.EventHandler(this.pictureBox108_Click);
            // 
            // pictureBox109
            // 
            this.pictureBox109.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox109.Location = new System.Drawing.Point(177, 414);
            this.pictureBox109.Margin = new System.Windows.Forms.Padding(0);
            this.pictureBox109.Name = "pictureBox109";
            this.pictureBox109.Size = new System.Drawing.Size(59, 64);
            this.pictureBox109.TabIndex = 0;
            this.pictureBox109.TabStop = false;
            this.pictureBox109.Click += new System.EventHandler(this.pictureBox109_Click);
            // 
            // pictureBox110
            // 
            this.pictureBox110.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox110.Location = new System.Drawing.Point(236, 414);
            this.pictureBox110.Margin = new System.Windows.Forms.Padding(0);
            this.pictureBox110.Name = "pictureBox110";
            this.pictureBox110.Size = new System.Drawing.Size(61, 64);
            this.pictureBox110.TabIndex = 0;
            this.pictureBox110.TabStop = false;
            this.pictureBox110.Click += new System.EventHandler(this.pictureBox110_Click);
            // 
            // pictureBox111
            // 
            this.pictureBox111.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox111.Location = new System.Drawing.Point(297, 414);
            this.pictureBox111.Margin = new System.Windows.Forms.Padding(0);
            this.pictureBox111.Name = "pictureBox111";
            this.pictureBox111.Size = new System.Drawing.Size(58, 64);
            this.pictureBox111.TabIndex = 0;
            this.pictureBox111.TabStop = false;
            this.pictureBox111.Click += new System.EventHandler(this.pictureBox111_Click);
            // 
            // pictureBox112
            // 
            this.pictureBox112.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox112.Location = new System.Drawing.Point(355, 414);
            this.pictureBox112.Margin = new System.Windows.Forms.Padding(0);
            this.pictureBox112.Name = "pictureBox112";
            this.pictureBox112.Size = new System.Drawing.Size(63, 64);
            this.pictureBox112.TabIndex = 0;
            this.pictureBox112.TabStop = false;
            this.pictureBox112.Click += new System.EventHandler(this.pictureBox112_Click);
            // 
            // pictureBox113
            // 
            this.pictureBox113.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox113.Location = new System.Drawing.Point(418, 414);
            this.pictureBox113.Margin = new System.Windows.Forms.Padding(0);
            this.pictureBox113.Name = "pictureBox113";
            this.pictureBox113.Size = new System.Drawing.Size(67, 64);
            this.pictureBox113.TabIndex = 0;
            this.pictureBox113.TabStop = false;
            this.pictureBox113.Click += new System.EventHandler(this.pictureBox113_Click);
            // 
            // pictureBox114
            // 
            this.pictureBox114.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox114.Location = new System.Drawing.Point(485, 414);
            this.pictureBox114.Margin = new System.Windows.Forms.Padding(0);
            this.pictureBox114.Name = "pictureBox114";
            this.pictureBox114.Size = new System.Drawing.Size(59, 64);
            this.pictureBox114.TabIndex = 0;
            this.pictureBox114.TabStop = false;
            this.pictureBox114.Click += new System.EventHandler(this.pictureBox114_Click);
            // 
            // pictureBox115
            // 
            this.pictureBox115.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox115.Location = new System.Drawing.Point(544, 414);
            this.pictureBox115.Margin = new System.Windows.Forms.Padding(0);
            this.pictureBox115.Name = "pictureBox115";
            this.pictureBox115.Size = new System.Drawing.Size(59, 64);
            this.pictureBox115.TabIndex = 0;
            this.pictureBox115.TabStop = false;
            this.pictureBox115.Click += new System.EventHandler(this.pictureBox115_Click);
            // 
            // pictureBox116
            // 
            this.pictureBox116.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox116.Location = new System.Drawing.Point(603, 414);
            this.pictureBox116.Margin = new System.Windows.Forms.Padding(0);
            this.pictureBox116.Name = "pictureBox116";
            this.pictureBox116.Size = new System.Drawing.Size(63, 64);
            this.pictureBox116.TabIndex = 0;
            this.pictureBox116.TabStop = false;
            this.pictureBox116.Click += new System.EventHandler(this.pictureBox116_Click);
            // 
            // pictureBox117
            // 
            this.pictureBox117.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox117.Location = new System.Drawing.Point(666, 414);
            this.pictureBox117.Margin = new System.Windows.Forms.Padding(0);
            this.pictureBox117.Name = "pictureBox117";
            this.pictureBox117.Size = new System.Drawing.Size(61, 64);
            this.pictureBox117.TabIndex = 0;
            this.pictureBox117.TabStop = false;
            this.pictureBox117.Click += new System.EventHandler(this.pictureBox117_Click);
            // 
            // pictureBox118
            // 
            this.pictureBox118.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox118.Location = new System.Drawing.Point(727, 414);
            this.pictureBox118.Margin = new System.Windows.Forms.Padding(0);
            this.pictureBox118.Name = "pictureBox118";
            this.pictureBox118.Size = new System.Drawing.Size(63, 64);
            this.pictureBox118.TabIndex = 0;
            this.pictureBox118.TabStop = false;
            this.pictureBox118.Click += new System.EventHandler(this.pictureBox118_Click);
            // 
            // pictureBox119
            // 
            this.pictureBox119.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox119.Location = new System.Drawing.Point(790, 414);
            this.pictureBox119.Margin = new System.Windows.Forms.Padding(0);
            this.pictureBox119.Name = "pictureBox119";
            this.pictureBox119.Size = new System.Drawing.Size(56, 64);
            this.pictureBox119.TabIndex = 0;
            this.pictureBox119.TabStop = false;
            this.pictureBox119.Click += new System.EventHandler(this.pictureBox119_Click);
            // 
            // pictureBox120
            // 
            this.pictureBox120.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox120.Location = new System.Drawing.Point(846, 414);
            this.pictureBox120.Margin = new System.Windows.Forms.Padding(0);
            this.pictureBox120.Name = "pictureBox120";
            this.pictureBox120.Size = new System.Drawing.Size(62, 64);
            this.pictureBox120.TabIndex = 0;
            this.pictureBox120.TabStop = false;
            this.pictureBox120.Click += new System.EventHandler(this.pictureBox120_Click);
            // 
            // pictureBox121
            // 
            this.pictureBox121.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox121.Location = new System.Drawing.Point(0, 478);
            this.pictureBox121.Margin = new System.Windows.Forms.Padding(0);
            this.pictureBox121.Name = "pictureBox121";
            this.pictureBox121.Size = new System.Drawing.Size(59, 55);
            this.pictureBox121.TabIndex = 0;
            this.pictureBox121.TabStop = false;
            this.pictureBox121.Click += new System.EventHandler(this.pictureBox121_Click);
            // 
            // pictureBox122
            // 
            this.pictureBox122.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox122.Location = new System.Drawing.Point(59, 478);
            this.pictureBox122.Margin = new System.Windows.Forms.Padding(0);
            this.pictureBox122.Name = "pictureBox122";
            this.pictureBox122.Size = new System.Drawing.Size(59, 55);
            this.pictureBox122.TabIndex = 0;
            this.pictureBox122.TabStop = false;
            this.pictureBox122.Click += new System.EventHandler(this.pictureBox122_Click);
            // 
            // pictureBox123
            // 
            this.pictureBox123.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox123.Location = new System.Drawing.Point(118, 478);
            this.pictureBox123.Margin = new System.Windows.Forms.Padding(0);
            this.pictureBox123.Name = "pictureBox123";
            this.pictureBox123.Size = new System.Drawing.Size(59, 55);
            this.pictureBox123.TabIndex = 0;
            this.pictureBox123.TabStop = false;
            this.pictureBox123.Click += new System.EventHandler(this.pictureBox123_Click);
            // 
            // pictureBox124
            // 
            this.pictureBox124.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox124.Location = new System.Drawing.Point(177, 478);
            this.pictureBox124.Margin = new System.Windows.Forms.Padding(0);
            this.pictureBox124.Name = "pictureBox124";
            this.pictureBox124.Size = new System.Drawing.Size(59, 55);
            this.pictureBox124.TabIndex = 0;
            this.pictureBox124.TabStop = false;
            this.pictureBox124.Click += new System.EventHandler(this.pictureBox124_Click);
            // 
            // pictureBox125
            // 
            this.pictureBox125.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox125.Location = new System.Drawing.Point(236, 478);
            this.pictureBox125.Margin = new System.Windows.Forms.Padding(0);
            this.pictureBox125.Name = "pictureBox125";
            this.pictureBox125.Size = new System.Drawing.Size(61, 55);
            this.pictureBox125.TabIndex = 0;
            this.pictureBox125.TabStop = false;
            this.pictureBox125.Click += new System.EventHandler(this.pictureBox125_Click);
            // 
            // pictureBox126
            // 
            this.pictureBox126.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox126.Location = new System.Drawing.Point(297, 478);
            this.pictureBox126.Margin = new System.Windows.Forms.Padding(0);
            this.pictureBox126.Name = "pictureBox126";
            this.pictureBox126.Size = new System.Drawing.Size(58, 55);
            this.pictureBox126.TabIndex = 0;
            this.pictureBox126.TabStop = false;
            this.pictureBox126.Click += new System.EventHandler(this.pictureBox126_Click);
            // 
            // pictureBox127
            // 
            this.pictureBox127.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox127.Location = new System.Drawing.Point(355, 478);
            this.pictureBox127.Margin = new System.Windows.Forms.Padding(0);
            this.pictureBox127.Name = "pictureBox127";
            this.pictureBox127.Size = new System.Drawing.Size(63, 55);
            this.pictureBox127.TabIndex = 0;
            this.pictureBox127.TabStop = false;
            this.pictureBox127.Click += new System.EventHandler(this.pictureBox127_Click);
            // 
            // pictureBox128
            // 
            this.pictureBox128.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox128.Location = new System.Drawing.Point(418, 478);
            this.pictureBox128.Margin = new System.Windows.Forms.Padding(0);
            this.pictureBox128.Name = "pictureBox128";
            this.pictureBox128.Size = new System.Drawing.Size(67, 55);
            this.pictureBox128.TabIndex = 0;
            this.pictureBox128.TabStop = false;
            this.pictureBox128.Click += new System.EventHandler(this.pictureBox128_Click);
            // 
            // pictureBox129
            // 
            this.pictureBox129.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox129.Location = new System.Drawing.Point(485, 478);
            this.pictureBox129.Margin = new System.Windows.Forms.Padding(0);
            this.pictureBox129.Name = "pictureBox129";
            this.pictureBox129.Size = new System.Drawing.Size(59, 55);
            this.pictureBox129.TabIndex = 0;
            this.pictureBox129.TabStop = false;
            this.pictureBox129.Click += new System.EventHandler(this.pictureBox129_Click);
            // 
            // pictureBox130
            // 
            this.pictureBox130.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox130.Location = new System.Drawing.Point(544, 478);
            this.pictureBox130.Margin = new System.Windows.Forms.Padding(0);
            this.pictureBox130.Name = "pictureBox130";
            this.pictureBox130.Size = new System.Drawing.Size(59, 55);
            this.pictureBox130.TabIndex = 0;
            this.pictureBox130.TabStop = false;
            this.pictureBox130.Click += new System.EventHandler(this.pictureBox130_Click);
            // 
            // pictureBox131
            // 
            this.pictureBox131.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox131.Location = new System.Drawing.Point(603, 478);
            this.pictureBox131.Margin = new System.Windows.Forms.Padding(0);
            this.pictureBox131.Name = "pictureBox131";
            this.pictureBox131.Size = new System.Drawing.Size(63, 55);
            this.pictureBox131.TabIndex = 0;
            this.pictureBox131.TabStop = false;
            this.pictureBox131.Click += new System.EventHandler(this.pictureBox131_Click);
            // 
            // pictureBox132
            // 
            this.pictureBox132.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox132.Location = new System.Drawing.Point(666, 478);
            this.pictureBox132.Margin = new System.Windows.Forms.Padding(0);
            this.pictureBox132.Name = "pictureBox132";
            this.pictureBox132.Size = new System.Drawing.Size(61, 55);
            this.pictureBox132.TabIndex = 0;
            this.pictureBox132.TabStop = false;
            this.pictureBox132.Click += new System.EventHandler(this.pictureBox132_Click);
            // 
            // pictureBox133
            // 
            this.pictureBox133.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox133.Location = new System.Drawing.Point(727, 478);
            this.pictureBox133.Margin = new System.Windows.Forms.Padding(0);
            this.pictureBox133.Name = "pictureBox133";
            this.pictureBox133.Size = new System.Drawing.Size(63, 55);
            this.pictureBox133.TabIndex = 0;
            this.pictureBox133.TabStop = false;
            this.pictureBox133.Click += new System.EventHandler(this.pictureBox133_Click);
            // 
            // pictureBox134
            // 
            this.pictureBox134.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox134.Location = new System.Drawing.Point(790, 478);
            this.pictureBox134.Margin = new System.Windows.Forms.Padding(0);
            this.pictureBox134.Name = "pictureBox134";
            this.pictureBox134.Size = new System.Drawing.Size(56, 55);
            this.pictureBox134.TabIndex = 0;
            this.pictureBox134.TabStop = false;
            this.pictureBox134.Click += new System.EventHandler(this.pictureBox134_Click);
            // 
            // pictureBox135
            // 
            this.pictureBox135.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox135.Location = new System.Drawing.Point(846, 478);
            this.pictureBox135.Margin = new System.Windows.Forms.Padding(0);
            this.pictureBox135.Name = "pictureBox135";
            this.pictureBox135.Size = new System.Drawing.Size(62, 55);
            this.pictureBox135.TabIndex = 0;
            this.pictureBox135.TabStop = false;
            this.pictureBox135.Click += new System.EventHandler(this.pictureBox135_Click);
            // 
            // pictureBox136
            // 
            this.pictureBox136.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox136.Location = new System.Drawing.Point(0, 533);
            this.pictureBox136.Margin = new System.Windows.Forms.Padding(0);
            this.pictureBox136.Name = "pictureBox136";
            this.pictureBox136.Size = new System.Drawing.Size(59, 60);
            this.pictureBox136.TabIndex = 0;
            this.pictureBox136.TabStop = false;
            this.pictureBox136.Click += new System.EventHandler(this.pictureBox136_Click);
            // 
            // pictureBox137
            // 
            this.pictureBox137.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox137.Location = new System.Drawing.Point(59, 533);
            this.pictureBox137.Margin = new System.Windows.Forms.Padding(0);
            this.pictureBox137.Name = "pictureBox137";
            this.pictureBox137.Size = new System.Drawing.Size(59, 60);
            this.pictureBox137.TabIndex = 0;
            this.pictureBox137.TabStop = false;
            this.pictureBox137.Click += new System.EventHandler(this.pictureBox137_Click);
            // 
            // pictureBox138
            // 
            this.pictureBox138.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox138.Location = new System.Drawing.Point(118, 533);
            this.pictureBox138.Margin = new System.Windows.Forms.Padding(0);
            this.pictureBox138.Name = "pictureBox138";
            this.pictureBox138.Size = new System.Drawing.Size(59, 60);
            this.pictureBox138.TabIndex = 0;
            this.pictureBox138.TabStop = false;
            this.pictureBox138.Click += new System.EventHandler(this.pictureBox138_Click);
            // 
            // pictureBox139
            // 
            this.pictureBox139.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox139.Location = new System.Drawing.Point(177, 533);
            this.pictureBox139.Margin = new System.Windows.Forms.Padding(0);
            this.pictureBox139.Name = "pictureBox139";
            this.pictureBox139.Size = new System.Drawing.Size(59, 60);
            this.pictureBox139.TabIndex = 0;
            this.pictureBox139.TabStop = false;
            this.pictureBox139.Click += new System.EventHandler(this.pictureBox139_Click);
            // 
            // pictureBox140
            // 
            this.pictureBox140.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox140.Location = new System.Drawing.Point(236, 533);
            this.pictureBox140.Margin = new System.Windows.Forms.Padding(0);
            this.pictureBox140.Name = "pictureBox140";
            this.pictureBox140.Size = new System.Drawing.Size(61, 60);
            this.pictureBox140.TabIndex = 0;
            this.pictureBox140.TabStop = false;
            this.pictureBox140.Click += new System.EventHandler(this.pictureBox140_Click);
            // 
            // pictureBox141
            // 
            this.pictureBox141.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox141.Location = new System.Drawing.Point(297, 533);
            this.pictureBox141.Margin = new System.Windows.Forms.Padding(0);
            this.pictureBox141.Name = "pictureBox141";
            this.pictureBox141.Size = new System.Drawing.Size(58, 60);
            this.pictureBox141.TabIndex = 0;
            this.pictureBox141.TabStop = false;
            this.pictureBox141.Click += new System.EventHandler(this.pictureBox141_Click);
            // 
            // pictureBox142
            // 
            this.pictureBox142.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox142.Location = new System.Drawing.Point(355, 533);
            this.pictureBox142.Margin = new System.Windows.Forms.Padding(0);
            this.pictureBox142.Name = "pictureBox142";
            this.pictureBox142.Size = new System.Drawing.Size(63, 60);
            this.pictureBox142.TabIndex = 0;
            this.pictureBox142.TabStop = false;
            this.pictureBox142.Click += new System.EventHandler(this.pictureBox142_Click);
            // 
            // pictureBox143
            // 
            this.pictureBox143.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox143.Location = new System.Drawing.Point(418, 533);
            this.pictureBox143.Margin = new System.Windows.Forms.Padding(0);
            this.pictureBox143.Name = "pictureBox143";
            this.pictureBox143.Size = new System.Drawing.Size(67, 60);
            this.pictureBox143.TabIndex = 0;
            this.pictureBox143.TabStop = false;
            this.pictureBox143.Click += new System.EventHandler(this.pictureBox143_Click);
            // 
            // pictureBox144
            // 
            this.pictureBox144.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox144.Location = new System.Drawing.Point(485, 533);
            this.pictureBox144.Margin = new System.Windows.Forms.Padding(0);
            this.pictureBox144.Name = "pictureBox144";
            this.pictureBox144.Size = new System.Drawing.Size(59, 60);
            this.pictureBox144.TabIndex = 0;
            this.pictureBox144.TabStop = false;
            this.pictureBox144.Click += new System.EventHandler(this.pictureBox144_Click);
            // 
            // pictureBox145
            // 
            this.pictureBox145.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox145.Location = new System.Drawing.Point(544, 533);
            this.pictureBox145.Margin = new System.Windows.Forms.Padding(0);
            this.pictureBox145.Name = "pictureBox145";
            this.pictureBox145.Size = new System.Drawing.Size(59, 60);
            this.pictureBox145.TabIndex = 0;
            this.pictureBox145.TabStop = false;
            this.pictureBox145.Click += new System.EventHandler(this.pictureBox145_Click);
            // 
            // pictureBox146
            // 
            this.pictureBox146.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox146.Location = new System.Drawing.Point(603, 533);
            this.pictureBox146.Margin = new System.Windows.Forms.Padding(0);
            this.pictureBox146.Name = "pictureBox146";
            this.pictureBox146.Size = new System.Drawing.Size(63, 60);
            this.pictureBox146.TabIndex = 0;
            this.pictureBox146.TabStop = false;
            this.pictureBox146.Click += new System.EventHandler(this.pictureBox146_Click);
            // 
            // pictureBox147
            // 
            this.pictureBox147.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox147.Location = new System.Drawing.Point(666, 533);
            this.pictureBox147.Margin = new System.Windows.Forms.Padding(0);
            this.pictureBox147.Name = "pictureBox147";
            this.pictureBox147.Size = new System.Drawing.Size(61, 60);
            this.pictureBox147.TabIndex = 0;
            this.pictureBox147.TabStop = false;
            this.pictureBox147.Click += new System.EventHandler(this.pictureBox147_Click);
            // 
            // pictureBox148
            // 
            this.pictureBox148.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox148.Location = new System.Drawing.Point(727, 533);
            this.pictureBox148.Margin = new System.Windows.Forms.Padding(0);
            this.pictureBox148.Name = "pictureBox148";
            this.pictureBox148.Size = new System.Drawing.Size(63, 60);
            this.pictureBox148.TabIndex = 0;
            this.pictureBox148.TabStop = false;
            this.pictureBox148.Click += new System.EventHandler(this.pictureBox148_Click);
            // 
            // pictureBox149
            // 
            this.pictureBox149.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox149.Location = new System.Drawing.Point(790, 533);
            this.pictureBox149.Margin = new System.Windows.Forms.Padding(0);
            this.pictureBox149.Name = "pictureBox149";
            this.pictureBox149.Size = new System.Drawing.Size(56, 60);
            this.pictureBox149.TabIndex = 0;
            this.pictureBox149.TabStop = false;
            this.pictureBox149.Click += new System.EventHandler(this.pictureBox149_Click);
            // 
            // pictureBox150
            // 
            this.pictureBox150.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox150.Location = new System.Drawing.Point(846, 533);
            this.pictureBox150.Margin = new System.Windows.Forms.Padding(0);
            this.pictureBox150.Name = "pictureBox150";
            this.pictureBox150.Size = new System.Drawing.Size(62, 60);
            this.pictureBox150.TabIndex = 0;
            this.pictureBox150.TabStop = false;
            this.pictureBox150.Click += new System.EventHandler(this.pictureBox150_Click);
            // 
            // pictureBox151
            // 
            this.pictureBox151.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox151.Location = new System.Drawing.Point(0, 593);
            this.pictureBox151.Margin = new System.Windows.Forms.Padding(0);
            this.pictureBox151.Name = "pictureBox151";
            this.pictureBox151.Size = new System.Drawing.Size(59, 62);
            this.pictureBox151.TabIndex = 0;
            this.pictureBox151.TabStop = false;
            this.pictureBox151.Click += new System.EventHandler(this.pictureBox151_Click);
            // 
            // pictureBox152
            // 
            this.pictureBox152.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox152.Location = new System.Drawing.Point(59, 593);
            this.pictureBox152.Margin = new System.Windows.Forms.Padding(0);
            this.pictureBox152.Name = "pictureBox152";
            this.pictureBox152.Size = new System.Drawing.Size(59, 62);
            this.pictureBox152.TabIndex = 0;
            this.pictureBox152.TabStop = false;
            this.pictureBox152.Click += new System.EventHandler(this.pictureBox152_Click);
            // 
            // pictureBox153
            // 
            this.pictureBox153.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox153.Location = new System.Drawing.Point(118, 593);
            this.pictureBox153.Margin = new System.Windows.Forms.Padding(0);
            this.pictureBox153.Name = "pictureBox153";
            this.pictureBox153.Size = new System.Drawing.Size(59, 62);
            this.pictureBox153.TabIndex = 0;
            this.pictureBox153.TabStop = false;
            this.pictureBox153.Click += new System.EventHandler(this.pictureBox153_Click);
            // 
            // pictureBox154
            // 
            this.pictureBox154.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox154.Location = new System.Drawing.Point(177, 593);
            this.pictureBox154.Margin = new System.Windows.Forms.Padding(0);
            this.pictureBox154.Name = "pictureBox154";
            this.pictureBox154.Size = new System.Drawing.Size(59, 62);
            this.pictureBox154.TabIndex = 0;
            this.pictureBox154.TabStop = false;
            this.pictureBox154.Click += new System.EventHandler(this.pictureBox154_Click);
            // 
            // pictureBox155
            // 
            this.pictureBox155.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox155.Location = new System.Drawing.Point(236, 593);
            this.pictureBox155.Margin = new System.Windows.Forms.Padding(0);
            this.pictureBox155.Name = "pictureBox155";
            this.pictureBox155.Size = new System.Drawing.Size(61, 62);
            this.pictureBox155.TabIndex = 0;
            this.pictureBox155.TabStop = false;
            this.pictureBox155.Click += new System.EventHandler(this.pictureBox155_Click);
            // 
            // pictureBox156
            // 
            this.pictureBox156.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox156.Location = new System.Drawing.Point(297, 593);
            this.pictureBox156.Margin = new System.Windows.Forms.Padding(0);
            this.pictureBox156.Name = "pictureBox156";
            this.pictureBox156.Size = new System.Drawing.Size(58, 62);
            this.pictureBox156.TabIndex = 0;
            this.pictureBox156.TabStop = false;
            this.pictureBox156.Click += new System.EventHandler(this.pictureBox156_Click);
            // 
            // pictureBox157
            // 
            this.pictureBox157.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox157.Location = new System.Drawing.Point(355, 593);
            this.pictureBox157.Margin = new System.Windows.Forms.Padding(0);
            this.pictureBox157.Name = "pictureBox157";
            this.pictureBox157.Size = new System.Drawing.Size(63, 62);
            this.pictureBox157.TabIndex = 0;
            this.pictureBox157.TabStop = false;
            this.pictureBox157.Click += new System.EventHandler(this.pictureBox157_Click);
            // 
            // pictureBox158
            // 
            this.pictureBox158.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox158.Location = new System.Drawing.Point(418, 593);
            this.pictureBox158.Margin = new System.Windows.Forms.Padding(0);
            this.pictureBox158.Name = "pictureBox158";
            this.pictureBox158.Size = new System.Drawing.Size(67, 62);
            this.pictureBox158.TabIndex = 0;
            this.pictureBox158.TabStop = false;
            this.pictureBox158.Click += new System.EventHandler(this.pictureBox158_Click);
            // 
            // pictureBox159
            // 
            this.pictureBox159.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox159.Location = new System.Drawing.Point(485, 593);
            this.pictureBox159.Margin = new System.Windows.Forms.Padding(0);
            this.pictureBox159.Name = "pictureBox159";
            this.pictureBox159.Size = new System.Drawing.Size(59, 62);
            this.pictureBox159.TabIndex = 0;
            this.pictureBox159.TabStop = false;
            this.pictureBox159.Click += new System.EventHandler(this.pictureBox159_Click);
            // 
            // pictureBox160
            // 
            this.pictureBox160.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox160.Location = new System.Drawing.Point(544, 593);
            this.pictureBox160.Margin = new System.Windows.Forms.Padding(0);
            this.pictureBox160.Name = "pictureBox160";
            this.pictureBox160.Size = new System.Drawing.Size(59, 62);
            this.pictureBox160.TabIndex = 0;
            this.pictureBox160.TabStop = false;
            this.pictureBox160.Click += new System.EventHandler(this.pictureBox160_Click);
            // 
            // pictureBox161
            // 
            this.pictureBox161.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox161.Location = new System.Drawing.Point(603, 593);
            this.pictureBox161.Margin = new System.Windows.Forms.Padding(0);
            this.pictureBox161.Name = "pictureBox161";
            this.pictureBox161.Size = new System.Drawing.Size(63, 62);
            this.pictureBox161.TabIndex = 0;
            this.pictureBox161.TabStop = false;
            this.pictureBox161.Click += new System.EventHandler(this.pictureBox161_Click);
            // 
            // pictureBox162
            // 
            this.pictureBox162.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox162.Location = new System.Drawing.Point(666, 593);
            this.pictureBox162.Margin = new System.Windows.Forms.Padding(0);
            this.pictureBox162.Name = "pictureBox162";
            this.pictureBox162.Size = new System.Drawing.Size(61, 62);
            this.pictureBox162.TabIndex = 0;
            this.pictureBox162.TabStop = false;
            this.pictureBox162.Click += new System.EventHandler(this.pictureBox162_Click);
            // 
            // pictureBox163
            // 
            this.pictureBox163.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox163.Location = new System.Drawing.Point(727, 593);
            this.pictureBox163.Margin = new System.Windows.Forms.Padding(0);
            this.pictureBox163.Name = "pictureBox163";
            this.pictureBox163.Size = new System.Drawing.Size(63, 62);
            this.pictureBox163.TabIndex = 0;
            this.pictureBox163.TabStop = false;
            this.pictureBox163.Click += new System.EventHandler(this.pictureBox163_Click);
            // 
            // pictureBox164
            // 
            this.pictureBox164.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox164.Location = new System.Drawing.Point(790, 593);
            this.pictureBox164.Margin = new System.Windows.Forms.Padding(0);
            this.pictureBox164.Name = "pictureBox164";
            this.pictureBox164.Size = new System.Drawing.Size(56, 62);
            this.pictureBox164.TabIndex = 0;
            this.pictureBox164.TabStop = false;
            this.pictureBox164.Click += new System.EventHandler(this.pictureBox164_Click);
            // 
            // pictureBox165
            // 
            this.pictureBox165.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox165.Location = new System.Drawing.Point(846, 593);
            this.pictureBox165.Margin = new System.Windows.Forms.Padding(0);
            this.pictureBox165.Name = "pictureBox165";
            this.pictureBox165.Size = new System.Drawing.Size(62, 62);
            this.pictureBox165.TabIndex = 0;
            this.pictureBox165.TabStop = false;
            this.pictureBox165.Click += new System.EventHandler(this.pictureBox165_Click);
            // 
            // pictureBox166
            // 
            this.pictureBox166.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox166.Location = new System.Drawing.Point(0, 655);
            this.pictureBox166.Margin = new System.Windows.Forms.Padding(0);
            this.pictureBox166.Name = "pictureBox166";
            this.pictureBox166.Size = new System.Drawing.Size(59, 58);
            this.pictureBox166.TabIndex = 0;
            this.pictureBox166.TabStop = false;
            this.pictureBox166.Click += new System.EventHandler(this.pictureBox166_Click);
            // 
            // pictureBox167
            // 
            this.pictureBox167.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox167.Location = new System.Drawing.Point(59, 655);
            this.pictureBox167.Margin = new System.Windows.Forms.Padding(0);
            this.pictureBox167.Name = "pictureBox167";
            this.pictureBox167.Size = new System.Drawing.Size(59, 58);
            this.pictureBox167.TabIndex = 0;
            this.pictureBox167.TabStop = false;
            this.pictureBox167.Click += new System.EventHandler(this.pictureBox167_Click);
            // 
            // pictureBox168
            // 
            this.pictureBox168.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox168.Location = new System.Drawing.Point(118, 655);
            this.pictureBox168.Margin = new System.Windows.Forms.Padding(0);
            this.pictureBox168.Name = "pictureBox168";
            this.pictureBox168.Size = new System.Drawing.Size(59, 58);
            this.pictureBox168.TabIndex = 0;
            this.pictureBox168.TabStop = false;
            this.pictureBox168.Click += new System.EventHandler(this.pictureBox168_Click);
            // 
            // pictureBox169
            // 
            this.pictureBox169.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox169.Location = new System.Drawing.Point(177, 655);
            this.pictureBox169.Margin = new System.Windows.Forms.Padding(0);
            this.pictureBox169.Name = "pictureBox169";
            this.pictureBox169.Size = new System.Drawing.Size(59, 58);
            this.pictureBox169.TabIndex = 0;
            this.pictureBox169.TabStop = false;
            this.pictureBox169.Click += new System.EventHandler(this.pictureBox169_Click);
            // 
            // pictureBox170
            // 
            this.pictureBox170.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox170.Location = new System.Drawing.Point(236, 655);
            this.pictureBox170.Margin = new System.Windows.Forms.Padding(0);
            this.pictureBox170.Name = "pictureBox170";
            this.pictureBox170.Size = new System.Drawing.Size(61, 58);
            this.pictureBox170.TabIndex = 0;
            this.pictureBox170.TabStop = false;
            this.pictureBox170.Click += new System.EventHandler(this.pictureBox170_Click);
            // 
            // pictureBox171
            // 
            this.pictureBox171.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox171.Location = new System.Drawing.Point(297, 655);
            this.pictureBox171.Margin = new System.Windows.Forms.Padding(0);
            this.pictureBox171.Name = "pictureBox171";
            this.pictureBox171.Size = new System.Drawing.Size(58, 58);
            this.pictureBox171.TabIndex = 0;
            this.pictureBox171.TabStop = false;
            this.pictureBox171.Click += new System.EventHandler(this.pictureBox171_Click);
            // 
            // pictureBox172
            // 
            this.pictureBox172.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox172.Location = new System.Drawing.Point(355, 655);
            this.pictureBox172.Margin = new System.Windows.Forms.Padding(0);
            this.pictureBox172.Name = "pictureBox172";
            this.pictureBox172.Size = new System.Drawing.Size(63, 58);
            this.pictureBox172.TabIndex = 0;
            this.pictureBox172.TabStop = false;
            this.pictureBox172.Click += new System.EventHandler(this.pictureBox172_Click);
            // 
            // pictureBox173
            // 
            this.pictureBox173.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox173.Location = new System.Drawing.Point(418, 655);
            this.pictureBox173.Margin = new System.Windows.Forms.Padding(0);
            this.pictureBox173.Name = "pictureBox173";
            this.pictureBox173.Size = new System.Drawing.Size(67, 58);
            this.pictureBox173.TabIndex = 0;
            this.pictureBox173.TabStop = false;
            this.pictureBox173.Click += new System.EventHandler(this.pictureBox173_Click);
            // 
            // pictureBox174
            // 
            this.pictureBox174.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox174.Location = new System.Drawing.Point(485, 655);
            this.pictureBox174.Margin = new System.Windows.Forms.Padding(0);
            this.pictureBox174.Name = "pictureBox174";
            this.pictureBox174.Size = new System.Drawing.Size(59, 58);
            this.pictureBox174.TabIndex = 0;
            this.pictureBox174.TabStop = false;
            this.pictureBox174.Click += new System.EventHandler(this.pictureBox174_Click);
            // 
            // pictureBox175
            // 
            this.pictureBox175.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox175.Location = new System.Drawing.Point(544, 655);
            this.pictureBox175.Margin = new System.Windows.Forms.Padding(0);
            this.pictureBox175.Name = "pictureBox175";
            this.pictureBox175.Size = new System.Drawing.Size(59, 58);
            this.pictureBox175.TabIndex = 0;
            this.pictureBox175.TabStop = false;
            this.pictureBox175.Click += new System.EventHandler(this.pictureBox175_Click);
            // 
            // pictureBox176
            // 
            this.pictureBox176.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox176.Location = new System.Drawing.Point(603, 655);
            this.pictureBox176.Margin = new System.Windows.Forms.Padding(0);
            this.pictureBox176.Name = "pictureBox176";
            this.pictureBox176.Size = new System.Drawing.Size(63, 58);
            this.pictureBox176.TabIndex = 0;
            this.pictureBox176.TabStop = false;
            this.pictureBox176.Click += new System.EventHandler(this.pictureBox176_Click);
            // 
            // pictureBox177
            // 
            this.pictureBox177.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox177.Location = new System.Drawing.Point(666, 655);
            this.pictureBox177.Margin = new System.Windows.Forms.Padding(0);
            this.pictureBox177.Name = "pictureBox177";
            this.pictureBox177.Size = new System.Drawing.Size(61, 58);
            this.pictureBox177.TabIndex = 0;
            this.pictureBox177.TabStop = false;
            this.pictureBox177.Click += new System.EventHandler(this.pictureBox177_Click);
            // 
            // pictureBox178
            // 
            this.pictureBox178.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox178.Location = new System.Drawing.Point(727, 655);
            this.pictureBox178.Margin = new System.Windows.Forms.Padding(0);
            this.pictureBox178.Name = "pictureBox178";
            this.pictureBox178.Size = new System.Drawing.Size(63, 58);
            this.pictureBox178.TabIndex = 0;
            this.pictureBox178.TabStop = false;
            this.pictureBox178.Click += new System.EventHandler(this.pictureBox178_Click);
            // 
            // pictureBox179
            // 
            this.pictureBox179.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox179.Location = new System.Drawing.Point(790, 655);
            this.pictureBox179.Margin = new System.Windows.Forms.Padding(0);
            this.pictureBox179.Name = "pictureBox179";
            this.pictureBox179.Size = new System.Drawing.Size(56, 58);
            this.pictureBox179.TabIndex = 0;
            this.pictureBox179.TabStop = false;
            this.pictureBox179.Click += new System.EventHandler(this.pictureBox179_Click);
            // 
            // pictureBox180
            // 
            this.pictureBox180.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox180.Location = new System.Drawing.Point(846, 655);
            this.pictureBox180.Margin = new System.Windows.Forms.Padding(0);
            this.pictureBox180.Name = "pictureBox180";
            this.pictureBox180.Size = new System.Drawing.Size(62, 58);
            this.pictureBox180.TabIndex = 0;
            this.pictureBox180.TabStop = false;
            this.pictureBox180.Click += new System.EventHandler(this.pictureBox180_Click);
            // 
            // pictureBox181
            // 
            this.pictureBox181.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox181.Location = new System.Drawing.Point(0, 713);
            this.pictureBox181.Margin = new System.Windows.Forms.Padding(0);
            this.pictureBox181.Name = "pictureBox181";
            this.pictureBox181.Size = new System.Drawing.Size(59, 58);
            this.pictureBox181.TabIndex = 0;
            this.pictureBox181.TabStop = false;
            this.pictureBox181.Click += new System.EventHandler(this.pictureBox181_Click);
            // 
            // pictureBox182
            // 
            this.pictureBox182.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox182.Location = new System.Drawing.Point(59, 713);
            this.pictureBox182.Margin = new System.Windows.Forms.Padding(0);
            this.pictureBox182.Name = "pictureBox182";
            this.pictureBox182.Size = new System.Drawing.Size(59, 58);
            this.pictureBox182.TabIndex = 0;
            this.pictureBox182.TabStop = false;
            this.pictureBox182.Click += new System.EventHandler(this.pictureBox182_Click);
            // 
            // pictureBox183
            // 
            this.pictureBox183.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox183.Location = new System.Drawing.Point(118, 713);
            this.pictureBox183.Margin = new System.Windows.Forms.Padding(0);
            this.pictureBox183.Name = "pictureBox183";
            this.pictureBox183.Size = new System.Drawing.Size(59, 58);
            this.pictureBox183.TabIndex = 0;
            this.pictureBox183.TabStop = false;
            this.pictureBox183.Click += new System.EventHandler(this.pictureBox183_Click);
            // 
            // pictureBox184
            // 
            this.pictureBox184.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox184.Location = new System.Drawing.Point(177, 713);
            this.pictureBox184.Margin = new System.Windows.Forms.Padding(0);
            this.pictureBox184.Name = "pictureBox184";
            this.pictureBox184.Size = new System.Drawing.Size(59, 58);
            this.pictureBox184.TabIndex = 0;
            this.pictureBox184.TabStop = false;
            this.pictureBox184.Click += new System.EventHandler(this.pictureBox184_Click);
            // 
            // pictureBox185
            // 
            this.pictureBox185.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox185.Location = new System.Drawing.Point(236, 713);
            this.pictureBox185.Margin = new System.Windows.Forms.Padding(0);
            this.pictureBox185.Name = "pictureBox185";
            this.pictureBox185.Size = new System.Drawing.Size(61, 58);
            this.pictureBox185.TabIndex = 0;
            this.pictureBox185.TabStop = false;
            this.pictureBox185.Click += new System.EventHandler(this.pictureBox185_Click);
            // 
            // pictureBox186
            // 
            this.pictureBox186.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox186.Location = new System.Drawing.Point(297, 713);
            this.pictureBox186.Margin = new System.Windows.Forms.Padding(0);
            this.pictureBox186.Name = "pictureBox186";
            this.pictureBox186.Size = new System.Drawing.Size(58, 58);
            this.pictureBox186.TabIndex = 0;
            this.pictureBox186.TabStop = false;
            this.pictureBox186.Click += new System.EventHandler(this.pictureBox186_Click);
            // 
            // pictureBox187
            // 
            this.pictureBox187.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox187.Location = new System.Drawing.Point(355, 713);
            this.pictureBox187.Margin = new System.Windows.Forms.Padding(0);
            this.pictureBox187.Name = "pictureBox187";
            this.pictureBox187.Size = new System.Drawing.Size(63, 58);
            this.pictureBox187.TabIndex = 0;
            this.pictureBox187.TabStop = false;
            this.pictureBox187.Click += new System.EventHandler(this.pictureBox187_Click);
            // 
            // pictureBox188
            // 
            this.pictureBox188.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox188.Location = new System.Drawing.Point(418, 713);
            this.pictureBox188.Margin = new System.Windows.Forms.Padding(0);
            this.pictureBox188.Name = "pictureBox188";
            this.pictureBox188.Size = new System.Drawing.Size(67, 58);
            this.pictureBox188.TabIndex = 0;
            this.pictureBox188.TabStop = false;
            this.pictureBox188.Click += new System.EventHandler(this.pictureBox188_Click);
            // 
            // pictureBox189
            // 
            this.pictureBox189.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox189.Location = new System.Drawing.Point(485, 713);
            this.pictureBox189.Margin = new System.Windows.Forms.Padding(0);
            this.pictureBox189.Name = "pictureBox189";
            this.pictureBox189.Size = new System.Drawing.Size(59, 58);
            this.pictureBox189.TabIndex = 0;
            this.pictureBox189.TabStop = false;
            this.pictureBox189.Click += new System.EventHandler(this.pictureBox189_Click);
            // 
            // pictureBox190
            // 
            this.pictureBox190.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox190.Location = new System.Drawing.Point(544, 713);
            this.pictureBox190.Margin = new System.Windows.Forms.Padding(0);
            this.pictureBox190.Name = "pictureBox190";
            this.pictureBox190.Size = new System.Drawing.Size(59, 58);
            this.pictureBox190.TabIndex = 0;
            this.pictureBox190.TabStop = false;
            this.pictureBox190.Click += new System.EventHandler(this.pictureBox190_Click);
            // 
            // pictureBox191
            // 
            this.pictureBox191.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox191.Location = new System.Drawing.Point(603, 713);
            this.pictureBox191.Margin = new System.Windows.Forms.Padding(0);
            this.pictureBox191.Name = "pictureBox191";
            this.pictureBox191.Size = new System.Drawing.Size(63, 58);
            this.pictureBox191.TabIndex = 0;
            this.pictureBox191.TabStop = false;
            this.pictureBox191.Click += new System.EventHandler(this.pictureBox191_Click);
            // 
            // pictureBox192
            // 
            this.pictureBox192.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox192.Location = new System.Drawing.Point(666, 713);
            this.pictureBox192.Margin = new System.Windows.Forms.Padding(0);
            this.pictureBox192.Name = "pictureBox192";
            this.pictureBox192.Size = new System.Drawing.Size(61, 58);
            this.pictureBox192.TabIndex = 0;
            this.pictureBox192.TabStop = false;
            this.pictureBox192.Click += new System.EventHandler(this.pictureBox192_Click);
            // 
            // pictureBox193
            // 
            this.pictureBox193.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox193.Location = new System.Drawing.Point(727, 713);
            this.pictureBox193.Margin = new System.Windows.Forms.Padding(0);
            this.pictureBox193.Name = "pictureBox193";
            this.pictureBox193.Size = new System.Drawing.Size(63, 58);
            this.pictureBox193.TabIndex = 0;
            this.pictureBox193.TabStop = false;
            this.pictureBox193.Click += new System.EventHandler(this.pictureBox193_Click);
            // 
            // pictureBox194
            // 
            this.pictureBox194.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox194.Location = new System.Drawing.Point(790, 713);
            this.pictureBox194.Margin = new System.Windows.Forms.Padding(0);
            this.pictureBox194.Name = "pictureBox194";
            this.pictureBox194.Size = new System.Drawing.Size(56, 58);
            this.pictureBox194.TabIndex = 0;
            this.pictureBox194.TabStop = false;
            this.pictureBox194.Click += new System.EventHandler(this.pictureBox194_Click);
            // 
            // pictureBox195
            // 
            this.pictureBox195.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox195.Location = new System.Drawing.Point(846, 713);
            this.pictureBox195.Margin = new System.Windows.Forms.Padding(0);
            this.pictureBox195.Name = "pictureBox195";
            this.pictureBox195.Size = new System.Drawing.Size(62, 58);
            this.pictureBox195.TabIndex = 0;
            this.pictureBox195.TabStop = false;
            this.pictureBox195.Click += new System.EventHandler(this.pictureBox195_Click);
            // 
            // pictureBox196
            // 
            this.pictureBox196.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox196.Location = new System.Drawing.Point(0, 771);
            this.pictureBox196.Margin = new System.Windows.Forms.Padding(0);
            this.pictureBox196.Name = "pictureBox196";
            this.pictureBox196.Size = new System.Drawing.Size(59, 60);
            this.pictureBox196.TabIndex = 0;
            this.pictureBox196.TabStop = false;
            this.pictureBox196.Click += new System.EventHandler(this.pictureBox196_Click);
            // 
            // pictureBox197
            // 
            this.pictureBox197.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox197.Location = new System.Drawing.Point(59, 771);
            this.pictureBox197.Margin = new System.Windows.Forms.Padding(0);
            this.pictureBox197.Name = "pictureBox197";
            this.pictureBox197.Size = new System.Drawing.Size(59, 60);
            this.pictureBox197.TabIndex = 0;
            this.pictureBox197.TabStop = false;
            this.pictureBox197.Click += new System.EventHandler(this.pictureBox197_Click);
            // 
            // pictureBox198
            // 
            this.pictureBox198.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox198.Location = new System.Drawing.Point(118, 771);
            this.pictureBox198.Margin = new System.Windows.Forms.Padding(0);
            this.pictureBox198.Name = "pictureBox198";
            this.pictureBox198.Size = new System.Drawing.Size(59, 60);
            this.pictureBox198.TabIndex = 0;
            this.pictureBox198.TabStop = false;
            this.pictureBox198.Click += new System.EventHandler(this.pictureBox198_Click);
            // 
            // pictureBox199
            // 
            this.pictureBox199.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox199.Location = new System.Drawing.Point(177, 771);
            this.pictureBox199.Margin = new System.Windows.Forms.Padding(0);
            this.pictureBox199.Name = "pictureBox199";
            this.pictureBox199.Size = new System.Drawing.Size(59, 60);
            this.pictureBox199.TabIndex = 0;
            this.pictureBox199.TabStop = false;
            this.pictureBox199.Click += new System.EventHandler(this.pictureBox199_Click);
            // 
            // pictureBox200
            // 
            this.pictureBox200.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox200.Location = new System.Drawing.Point(236, 771);
            this.pictureBox200.Margin = new System.Windows.Forms.Padding(0);
            this.pictureBox200.Name = "pictureBox200";
            this.pictureBox200.Size = new System.Drawing.Size(61, 60);
            this.pictureBox200.TabIndex = 0;
            this.pictureBox200.TabStop = false;
            this.pictureBox200.Click += new System.EventHandler(this.pictureBox200_Click);
            // 
            // pictureBox201
            // 
            this.pictureBox201.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox201.Location = new System.Drawing.Point(297, 771);
            this.pictureBox201.Margin = new System.Windows.Forms.Padding(0);
            this.pictureBox201.Name = "pictureBox201";
            this.pictureBox201.Size = new System.Drawing.Size(58, 60);
            this.pictureBox201.TabIndex = 0;
            this.pictureBox201.TabStop = false;
            this.pictureBox201.Click += new System.EventHandler(this.pictureBox201_Click);
            // 
            // pictureBox202
            // 
            this.pictureBox202.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox202.Location = new System.Drawing.Point(355, 771);
            this.pictureBox202.Margin = new System.Windows.Forms.Padding(0);
            this.pictureBox202.Name = "pictureBox202";
            this.pictureBox202.Size = new System.Drawing.Size(63, 60);
            this.pictureBox202.TabIndex = 0;
            this.pictureBox202.TabStop = false;
            this.pictureBox202.Click += new System.EventHandler(this.pictureBox202_Click);
            // 
            // pictureBox203
            // 
            this.pictureBox203.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox203.Location = new System.Drawing.Point(418, 771);
            this.pictureBox203.Margin = new System.Windows.Forms.Padding(0);
            this.pictureBox203.Name = "pictureBox203";
            this.pictureBox203.Size = new System.Drawing.Size(67, 60);
            this.pictureBox203.TabIndex = 0;
            this.pictureBox203.TabStop = false;
            this.pictureBox203.Click += new System.EventHandler(this.pictureBox203_Click);
            // 
            // pictureBox204
            // 
            this.pictureBox204.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox204.Location = new System.Drawing.Point(485, 771);
            this.pictureBox204.Margin = new System.Windows.Forms.Padding(0);
            this.pictureBox204.Name = "pictureBox204";
            this.pictureBox204.Size = new System.Drawing.Size(59, 60);
            this.pictureBox204.TabIndex = 0;
            this.pictureBox204.TabStop = false;
            this.pictureBox204.Click += new System.EventHandler(this.pictureBox204_Click);
            // 
            // pictureBox205
            // 
            this.pictureBox205.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox205.Location = new System.Drawing.Point(544, 771);
            this.pictureBox205.Margin = new System.Windows.Forms.Padding(0);
            this.pictureBox205.Name = "pictureBox205";
            this.pictureBox205.Size = new System.Drawing.Size(59, 60);
            this.pictureBox205.TabIndex = 0;
            this.pictureBox205.TabStop = false;
            this.pictureBox205.Click += new System.EventHandler(this.pictureBox205_Click);
            // 
            // pictureBox206
            // 
            this.pictureBox206.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox206.Location = new System.Drawing.Point(603, 771);
            this.pictureBox206.Margin = new System.Windows.Forms.Padding(0);
            this.pictureBox206.Name = "pictureBox206";
            this.pictureBox206.Size = new System.Drawing.Size(63, 60);
            this.pictureBox206.TabIndex = 0;
            this.pictureBox206.TabStop = false;
            this.pictureBox206.Click += new System.EventHandler(this.pictureBox206_Click);
            // 
            // pictureBox207
            // 
            this.pictureBox207.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox207.Location = new System.Drawing.Point(666, 771);
            this.pictureBox207.Margin = new System.Windows.Forms.Padding(0);
            this.pictureBox207.Name = "pictureBox207";
            this.pictureBox207.Size = new System.Drawing.Size(61, 60);
            this.pictureBox207.TabIndex = 0;
            this.pictureBox207.TabStop = false;
            this.pictureBox207.Click += new System.EventHandler(this.pictureBox207_Click);
            // 
            // pictureBox208
            // 
            this.pictureBox208.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox208.Location = new System.Drawing.Point(727, 771);
            this.pictureBox208.Margin = new System.Windows.Forms.Padding(0);
            this.pictureBox208.Name = "pictureBox208";
            this.pictureBox208.Size = new System.Drawing.Size(63, 60);
            this.pictureBox208.TabIndex = 0;
            this.pictureBox208.TabStop = false;
            this.pictureBox208.Click += new System.EventHandler(this.pictureBox208_Click);
            // 
            // pictureBox209
            // 
            this.pictureBox209.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox209.Location = new System.Drawing.Point(790, 771);
            this.pictureBox209.Margin = new System.Windows.Forms.Padding(0);
            this.pictureBox209.Name = "pictureBox209";
            this.pictureBox209.Size = new System.Drawing.Size(56, 60);
            this.pictureBox209.TabIndex = 0;
            this.pictureBox209.TabStop = false;
            this.pictureBox209.Click += new System.EventHandler(this.pictureBox209_Click);
            // 
            // pictureBox210
            // 
            this.pictureBox210.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox210.Location = new System.Drawing.Point(846, 771);
            this.pictureBox210.Margin = new System.Windows.Forms.Padding(0);
            this.pictureBox210.Name = "pictureBox210";
            this.pictureBox210.Size = new System.Drawing.Size(62, 60);
            this.pictureBox210.TabIndex = 0;
            this.pictureBox210.TabStop = false;
            this.pictureBox210.Click += new System.EventHandler(this.pictureBox210_Click);
            // 
            // pictureBox211
            // 
            this.pictureBox211.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox211.Location = new System.Drawing.Point(0, 831);
            this.pictureBox211.Margin = new System.Windows.Forms.Padding(0);
            this.pictureBox211.Name = "pictureBox211";
            this.pictureBox211.Size = new System.Drawing.Size(59, 67);
            this.pictureBox211.TabIndex = 0;
            this.pictureBox211.TabStop = false;
            this.pictureBox211.Click += new System.EventHandler(this.pictureBox211_Click);
            // 
            // pictureBox212
            // 
            this.pictureBox212.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox212.Location = new System.Drawing.Point(59, 831);
            this.pictureBox212.Margin = new System.Windows.Forms.Padding(0);
            this.pictureBox212.Name = "pictureBox212";
            this.pictureBox212.Size = new System.Drawing.Size(59, 67);
            this.pictureBox212.TabIndex = 0;
            this.pictureBox212.TabStop = false;
            this.pictureBox212.Click += new System.EventHandler(this.pictureBox212_Click);
            // 
            // pictureBox213
            // 
            this.pictureBox213.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox213.Location = new System.Drawing.Point(118, 831);
            this.pictureBox213.Margin = new System.Windows.Forms.Padding(0);
            this.pictureBox213.Name = "pictureBox213";
            this.pictureBox213.Size = new System.Drawing.Size(59, 67);
            this.pictureBox213.TabIndex = 0;
            this.pictureBox213.TabStop = false;
            this.pictureBox213.Click += new System.EventHandler(this.pictureBox213_Click);
            // 
            // pictureBox214
            // 
            this.pictureBox214.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox214.Location = new System.Drawing.Point(177, 831);
            this.pictureBox214.Margin = new System.Windows.Forms.Padding(0);
            this.pictureBox214.Name = "pictureBox214";
            this.pictureBox214.Size = new System.Drawing.Size(59, 67);
            this.pictureBox214.TabIndex = 0;
            this.pictureBox214.TabStop = false;
            this.pictureBox214.Click += new System.EventHandler(this.pictureBox214_Click);
            // 
            // pictureBox215
            // 
            this.pictureBox215.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox215.Location = new System.Drawing.Point(236, 831);
            this.pictureBox215.Margin = new System.Windows.Forms.Padding(0);
            this.pictureBox215.Name = "pictureBox215";
            this.pictureBox215.Size = new System.Drawing.Size(61, 67);
            this.pictureBox215.TabIndex = 0;
            this.pictureBox215.TabStop = false;
            this.pictureBox215.Click += new System.EventHandler(this.pictureBox215_Click);
            // 
            // pictureBox216
            // 
            this.pictureBox216.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox216.Location = new System.Drawing.Point(297, 831);
            this.pictureBox216.Margin = new System.Windows.Forms.Padding(0);
            this.pictureBox216.Name = "pictureBox216";
            this.pictureBox216.Size = new System.Drawing.Size(58, 67);
            this.pictureBox216.TabIndex = 0;
            this.pictureBox216.TabStop = false;
            this.pictureBox216.Click += new System.EventHandler(this.pictureBox216_Click);
            // 
            // pictureBox217
            // 
            this.pictureBox217.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox217.Location = new System.Drawing.Point(355, 831);
            this.pictureBox217.Margin = new System.Windows.Forms.Padding(0);
            this.pictureBox217.Name = "pictureBox217";
            this.pictureBox217.Size = new System.Drawing.Size(63, 67);
            this.pictureBox217.TabIndex = 0;
            this.pictureBox217.TabStop = false;
            this.pictureBox217.Click += new System.EventHandler(this.pictureBox217_Click);
            // 
            // pictureBox218
            // 
            this.pictureBox218.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox218.Location = new System.Drawing.Point(418, 831);
            this.pictureBox218.Margin = new System.Windows.Forms.Padding(0);
            this.pictureBox218.Name = "pictureBox218";
            this.pictureBox218.Size = new System.Drawing.Size(67, 67);
            this.pictureBox218.TabIndex = 0;
            this.pictureBox218.TabStop = false;
            this.pictureBox218.Click += new System.EventHandler(this.pictureBox218_Click);
            // 
            // pictureBox219
            // 
            this.pictureBox219.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox219.Location = new System.Drawing.Point(485, 831);
            this.pictureBox219.Margin = new System.Windows.Forms.Padding(0);
            this.pictureBox219.Name = "pictureBox219";
            this.pictureBox219.Size = new System.Drawing.Size(59, 67);
            this.pictureBox219.TabIndex = 0;
            this.pictureBox219.TabStop = false;
            this.pictureBox219.Click += new System.EventHandler(this.pictureBox219_Click);
            // 
            // pictureBox220
            // 
            this.pictureBox220.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox220.Location = new System.Drawing.Point(544, 831);
            this.pictureBox220.Margin = new System.Windows.Forms.Padding(0);
            this.pictureBox220.Name = "pictureBox220";
            this.pictureBox220.Size = new System.Drawing.Size(59, 67);
            this.pictureBox220.TabIndex = 0;
            this.pictureBox220.TabStop = false;
            this.pictureBox220.Click += new System.EventHandler(this.pictureBox220_Click);
            // 
            // pictureBox221
            // 
            this.pictureBox221.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox221.Location = new System.Drawing.Point(603, 831);
            this.pictureBox221.Margin = new System.Windows.Forms.Padding(0);
            this.pictureBox221.Name = "pictureBox221";
            this.pictureBox221.Size = new System.Drawing.Size(63, 67);
            this.pictureBox221.TabIndex = 0;
            this.pictureBox221.TabStop = false;
            this.pictureBox221.Click += new System.EventHandler(this.pictureBox221_Click);
            // 
            // pictureBox222
            // 
            this.pictureBox222.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox222.Location = new System.Drawing.Point(666, 831);
            this.pictureBox222.Margin = new System.Windows.Forms.Padding(0);
            this.pictureBox222.Name = "pictureBox222";
            this.pictureBox222.Size = new System.Drawing.Size(61, 67);
            this.pictureBox222.TabIndex = 0;
            this.pictureBox222.TabStop = false;
            this.pictureBox222.Click += new System.EventHandler(this.pictureBox222_Click);
            // 
            // pictureBox223
            // 
            this.pictureBox223.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox223.Location = new System.Drawing.Point(727, 831);
            this.pictureBox223.Margin = new System.Windows.Forms.Padding(0);
            this.pictureBox223.Name = "pictureBox223";
            this.pictureBox223.Size = new System.Drawing.Size(63, 67);
            this.pictureBox223.TabIndex = 0;
            this.pictureBox223.TabStop = false;
            this.pictureBox223.Click += new System.EventHandler(this.pictureBox223_Click);
            // 
            // pictureBox224
            // 
            this.pictureBox224.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox224.Location = new System.Drawing.Point(790, 831);
            this.pictureBox224.Margin = new System.Windows.Forms.Padding(0);
            this.pictureBox224.Name = "pictureBox224";
            this.pictureBox224.Size = new System.Drawing.Size(56, 67);
            this.pictureBox224.TabIndex = 0;
            this.pictureBox224.TabStop = false;
            this.pictureBox224.Click += new System.EventHandler(this.pictureBox224_Click);
            // 
            // pictureBox225
            // 
            this.pictureBox225.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox225.Location = new System.Drawing.Point(846, 831);
            this.pictureBox225.Margin = new System.Windows.Forms.Padding(0);
            this.pictureBox225.Name = "pictureBox225";
            this.pictureBox225.Size = new System.Drawing.Size(62, 67);
            this.pictureBox225.TabIndex = 0;
            this.pictureBox225.TabStop = false;
            this.pictureBox225.Click += new System.EventHandler(this.pictureBox225_Click);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(1271, 130);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(166, 90);
            this.button1.TabIndex = 1;
            this.button1.Text = "Start";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(0, 0);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(75, 23);
            this.button2.TabIndex = 4;
            // 
            // button3
            // 
            this.button3.Enabled = false;
            this.button3.Location = new System.Drawing.Point(1271, 282);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(166, 90);
            this.button3.TabIndex = 3;
            this.button3.Text = "Exit";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // Gobang
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(13F, 32F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::Gobang_Melinda.Properties.Resources._3;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.ClientSize = new System.Drawing.Size(1484, 971);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.tableLayoutPanel1);
            this.Cursor = System.Windows.Forms.Cursors.Default;
            this.Margin = new System.Windows.Forms.Padding(6);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "Gobang";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Gobang";
            this.tableLayoutPanel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox11)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox12)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox13)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox14)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox15)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox16)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox17)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox18)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox19)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox20)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox21)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox22)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox23)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox24)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox25)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox26)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox27)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox28)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox29)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox30)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox31)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox32)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox33)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox34)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox35)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox36)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox37)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox38)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox39)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox40)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox41)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox42)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox43)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox44)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox45)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox46)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox47)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox48)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox49)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox50)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox51)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox52)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox53)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox54)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox55)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox56)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox57)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox58)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox59)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox60)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox61)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox62)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox63)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox64)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox65)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox66)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox67)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox68)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox69)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox70)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox71)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox72)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox73)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox74)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox75)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox76)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox77)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox78)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox79)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox80)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox81)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox82)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox83)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox84)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox85)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox86)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox87)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox88)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox89)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox90)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox91)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox92)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox93)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox94)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox95)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox96)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox97)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox98)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox99)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox100)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox101)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox102)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox103)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox104)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox105)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox106)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox107)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox108)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox109)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox110)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox111)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox112)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox113)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox114)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox115)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox116)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox117)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox118)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox119)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox120)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox121)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox122)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox123)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox124)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox125)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox126)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox127)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox128)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox129)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox130)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox131)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox132)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox133)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox134)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox135)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox136)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox137)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox138)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox139)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox140)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox141)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox142)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox143)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox144)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox145)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox146)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox147)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox148)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox149)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox150)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox151)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox152)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox153)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox154)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox155)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox156)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox157)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox158)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox159)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox160)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox161)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox162)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox163)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox164)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox165)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox166)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox167)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox168)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox169)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox170)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox171)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox172)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox173)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox174)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox175)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox176)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox177)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox178)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox179)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox180)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox181)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox182)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox183)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox184)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox185)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox186)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox187)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox188)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox189)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox190)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox191)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox192)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox193)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox194)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox195)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox196)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox197)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox198)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox199)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox200)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox201)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox202)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox203)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox204)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox205)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox206)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox207)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox208)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox209)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox210)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox211)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox212)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox213)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox214)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox215)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox216)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox217)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox218)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox219)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox220)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox221)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox222)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox223)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox224)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox225)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.PictureBox pictureBox5;
        private System.Windows.Forms.PictureBox pictureBox6;
        private System.Windows.Forms.PictureBox pictureBox7;
        private System.Windows.Forms.PictureBox pictureBox8;
        private System.Windows.Forms.PictureBox pictureBox9;
        private System.Windows.Forms.PictureBox pictureBox10;
        private System.Windows.Forms.PictureBox pictureBox11;
        private System.Windows.Forms.PictureBox pictureBox12;
        private System.Windows.Forms.PictureBox pictureBox13;
        private System.Windows.Forms.PictureBox pictureBox14;
        private System.Windows.Forms.PictureBox pictureBox15;
        private System.Windows.Forms.PictureBox pictureBox16;
        private System.Windows.Forms.PictureBox pictureBox17;
        private System.Windows.Forms.PictureBox pictureBox18;
        private System.Windows.Forms.PictureBox pictureBox19;
        private System.Windows.Forms.PictureBox pictureBox20;
        private System.Windows.Forms.PictureBox pictureBox21;
        private System.Windows.Forms.PictureBox pictureBox22;
        private System.Windows.Forms.PictureBox pictureBox23;
        private System.Windows.Forms.PictureBox pictureBox24;
        private System.Windows.Forms.PictureBox pictureBox25;
        private System.Windows.Forms.PictureBox pictureBox26;
        private System.Windows.Forms.PictureBox pictureBox27;
        private System.Windows.Forms.PictureBox pictureBox28;
        private System.Windows.Forms.PictureBox pictureBox29;
        private System.Windows.Forms.PictureBox pictureBox30;
        private System.Windows.Forms.PictureBox pictureBox31;
        private System.Windows.Forms.PictureBox pictureBox32;
        private System.Windows.Forms.PictureBox pictureBox33;
        private System.Windows.Forms.PictureBox pictureBox34;
        private System.Windows.Forms.PictureBox pictureBox35;
        private System.Windows.Forms.PictureBox pictureBox36;
        private System.Windows.Forms.PictureBox pictureBox37;
        private System.Windows.Forms.PictureBox pictureBox38;
        private System.Windows.Forms.PictureBox pictureBox39;
        private System.Windows.Forms.PictureBox pictureBox40;
        private System.Windows.Forms.PictureBox pictureBox41;
        private System.Windows.Forms.PictureBox pictureBox42;
        private System.Windows.Forms.PictureBox pictureBox43;
        private System.Windows.Forms.PictureBox pictureBox44;
        private System.Windows.Forms.PictureBox pictureBox45;
        private System.Windows.Forms.PictureBox pictureBox46;
        private System.Windows.Forms.PictureBox pictureBox47;
        private System.Windows.Forms.PictureBox pictureBox48;
        private System.Windows.Forms.PictureBox pictureBox49;
        private System.Windows.Forms.PictureBox pictureBox50;
        private System.Windows.Forms.PictureBox pictureBox51;
        private System.Windows.Forms.PictureBox pictureBox52;
        private System.Windows.Forms.PictureBox pictureBox53;
        private System.Windows.Forms.PictureBox pictureBox54;
        private System.Windows.Forms.PictureBox pictureBox55;
        private System.Windows.Forms.PictureBox pictureBox56;
        private System.Windows.Forms.PictureBox pictureBox57;
        private System.Windows.Forms.PictureBox pictureBox58;
        private System.Windows.Forms.PictureBox pictureBox59;
        private System.Windows.Forms.PictureBox pictureBox60;
        private System.Windows.Forms.PictureBox pictureBox61;
        private System.Windows.Forms.PictureBox pictureBox62;
        private System.Windows.Forms.PictureBox pictureBox63;
        private System.Windows.Forms.PictureBox pictureBox64;
        private System.Windows.Forms.PictureBox pictureBox65;
        private System.Windows.Forms.PictureBox pictureBox66;
        private System.Windows.Forms.PictureBox pictureBox67;
        private System.Windows.Forms.PictureBox pictureBox68;
        private System.Windows.Forms.PictureBox pictureBox69;
        private System.Windows.Forms.PictureBox pictureBox70;
        private System.Windows.Forms.PictureBox pictureBox71;
        private System.Windows.Forms.PictureBox pictureBox72;
        private System.Windows.Forms.PictureBox pictureBox73;
        private System.Windows.Forms.PictureBox pictureBox74;
        private System.Windows.Forms.PictureBox pictureBox75;
        private System.Windows.Forms.PictureBox pictureBox76;
        private System.Windows.Forms.PictureBox pictureBox77;
        private System.Windows.Forms.PictureBox pictureBox78;
        private System.Windows.Forms.PictureBox pictureBox79;
        private System.Windows.Forms.PictureBox pictureBox80;
        private System.Windows.Forms.PictureBox pictureBox81;
        private System.Windows.Forms.PictureBox pictureBox82;
        private System.Windows.Forms.PictureBox pictureBox83;
        private System.Windows.Forms.PictureBox pictureBox84;
        private System.Windows.Forms.PictureBox pictureBox85;
        private System.Windows.Forms.PictureBox pictureBox86;
        private System.Windows.Forms.PictureBox pictureBox87;
        private System.Windows.Forms.PictureBox pictureBox88;
        private System.Windows.Forms.PictureBox pictureBox89;
        private System.Windows.Forms.PictureBox pictureBox90;
        private System.Windows.Forms.PictureBox pictureBox91;
        private System.Windows.Forms.PictureBox pictureBox92;
        private System.Windows.Forms.PictureBox pictureBox93;
        private System.Windows.Forms.PictureBox pictureBox94;
        private System.Windows.Forms.PictureBox pictureBox95;
        private System.Windows.Forms.PictureBox pictureBox96;
        private System.Windows.Forms.PictureBox pictureBox97;
        private System.Windows.Forms.PictureBox pictureBox98;
        private System.Windows.Forms.PictureBox pictureBox99;
        private System.Windows.Forms.PictureBox pictureBox100;
        private System.Windows.Forms.PictureBox pictureBox101;
        private System.Windows.Forms.PictureBox pictureBox102;
        private System.Windows.Forms.PictureBox pictureBox103;
        private System.Windows.Forms.PictureBox pictureBox104;
        private System.Windows.Forms.PictureBox pictureBox105;
        private System.Windows.Forms.PictureBox pictureBox106;
        private System.Windows.Forms.PictureBox pictureBox107;
        private System.Windows.Forms.PictureBox pictureBox108;
        private System.Windows.Forms.PictureBox pictureBox109;
        private System.Windows.Forms.PictureBox pictureBox110;
        private System.Windows.Forms.PictureBox pictureBox111;
        private System.Windows.Forms.PictureBox pictureBox112;
        private System.Windows.Forms.PictureBox pictureBox113;
        private System.Windows.Forms.PictureBox pictureBox114;
        private System.Windows.Forms.PictureBox pictureBox115;
        private System.Windows.Forms.PictureBox pictureBox116;
        private System.Windows.Forms.PictureBox pictureBox117;
        private System.Windows.Forms.PictureBox pictureBox118;
        private System.Windows.Forms.PictureBox pictureBox119;
        private System.Windows.Forms.PictureBox pictureBox120;
        private System.Windows.Forms.PictureBox pictureBox121;
        private System.Windows.Forms.PictureBox pictureBox122;
        private System.Windows.Forms.PictureBox pictureBox123;
        private System.Windows.Forms.PictureBox pictureBox124;
        private System.Windows.Forms.PictureBox pictureBox125;
        private System.Windows.Forms.PictureBox pictureBox126;
        private System.Windows.Forms.PictureBox pictureBox127;
        private System.Windows.Forms.PictureBox pictureBox128;
        private System.Windows.Forms.PictureBox pictureBox129;
        private System.Windows.Forms.PictureBox pictureBox130;
        private System.Windows.Forms.PictureBox pictureBox131;
        private System.Windows.Forms.PictureBox pictureBox132;
        private System.Windows.Forms.PictureBox pictureBox133;
        private System.Windows.Forms.PictureBox pictureBox134;
        private System.Windows.Forms.PictureBox pictureBox135;
        private System.Windows.Forms.PictureBox pictureBox136;
        private System.Windows.Forms.PictureBox pictureBox137;
        private System.Windows.Forms.PictureBox pictureBox138;
        private System.Windows.Forms.PictureBox pictureBox139;
        private System.Windows.Forms.PictureBox pictureBox140;
        private System.Windows.Forms.PictureBox pictureBox141;
        private System.Windows.Forms.PictureBox pictureBox142;
        private System.Windows.Forms.PictureBox pictureBox143;
        private System.Windows.Forms.PictureBox pictureBox144;
        private System.Windows.Forms.PictureBox pictureBox145;
        private System.Windows.Forms.PictureBox pictureBox146;
        private System.Windows.Forms.PictureBox pictureBox147;
        private System.Windows.Forms.PictureBox pictureBox148;
        private System.Windows.Forms.PictureBox pictureBox149;
        private System.Windows.Forms.PictureBox pictureBox150;
        private System.Windows.Forms.PictureBox pictureBox151;
        private System.Windows.Forms.PictureBox pictureBox152;
        private System.Windows.Forms.PictureBox pictureBox153;
        private System.Windows.Forms.PictureBox pictureBox154;
        private System.Windows.Forms.PictureBox pictureBox155;
        private System.Windows.Forms.PictureBox pictureBox156;
        private System.Windows.Forms.PictureBox pictureBox157;
        private System.Windows.Forms.PictureBox pictureBox158;
        private System.Windows.Forms.PictureBox pictureBox159;
        private System.Windows.Forms.PictureBox pictureBox160;
        private System.Windows.Forms.PictureBox pictureBox161;
        private System.Windows.Forms.PictureBox pictureBox162;
        private System.Windows.Forms.PictureBox pictureBox163;
        private System.Windows.Forms.PictureBox pictureBox164;
        private System.Windows.Forms.PictureBox pictureBox165;
        private System.Windows.Forms.PictureBox pictureBox166;
        private System.Windows.Forms.PictureBox pictureBox167;
        private System.Windows.Forms.PictureBox pictureBox168;
        private System.Windows.Forms.PictureBox pictureBox169;
        private System.Windows.Forms.PictureBox pictureBox170;
        private System.Windows.Forms.PictureBox pictureBox171;
        private System.Windows.Forms.PictureBox pictureBox172;
        private System.Windows.Forms.PictureBox pictureBox173;
        private System.Windows.Forms.PictureBox pictureBox174;
        private System.Windows.Forms.PictureBox pictureBox175;
        private System.Windows.Forms.PictureBox pictureBox176;
        private System.Windows.Forms.PictureBox pictureBox177;
        private System.Windows.Forms.PictureBox pictureBox178;
        private System.Windows.Forms.PictureBox pictureBox179;
        private System.Windows.Forms.PictureBox pictureBox180;
        private System.Windows.Forms.PictureBox pictureBox181;
        private System.Windows.Forms.PictureBox pictureBox182;
        private System.Windows.Forms.PictureBox pictureBox183;
        private System.Windows.Forms.PictureBox pictureBox184;
        private System.Windows.Forms.PictureBox pictureBox185;
        private System.Windows.Forms.PictureBox pictureBox186;
        private System.Windows.Forms.PictureBox pictureBox187;
        private System.Windows.Forms.PictureBox pictureBox188;
        private System.Windows.Forms.PictureBox pictureBox189;
        private System.Windows.Forms.PictureBox pictureBox190;
        private System.Windows.Forms.PictureBox pictureBox191;
        private System.Windows.Forms.PictureBox pictureBox192;
        private System.Windows.Forms.PictureBox pictureBox193;
        private System.Windows.Forms.PictureBox pictureBox194;
        private System.Windows.Forms.PictureBox pictureBox195;
        private System.Windows.Forms.PictureBox pictureBox196;
        private System.Windows.Forms.PictureBox pictureBox197;
        private System.Windows.Forms.PictureBox pictureBox198;
        private System.Windows.Forms.PictureBox pictureBox199;
        private System.Windows.Forms.PictureBox pictureBox200;
        private System.Windows.Forms.PictureBox pictureBox201;
        private System.Windows.Forms.PictureBox pictureBox202;
        private System.Windows.Forms.PictureBox pictureBox203;
        private System.Windows.Forms.PictureBox pictureBox204;
        private System.Windows.Forms.PictureBox pictureBox205;
        private System.Windows.Forms.PictureBox pictureBox206;
        private System.Windows.Forms.PictureBox pictureBox207;
        private System.Windows.Forms.PictureBox pictureBox208;
        private System.Windows.Forms.PictureBox pictureBox209;
        private System.Windows.Forms.PictureBox pictureBox210;
        private System.Windows.Forms.PictureBox pictureBox211;
        private System.Windows.Forms.PictureBox pictureBox212;
        private System.Windows.Forms.PictureBox pictureBox213;
        private System.Windows.Forms.PictureBox pictureBox214;
        private System.Windows.Forms.PictureBox pictureBox215;
        private System.Windows.Forms.PictureBox pictureBox216;
        private System.Windows.Forms.PictureBox pictureBox217;
        private System.Windows.Forms.PictureBox pictureBox218;
        private System.Windows.Forms.PictureBox pictureBox219;
        private System.Windows.Forms.PictureBox pictureBox220;
        private System.Windows.Forms.PictureBox pictureBox221;
        private System.Windows.Forms.PictureBox pictureBox222;
        private System.Windows.Forms.PictureBox pictureBox223;
        private System.Windows.Forms.PictureBox pictureBox224;
        private System.Windows.Forms.PictureBox pictureBox225;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
    }
}

